package com.cinemasub.browser.audio

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class DeepgramStreamingClient(
    private val apiKey: String,
    private val onTranscript: (text: String, isFinal: Boolean) -> Unit,
    private val onStatusChanged: (connected: Boolean, errorMsg: String?) -> Unit
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .build()

    @Volatile
    private var webSocket: WebSocket? = null
    private val isConnected = AtomicBoolean(false)
    private val isClosedManually = AtomicBoolean(false)

    fun connect() {
        isClosedManually.set(false)
        val url = "wss://api.deepgram.com/v1/listen" +
            "?model=nova-2" +
            "&language=multi" +
            "&encoding=linear16" +
            "&sample_rate=16000" +
            "&channels=1" +
            "&smart_format=true" +
            "&interim_results=true" +
            "&endpointing=300" +
            "&vad_events=true"

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Token ${apiKey.trim()}")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                isConnected.set(true)
                onStatusChanged(true, null)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                runCatching {
                    val json = JSONObject(text)
                    val channel = json.optJSONObject("channel") ?: return
                    val alts = channel.optJSONArray("alternatives") ?: return
                    if (alts.length() == 0) return
                    val transcript = alts.optJSONObject(0)?.optString("transcript", "")?.trim().orEmpty()
                    if (transcript.isNotEmpty()) {
                        val isFinal = json.optBoolean("is_final", false) || json.optBoolean("speech_final", false)
                        onTranscript(transcript, isFinal)
                    }
                }
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                isConnected.set(false)
                if (!isClosedManually.get()) {
                    val code = response?.code
                    val msg = if (code == 401 || code == 403) {
                        "مفتاح Deepgram غير صحيح أو منتهي الصلاحية"
                    } else {
                        "انقطع اتصال البث المباشر: ${t.localizedMessage ?: "خطأ شبكة"}"
                    }
                    onStatusChanged(false, msg)
                }
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                isConnected.set(false)
                if (!isClosedManually.get()) {
                    onStatusChanged(false, null)
                }
            }
        })
    }

    fun sendPcmAudio(data: ByteArray, length: Int) {
        if (!isConnected.get() || length <= 0) return
        webSocket?.send(data.toByteString(0, length))
    }

    fun sendKeepAlive() {
        if (!isConnected.get()) return
        webSocket?.send("""{"type":"KeepAlive"}""")
    }

    fun close() {
        isClosedManually.set(true)
        isConnected.set(false)
        runCatching {
            webSocket?.send("""{"type":"CloseStream"}""")
            webSocket?.close(1000, "Stopped")
        }
        webSocket = null
    }
}
