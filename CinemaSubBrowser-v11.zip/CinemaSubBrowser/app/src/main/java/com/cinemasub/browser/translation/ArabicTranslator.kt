package com.cinemasub.browser.translation

import com.cinemasub.browser.model.TranslationEngine
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Collections
import java.util.concurrent.atomic.AtomicBoolean

class ArabicTranslator {

    companion object {
        private const val CINEMA_SYSTEM_PROMPT =
            "You are a professional Netflix Arabic movie subtitle translator. " +
                "Translate the dialogue into natural, idiomatic, concise Arabic suitable for cinema subtitles. " +
                "Translate slang and idioms by meaning, not literally. " +
                "Output ONLY the Arabic translation text with no markdown, no asterisks, no quotes, and no notes."
    }

    private val options = TranslatorOptions.Builder()
        .setSourceLanguage(TranslateLanguage.ENGLISH)
        .setTargetLanguage(TranslateLanguage.ARABIC)
        .build()

    private val mlKitTranslator: Translator = Translation.getClient(options)
    private val isOfflineReady = AtomicBoolean(false)

    @Volatile
    private var cachedGeminiModel: String? = null

    @Volatile
    private var cachedGroqModel: String? = null

    @Volatile
    private var cachedCerebrasModel: String? = null

    private val cache: MutableMap<String, String> = Collections.synchronizedMap(
        object : LinkedHashMap<String, String>(520, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
                return size > 500
            }
        }
    )

    suspend fun ensureModelDownloaded() {
        if (isOfflineReady.get()) return
        runCatching {
            val conditions = DownloadConditions.Builder().build()
            mlKitTranslator.downloadModelIfNeeded(conditions).await()
            isOfflineReady.set(true)
        }
    }

    suspend fun testApiKey(engine: TranslationEngine, rawKey: String): Pair<Boolean, String> =
        withContext(Dispatchers.IO) {
            val apiKey = rawKey.trim()
            if (apiKey.isEmpty()) {
                return@withContext Pair(false, "من فضلك أدخل المفتاح أولاً قبل الاختبار.")
            }
            when (engine) {
                TranslationEngine.GEMINI_AI -> testGeminiKey(apiKey)
                TranslationEngine.GROQ_AI -> testGroqKey(apiKey)
                TranslationEngine.CEREBRAS_AI -> testCerebrasKey(apiKey)
                TranslationEngine.GOOGLE_FREE -> Pair(true, "ترجمة جوجل المجانية تعمل بدون مفتاح.")
            }
        }

    private fun testGeminiKey(apiKey: String): Pair<Boolean, String> {
        cachedGeminiModel = null
        val models = listOf("gemini-2.5-flash-lite", "gemini-2.5-flash", "gemini-flash-latest")
        var lastError = "فشل الاتصال بسيرفر Gemini"
        for (model in models) {
            try {
                val url = URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
                )
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 5000
                    readTimeout = 6000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                }

                val payload = buildGeminiPayload("It's a piece of cake, don't worry about it!")
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }

                val code = conn.responseCode
                if (code == HttpURLConnection.HTTP_OK) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    val text = extractGeminiText(body)
                    if (text.isNotBlank()) {
                        cachedGeminiModel = model
                        return Pair(true, "المفتاح شغال بنجاح ($model)!\nتجربة: $text")
                    }
                } else {
                    val errBody = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    conn.disconnect()
                    val errMsg = runCatching {
                        JSONObject(errBody).optJSONObject("error")?.optString("message", "")
                    }.getOrNull().orEmpty()
                    lastError = when (code) {
                        400 -> "المفتاح غير صالح (400): $errMsg"
                        403 -> "المفتاح مرفوض أو غير مفعّل (403): $errMsg"
                        404 -> "الموديل $model غير متاح (404)"
                        429 -> "تم استهلاك الحد المجاني مؤقتاً (429): $errMsg"
                        else -> "خطأ من السيرفر ($code): $errMsg"
                    }
                }
            } catch (e: Exception) {
                lastError = "خطأ في الاتصال: ${e.localizedMessage ?: "تأكد من الإنترنت"}"
            }
        }
        return Pair(false, lastError)
    }

    private fun discoverGroqModels(apiKey: String): List<String> {
        val discovered = mutableListOf<String>()
        runCatching {
            val url = URL("https://api.groq.com/openai/v1/models")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4000
                readTimeout = 4000
                setRequestProperty("Authorization", "Bearer $apiKey")
            }
            if (conn.responseCode == HttpURLConnection.HTTP_OK) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val data = JSONObject(body).optJSONArray("data")
                if (data != null) {
                    for (i in 0 until data.length()) {
                        val id = data.optJSONObject(i)?.optString("id", "").orEmpty()
                        val lower = id.lowercase()
                        if (id.isNotBlank() &&
                            !lower.contains("whisper") &&
                            !lower.contains("tts") &&
                            !lower.contains("guard") &&
                            !lower.contains("safeguard") &&
                            !lower.contains("prompt-guard")
                        ) {
                            discovered.add(id)
                        }
                    }
                }
            } else {
                conn.disconnect()
            }
        }

        // Prioritize fast, high-quality chat models first
        val preferredOrder = listOf(
            "llama-3.3-70b-versatile",
            "meta-llama/llama-4-scout-17b-16e-instruct",
            "llama-3.1-8b-instant",
            "qwen/qwen3-32b",
            "gemma2-9b-it"
        )
        val sorted = mutableListOf<String>()
        for (pref in preferredOrder) {
            if (pref in discovered) sorted.add(pref)
        }
        for (m in discovered) {
            if (m !in sorted) sorted.add(m)
        }
        if (sorted.isEmpty()) {
            sorted.addAll(preferredOrder)
        }
        return sorted
    }

    private fun testGroqKey(apiKey: String): Pair<Boolean, String> {
        cachedGroqModel = null
        val candidates = discoverGroqModels(apiKey).take(5)
        var lastError = "فشل الاتصال بسيرفر Groq"

        for (model in candidates) {
            try {
                val url = URL("https://api.groq.com/openai/v1/chat/completions")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 5000
                    readTimeout = 6000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Authorization", "Bearer $apiKey")
                }

                val payload = buildGroqPayload(model, "It's a piece of cake, don't worry about it!")
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }

                val code = conn.responseCode
                if (code == HttpURLConnection.HTTP_OK) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    val text = extractGroqText(body)
                    if (text.isNotBlank()) {
                        cachedGroqModel = model
                        return Pair(true, "مفتاح Groq شغال بنجاح ($model)!\nتجربة: $text")
                    }
                } else {
                    val errBody = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    conn.disconnect()
                    val errMsg = runCatching {
                        JSONObject(errBody).optJSONObject("error")?.optString("message", "")
                    }.getOrNull().orEmpty()
                    if (code == 401) {
                        return Pair(false, "مفتاح Groq غير صحيح (401)")
                    }
                    lastError = when (code) {
                        429 -> "تم تجاوز حد الطلبات مؤقتاً (429)"
                        else -> "خطأ من Groq ($code): $errMsg"
                    }
                }
            } catch (e: Exception) {
                lastError = "خطأ في الاتصال: ${e.localizedMessage ?: "تأكد من الإنترنت"}"
            }
        }
        return Pair(false, lastError)
    }

    suspend fun preloadToCache(sourceText: String) {
        val cleaned = sourceText.trim()
        if (cleaned.isEmpty() || isAlreadyArabic(cleaned)) return
        val config = TranslationSettingsStore.currentConfig
        val cacheKey = "${config.engine.name}|$cleaned"
        if (cache.containsKey(cacheKey)) return
        translateToArabic(cleaned)
    }

    suspend fun translateToArabic(sourceText: String): String {
        val cleaned = sourceText.trim()
        if (cleaned.isEmpty()) return ""
        if (isAlreadyArabic(cleaned)) return cleaned

        val config = TranslationSettingsStore.currentConfig
        val cacheKey = "${config.engine.name}|$cleaned"
        cache[cacheKey]?.let { return it }

        val aiResult: String? = when (config.engine) {
            TranslationEngine.GEMINI_AI -> {
                if (config.geminiApiKey.isNotBlank()) {
                    translateViaGeminiFast(cleaned, config.geminiApiKey.trim())
                } else null
            }
            TranslationEngine.GROQ_AI -> {
                if (config.groqApiKey.isNotBlank()) {
                    translateViaGroqFast(cleaned, config.groqApiKey.trim())
                } else null
            }
            TranslationEngine.CEREBRAS_AI -> {
                if (config.cerebrasApiKey.isNotBlank()) {
                    translateViaCerebrasFast(cleaned, config.cerebrasApiKey.trim())
                } else null
            }
            TranslationEngine.GOOGLE_FREE -> null
        }

        if (!aiResult.isNullOrBlank()) {
            cache[cacheKey] = aiResult
            return aiResult
        }

        val onlineResult = translateViaGoogleFree(cleaned)
        if (!onlineResult.isNullOrBlank()) {
            cache[cacheKey] = onlineResult
            return onlineResult
        }

        if (!isOfflineReady.get()) ensureModelDownloaded()
        val offlineResult = runCatching {
            mlKitTranslator.translate(cleaned).await()
        }.getOrDefault("")

        if (offlineResult.isNotBlank()) {
            cache[cacheKey] = offlineResult
        }
        return offlineResult
    }

    private suspend fun translateViaGeminiFast(text: String, apiKey: String): String? =
        withContext(Dispatchers.IO) {
            val cached = cachedGeminiModel
            if (cached != null) {
                callGeminiModel(cached, text, apiKey)?.let { return@withContext it }
            }
            val models = listOf("gemini-2.5-flash-lite", "gemini-2.5-flash", "gemini-flash-latest")
            for (model in models) {
                if (model == cached) continue
                val res = callGeminiModel(model, text, apiKey)
                if (!res.isNullOrBlank()) {
                    cachedGeminiModel = model
                    return@withContext res
                }
            }
            null
        }

    private fun buildGeminiPayload(text: String): JSONObject = JSONObject().apply {
        put(
            "systemInstruction",
            JSONObject().put(
                "parts",
                JSONArray().put(JSONObject().put("text", CINEMA_SYSTEM_PROMPT))
            )
        )
        put(
            "contents",
            JSONArray().put(
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", text))
                )
            )
        )
        put(
            "generationConfig",
            JSONObject()
                .put("temperature", 0.2)
                .put("maxOutputTokens", 120)
        )
    }

    private fun extractGeminiText(body: String): String {
        val raw = runCatching {
            JSONObject(body)
                .optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text", "")
                .orEmpty()
        }.getOrDefault("")
        return sanitizeSubtitleOutput(raw)
    }

    private fun callGeminiModel(model: String, text: String, apiKey: String): String? =
        runCatching {
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            )
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 2500
                readTimeout = 3000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Connection", "keep-alive")
            }

            val payload = buildGeminiPayload(text)
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }

            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                conn.disconnect()
                return@runCatching null
            }

            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            extractGeminiText(body).takeIf { it.isNotBlank() }
        }.getOrNull()

    private fun buildGroqPayload(model: String, text: String): JSONObject {
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", CINEMA_SYSTEM_PROMPT))
            .put(JSONObject().put("role", "user").put("content", text))

        return JSONObject()
            .put("model", model)
            .put("temperature", 0.2)
            .put("max_tokens", 120)
            .put("messages", messages)
    }

    private fun extractGroqText(body: String): String {
        val raw = runCatching {
            JSONObject(body)
                .optJSONArray("choices")
                ?.optJSONObject(0)
                ?.optJSONObject("message")
                ?.optString("content", "")
                .orEmpty()
        }.getOrDefault("")
        return sanitizeSubtitleOutput(raw)
    }

    private suspend fun translateViaGroqFast(text: String, apiKey: String): String? =
        withContext(Dispatchers.IO) {
            val model = cachedGroqModel ?: discoverGroqModels(apiKey).firstOrNull()?.also {
                cachedGroqModel = it
            } ?: return@withContext null

            callGroqModel(model, text, apiKey)
        }

    private fun callGroqModel(model: String, text: String, apiKey: String): String? =
        runCatching {
            val url = URL("https://api.groq.com/openai/v1/chat/completions")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 2000
                readTimeout = 2500
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Authorization", "Bearer $apiKey")
                setRequestProperty("Connection", "keep-alive")
            }

            val payload = buildGroqPayload(model, text)
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }

            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                conn.disconnect()
                return@runCatching null
            }

            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            extractGroqText(body).takeIf { it.isNotBlank() }
        }.getOrNull()


    private fun discoverCerebrasModels(apiKey: String): List<String> {
        val discovered = mutableListOf<String>()
        runCatching {
            val url = URL("https://api.cerebras.ai/v1/models")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4000
                readTimeout = 4000
                setRequestProperty("Authorization", "Bearer $apiKey")
            }
            if (conn.responseCode == HttpURLConnection.HTTP_OK) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val data = JSONObject(body).optJSONArray("data")
                if (data != null) {
                    for (i in 0 until data.length()) {
                        val id = data.optJSONObject(i)?.optString("id", "").orEmpty()
                        if (id.isNotBlank()) discovered.add(id)
                    }
                }
            } else {
                conn.disconnect()
            }
        }

        val preferred = listOf("llama-3.3-70b", "qwen-3-32b", "llama3.1-8b", "llama-4-scout-17b-16e-instruct")
        val sorted = mutableListOf<String>()
        for (p in preferred) if (p in discovered) sorted.add(p)
        for (m in discovered) if (m !in sorted) sorted.add(m)
        if (sorted.isEmpty()) sorted.addAll(preferred)
        return sorted
    }

    private fun testCerebrasKey(apiKey: String): Pair<Boolean, String> {
        cachedCerebrasModel = null
        val candidates = discoverCerebrasModels(apiKey).take(5)
        var lastError = "فشل الاتصال بسيرفر Cerebras"

        for (model in candidates) {
            try {
                val url = URL("https://api.cerebras.ai/v1/chat/completions")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 5000
                    readTimeout = 6000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Authorization", "Bearer $apiKey")
                }

                val payload = buildGroqPayload(model, "It's a piece of cake, don't worry about it!")
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }

                val code = conn.responseCode
                if (code == HttpURLConnection.HTTP_OK) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    val text = extractGroqText(body)
                    if (text.isNotBlank()) {
                        cachedCerebrasModel = model
                        return Pair(true, "مفتاح Cerebras شغال بنجاح ($model)!\nتجربة: $text")
                    }
                } else {
                    val errBody = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    conn.disconnect()
                    val errMsg = runCatching {
                        JSONObject(errBody).optJSONObject("error")?.optString("message", "")
                    }.getOrNull().orEmpty()
                    if (code == 401) return Pair(false, "مفتاح Cerebras غير صحيح (401)")
                    lastError = when (code) {
                        429 -> "تم تجاوز حد الطلبات مؤقتاً (429)"
                        else -> "خطأ من Cerebras ($code): $errMsg"
                    }
                }
            } catch (e: Exception) {
                lastError = "خطأ في الاتصال: ${e.localizedMessage ?: "تأكد من الإنترنت"}"
            }
        }
        return Pair(false, lastError)
    }

    private suspend fun translateViaCerebrasFast(text: String, apiKey: String): String? =
        withContext(Dispatchers.IO) {
            val model = cachedCerebrasModel ?: discoverCerebrasModels(apiKey).firstOrNull()?.also {
                cachedCerebrasModel = it
            } ?: return@withContext null

            runCatching {
                val url = URL("https://api.cerebras.ai/v1/chat/completions")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 1800
                    readTimeout = 2200
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Authorization", "Bearer $apiKey")
                    setRequestProperty("Connection", "keep-alive")
                }

                val payload = buildGroqPayload(model, text)
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }

                if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                    conn.disconnect()
                    return@runCatching null
                }

                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                extractGroqText(body).takeIf { it.isNotBlank() }
            }.getOrNull()
        }

    private fun sanitizeSubtitleOutput(raw: String): String {
        // Strip thinking tags if any reasoning model outputs them, plus markdown/quotes
        val noThink = raw.replace(Regex("<think>[\\s\\S]*?</think>"), "")
        return noThink
            .replace("*", "")
            .replace("\r", "")
            .lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .take(2)
            .joinToString("\n")
            .trim('"', '\'', '«', '»', ' ')
    }

    private fun isAlreadyArabic(text: String): Boolean {
        var arabicCount = 0
        var letterCount = 0
        for (ch in text) {
            if (ch.isLetter()) {
                letterCount++
                if (ch in '\u0600'..'\u06FF') arabicCount++
            }
        }
        return letterCount > 0 && (arabicCount * 2 > letterCount)
    }

    private suspend fun translateViaGoogleFree(text: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            val encoded = URLEncoder.encode(text, "UTF-8")
            val urlStr =
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ar&dt=t&q=$encoded"
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 1500
                readTimeout = 1500
                setRequestProperty("User-Agent", "Mozilla/5.0")
            }
            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                conn.disconnect()
                return@runCatching null
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val root = JSONArray(body)
            val sentences = root.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                val part = sentences.getJSONArray(i).optString(0, "")
                sb.append(part)
            }
            sb.toString().trim()
        }.getOrNull()
    }

    fun close() {
        mlKitTranslator.close()
    }
}
