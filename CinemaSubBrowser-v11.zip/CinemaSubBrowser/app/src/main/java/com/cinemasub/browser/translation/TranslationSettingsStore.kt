package com.cinemasub.browser.translation

import android.content.Context
import com.cinemasub.browser.model.AiTranslationConfig
import com.cinemasub.browser.model.TranslationEngine

object TranslationSettingsStore {

    private const val PREFS_NAME = "cinemasub_ai_prefs"
    private const val KEY_ENGINE = "translation_engine"
    private const val KEY_GEMINI = "gemini_api_key"
    private const val KEY_GROQ = "groq_api_key"
    private const val KEY_CEREBRAS = "cerebras_api_key"
    private const val KEY_ADBLOCK = "adblock_enabled"
    private const val KEY_SYNC_OFFSET = "sync_offset_sec"

    @Volatile
    var currentConfig: AiTranslationConfig = AiTranslationConfig()
        private set

    @Volatile
    var isAdBlockerEnabled: Boolean = true
        private set

    @Volatile
    var syncOffsetSec: Float = 0f
        private set

    fun init(context: Context) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val engineName = prefs.getString(KEY_ENGINE, TranslationEngine.GOOGLE_FREE.name)
        val engine = runCatching { TranslationEngine.valueOf(engineName ?: "") }
            .getOrDefault(TranslationEngine.GOOGLE_FREE)
        val geminiKey = prefs.getString(KEY_GEMINI, "") ?: ""
        val groqKey = prefs.getString(KEY_GROQ, "") ?: ""
        val cerebrasKey = prefs.getString(KEY_CEREBRAS, "") ?: ""
        isAdBlockerEnabled = prefs.getBoolean(KEY_ADBLOCK, true)
        syncOffsetSec = prefs.getFloat(KEY_SYNC_OFFSET, 0f)
        currentConfig = AiTranslationConfig(
            engine = engine,
            geminiApiKey = geminiKey,
            groqApiKey = groqKey,
            cerebrasApiKey = cerebrasKey
        )
    }

    fun update(context: Context, config: AiTranslationConfig) {
        currentConfig = config
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_ENGINE, config.engine.name)
            .putString(KEY_GEMINI, config.geminiApiKey.trim())
            .putString(KEY_GROQ, config.groqApiKey.trim())
            .putString(KEY_CEREBRAS, config.cerebrasApiKey.trim())
            .apply()
    }

    fun setAdBlockerEnabled(context: Context, enabled: Boolean) {
        isAdBlockerEnabled = enabled
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_ADBLOCK, enabled).apply()
    }

    fun setSyncOffsetSec(context: Context, offsetSec: Float) {
        syncOffsetSec = offsetSec
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putFloat(KEY_SYNC_OFFSET, offsetSec).apply()
    }
}
