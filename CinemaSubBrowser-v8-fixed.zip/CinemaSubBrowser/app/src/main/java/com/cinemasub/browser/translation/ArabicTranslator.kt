package com.cinemasub.browser.translation

import com.cinemasub.browser.model.TranslationEngine
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Collections
import java.util.concurrent.atomic.AtomicBoolean

class ArabicTranslator {

    private val options = TranslatorOptions.Builder()
        .setSourceLanguage(TranslateLanguage.ENGLISH)
        .setTargetLanguage(TranslateLanguage.ARABIC)
        .build()

    private val mlKitTranslator: Translator = Translation.getClient(options)
    private val isOfflineReady = AtomicBoolean(false)

    private val cache: MutableMap<String, String> = Collections.synchronizedMap(
        object : LinkedHashMap<String, String>(520, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
                return size > 500
            }
        }
    )

    suspend fun ensureModelDownloaded() {
        if (isOfflineReady.get()) return
        runCatching {
            val conditions = DownloadConditions.Builder().build()
            mlKitTranslator.downloadModelIfNeeded(conditions).await()
            isOfflineReady.set(true)
        }
    }

    suspend fun testApiKey(engine: TranslationEngine, rawKey: String): Pair<Boolean, String> =
        withContext(Dispatchers.IO) {
            val apiKey = rawKey.trim()
            if (apiKey.isEmpty()) {
                return@withContext Pair(false, "من فضلك أدخل المفتاح أولاً قبل الاختبار.")
            }
            when (engine) {
                TranslationEngine.GEMINI_AI -> testGeminiKey(apiKey)
                TranslationEngine.GROQ_AI -> testGroqKey(apiKey)
                TranslationEngine.GOOGLE_FREE -> Pair(true, "ترجمة جوجل المجانية تعمل بدون مفتاح.")
            }
        }

    private fun testGeminiKey(apiKey: String): Pair<Boolean, String> {
        val models = listOf("gemini-2.0-flash-lite", "gemini-2.0-flash")
        var lastError = "فشل الاتصال بسيرفر Gemini"
        for (model in models) {
            try {
                val url = URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
                )
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 5000
                    readTimeout = 6000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                }

                val payload = JSONObject().apply {
                    put(
                        "contents",
                        JSONArray().put(
                            JSONObject().put(
                                "parts",
                                JSONArray().put(
                                    JSONObject().put("text", "Arabic movie subtitle only:\nIt's a piece of cake!")
                                )
                            )
                        )
                    )
                    put(
                        "generationConfig",
                        JSONObject().put("temperature", 0.1).put("maxOutputTokens", 50)
                    )
                }

                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }
                val code = conn.responseCode
                if (code == HttpURLConnection.HTTP_OK) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    val text = JSONObject(body)
                        .optJSONArray("candidates")
                        ?.optJSONObject(0)
                        ?.optJSONObject("content")
                        ?.optJSONArray("parts")
                        ?.optJSONObject(0)
                        ?.optString("text", "")
                        ?.trim()
                        .orEmpty()
                    return Pair(true, "المفتاح شغال بنجاح ($model)!\nتجربة: $text")
                } else {
                    val errBody = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    conn.disconnect()
                    val errMsg = runCatching {
                        JSONObject(errBody).optJSONObject("error")?.optString("message", "")
                    }.getOrNull().orEmpty()
                    lastError = when (code) {
                        400 -> "المفتاح غير صالح (400): $errMsg"
                        403 -> "المفتاح مرفوض أو غير مفعّل (403): $errMsg"
                        404 -> "الموديل $model غير متاح (404)"
                        429 -> "تم استهلاك الحد المجاني مؤقتاً (429): $errMsg"
                        else -> "خطأ من السيرفر ($code): $errMsg"
                    }
                }
            } catch (e: Exception) {
                lastError = "خطأ في الاتصال: ${e.localizedMessage ?: "تأكد من الإنترنت"}"
            }
        }
        return Pair(false, lastError)
    }

    private fun testGroqKey(apiKey: String): Pair<Boolean, String> {
        return try {
            val url = URL("https://api.groq.com/openai/v1/chat/completions")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 5000
                readTimeout = 6000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Authorization", "Bearer $apiKey")
            }

            val messages = JSONArray()
                .put(JSONObject().put("role", "system").put("content", "Translate to natural Arabic movie subtitle. Arabic text only."))
                .put(JSONObject().put("role", "user").put("content", "It's a piece of cake!"))

            val payload = JSONObject()
                .put("model", "llama-3.1-8b-instant")
                .put("temperature", 0.1)
                .put("max_tokens", 50)
                .put("messages", messages)

            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }
            val code = conn.responseCode
            if (code == HttpURLConnection.HTTP_OK) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val text = JSONObject(body)
                    .optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
                    ?.optString("content", "")
                    ?.trim()
                    .orEmpty()
                Pair(true, "مفتاح Groq شغال بنجاح!\nتجربة: $text")
            } else {
                val errBody = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                conn.disconnect()
                val errMsg = runCatching {
                    JSONObject(errBody).optJSONObject("error")?.optString("message", "")
                }.getOrNull().orEmpty()
                val friendly = when (code) {
                    401 -> "مفتاح Groq غير صحيح (401)"
                    429 -> "تم تجاوز حد الطلبات مؤقتاً (429)"
                    else -> "خطأ من Groq ($code): $errMsg"
                }
                Pair(false, friendly)
            }
        } catch (e: Exception) {
            Pair(false, "خطأ في الاتصال: ${e.localizedMessage ?: "تأكد من الإنترنت"}")
        }
    }

    suspend fun preloadToCache(sourceText: String) {
        val cleaned = sourceText.trim()
        if (cleaned.isEmpty() || isAlreadyArabic(cleaned)) return
        val config = TranslationSettingsStore.currentConfig
        val cacheKey = "${config.engine.name}|$cleaned"
        if (cache.containsKey(cacheKey)) return
        translateToArabic(cleaned)
    }

    suspend fun translateToArabic(sourceText: String): String {
        val cleaned = sourceText.trim()
        if (cleaned.isEmpty()) return ""
        if (isAlreadyArabic(cleaned)) return cleaned

        val config = TranslationSettingsStore.currentConfig
        val cacheKey = "${config.engine.name}|$cleaned"
        cache[cacheKey]?.let { return it }

        val aiResult: String? = when (config.engine) {
            TranslationEngine.GEMINI_AI -> {
                if (config.geminiApiKey.isNotBlank()) {
                    translateViaGeminiFast(cleaned, config.geminiApiKey.trim())
                } else null
            }
            TranslationEngine.GROQ_AI -> {
                if (config.groqApiKey.isNotBlank()) {
                    translateViaGroqFast(cleaned, config.groqApiKey.trim())
                } else null
            }
            TranslationEngine.GOOGLE_FREE -> null
        }

        if (!aiResult.isNullOrBlank()) {
            cache[cacheKey] = aiResult
            return aiResult
        }

        val onlineResult = translateViaGoogleFree(cleaned)
        if (!onlineResult.isNullOrBlank()) {
            cache[cacheKey] = onlineResult
            return onlineResult
        }

        if (!isOfflineReady.get()) ensureModelDownloaded()
        val offlineResult = runCatching {
            mlKitTranslator.translate(cleaned).await()
        }.getOrDefault("")

        if (offlineResult.isNotBlank()) {
            cache[cacheKey] = offlineResult
        }
        return offlineResult
    }

    private suspend fun translateViaGeminiFast(text: String, apiKey: String): String? =
        withContext(Dispatchers.IO) {
            callGeminiModel("gemini-2.0-flash-lite", text, apiKey)
                ?: callGeminiModel("gemini-2.0-flash", text, apiKey)
        }

    private fun callGeminiModel(model: String, text: String, apiKey: String): String? =
        runCatching {
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            )
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 2500
                readTimeout = 3000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Connection", "keep-alive")
            }

            val prompt = "Arabic movie subtitle only:\n$text"

            val payload = JSONObject().apply {
                put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", prompt))
                        )
                    )
                )
                put(
                    "generationConfig",
                    JSONObject()
                        .put("temperature", 0.1)
                        .put("maxOutputTokens", 80)
                )
            }

            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }

            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                conn.disconnect()
                return@runCatching null
            }

            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val root = JSONObject(body)
            val candidates = root.optJSONArray("candidates") ?: return@runCatching null
            val parts = candidates.getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
            parts.getJSONObject(0).optString("text", "").trim().trim('"')
        }.getOrNull()

    private suspend fun translateViaGroqFast(text: String, apiKey: String): String? =
        withContext(Dispatchers.IO) {
            runCatching {
                val url = URL("https://api.groq.com/openai/v1/chat/completions")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 2000
                    readTimeout = 2500
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Authorization", "Bearer $apiKey")
                    setRequestProperty("Connection", "keep-alive")
                }

                val messages = JSONArray()
                    .put(
                        JSONObject()
                            .put("role", "system")
                            .put("content", "Translate to natural Arabic movie subtitle. Arabic text only.")
                    )
                    .put(
                        JSONObject()
                            .put("role", "user")
                            .put("content", text)
                    )

                val payload = JSONObject()
                    .put("model", "llama-3.1-8b-instant")
                    .put("temperature", 0.1)
                    .put("max_tokens", 80)
                    .put("messages", messages)

                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }

                if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                    conn.disconnect()
                    return@runCatching null
                }

                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()

                val root = JSONObject(body)
                val choices = root.optJSONArray("choices") ?: return@runCatching null
                choices.getJSONObject(0)
                    .getJSONObject("message")
                    .optString("content", "")
                    .trim()
                    .trim('"')
            }.getOrNull()
        }

    private fun isAlreadyArabic(text: String): Boolean {
        var arabicCount = 0
        var letterCount = 0
        for (ch in text) {
            if (ch.isLetter()) {
                letterCount++
                if (ch in '\u0600'..'\u06FF') arabicCount++
            }
        }
        return letterCount > 0 && (arabicCount * 2 > letterCount)
    }

    private suspend fun translateViaGoogleFree(text: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            val encoded = URLEncoder.encode(text, "UTF-8")
            val urlStr =
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ar&dt=t&q=$encoded"
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 1500
                readTimeout = 1500
                setRequestProperty("User-Agent", "Mozilla/5.0")
            }
            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                conn.disconnect()
                return@runCatching null
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val root = JSONArray(body)
            val sentences = root.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                val part = sentences.getJSONArray(i).optString(0, "")
                sb.append(part)
            }
            sb.toString().trim()
        }.getOrNull()
    }

    fun close() {
        mlKitTranslator.close()
    }
}
