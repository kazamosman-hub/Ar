package com.cinemasub.browser.browser

import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import com.cinemasub.browser.translation.ArabicTranslator
import com.cinemasub.browser.translation.TranslationSettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Collections

object NetworkSubtitleInterceptor {

    private const val MAX_DISK_CACHE_FILES = 25

    private val translatedFileCache: MutableMap<String, ByteArray> = Collections.synchronizedMap(
        object : LinkedHashMap<String, ByteArray>(20, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ByteArray>?): Boolean {
                return size > 15
            }
        }
    )

    private val timestampLineRegex = Regex(
        """^\s*\d{1,2}:\d{2}(?::\d{2})?[.,]\d{3}\s*-->\s*\d{1,2}:\d{2}(?::\d{2})?[.,]\d{3}.*$"""
    )

    private val sdhBracketRegex = Regex("""\[[^\]]*]|\([^)]*\)|♪[^♪]*♪|♪|♫""")

    fun isSubtitleUrl(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val lower = url.lowercase()
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) return false
        val path = runCatching { Uri.parse(lower).path.orEmpty() }.getOrDefault(lower)
        if (path.endsWith(".vtt") || path.endsWith(".srt") ||
            lower.contains(".vtt?") || lower.contains(".srt?")
        ) {
            return true
        }
        // Support timedtext endpoints explicitly returning VTT or SRT
        if (lower.contains("timedtext") && (lower.contains("fmt=vtt") || lower.contains("fmt=srt"))) {
            return true
        }
        return false
    }

    fun interceptAndTranslate(
        context: Context,
        request: WebResourceRequest,
        translator: ArabicTranslator
    ): WebResourceResponse? {
        val urlStr = request.url?.toString() ?: return null
        val config = TranslationSettingsStore.currentConfig
        val dual = TranslationSettingsStore.dualSubtitlesEnabled
        val cacheKey = "${config.engine.name}|${config.dialect.name}|$dual|$urlStr"

        val isVtt = urlStr.lowercase().contains("vtt")
        val mime = if (isVtt) "text/vtt" else "text/plain"

        // 1. Check fast RAM cache
        translatedFileCache[cacheKey]?.let { cachedBytes ->
            return buildCorsResponse(mime, cachedBytes)
        }

        // 2. Check persistent Disk cache (0ms instant load when returning to a movie!)
        readDiskCache(context, cacheKey)?.let { diskBytes ->
            translatedFileCache[cacheKey] = diskBytes
            return buildCorsResponse(mime, diskBytes)
        }

        val originalText = fetchOriginalSubtitle(urlStr, request.requestHeaders) ?: return null
        if (originalText.isBlank() || isMostlyArabic(originalText)) {
            return buildCorsResponse(mime, originalText.toByteArray(Charsets.UTF_8))
        }

        val translatedText = runBlocking(Dispatchers.IO) {
            translateSubtitleDocument(originalText, translator, dual)
        }

        val bytes = translatedText.toByteArray(Charsets.UTF_8)
        translatedFileCache[cacheKey] = bytes
        writeDiskCache(context, cacheKey, bytes)
        return buildCorsResponse(mime, bytes)
    }

    private fun cleanSdhText(raw: String): String {
        return raw
            .replace(Regex("<[^>]*>"), "")
            .replace(sdhBracketRegex, " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun fetchOriginalSubtitle(urlStr: String, headers: Map<String, String>?): String? =
        runCatching {
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 7000
                instanceFollowRedirects = true
                headers?.forEach { (k, v) ->
                    if (!k.equals("Accept-Encoding", ignoreCase = true)) {
                        setRequestProperty(k, v)
                    }
                }
                val cookie = runCatching { CookieManager.getInstance().getCookie(urlStr) }.getOrNull()
                if (!cookie.isNullOrBlank() && headers?.keys?.none { it.equals("Cookie", true) } == true) {
                    setRequestProperty("Cookie", cookie)
                }
            }
            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                conn.disconnect()
                return@runCatching null
            }
            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            conn.disconnect()
            text
        }.getOrNull()

    private data class CueBlock(
        val headerLines: List<String>,
        val textLines: List<String>
    )

    private suspend fun translateSubtitleDocument(
        rawContent: String,
        translator: ArabicTranslator,
        dualSubtitles: Boolean
    ): String {
        val normalized = rawContent.replace("\r\n", "\n").replace("\r", "\n")
        val rawBlocks = normalized.split(Regex("\n{2,}"))
        val parsedBlocks = mutableListOf<Any>() // String (raw header/note) or CueBlock
        val cueIndices = mutableListOf<Int>()
        val cueTexts = mutableListOf<String>()

        for (block in rawBlocks) {
            val lines = block.lines()
            val tsIdx = lines.indexOfFirst { timestampLineRegex.matches(it) }
            if (tsIdx != -1 && tsIdx < lines.lastIndex) {
                val header = lines.subList(0, tsIdx + 1)
                val bodyLines = lines.subList(tsIdx + 1, lines.size)
                val cleanBody = cleanSdhText(bodyLines.joinToString(" "))
                if (cleanBody.isNotEmpty()) {
                    cueIndices.add(parsedBlocks.size)
                    cueTexts.add(cleanBody)
                    parsedBlocks.add(CueBlock(header, bodyLines))
                }
                // Pure SDH sound-effect cues (like [music playing]) are silently dropped!
            } else {
                parsedBlocks.add(block)
            }
        }

        if (cueTexts.isEmpty()) return rawContent

        // High-throughput parallel batching (24 cues x 5 concurrent) with per-batch timeout guard
        val batchSize = 24
        val semaphore = Semaphore(5)
        val translatedMap = Collections.synchronizedMap(mutableMapOf<Int, String>())

        coroutineScope {
            val jobs = cueTexts.chunked(batchSize).mapIndexed { batchIdx, chunk ->
                async(Dispatchers.IO) {
                    semaphore.withPermit {
                        val res = withTimeoutOrNull(8500L) {
                            translator.translateBatchForSubtitleFile(chunk)
                        }
                        if (res != null) {
                            val offset = batchIdx * batchSize
                            for ((localI, ar) in res) {
                                translatedMap[offset + localI] = ar
                            }
                        }
                    }
                }
            }
            jobs.awaitAll()
        }

        val out = StringBuilder()
        var cueCounter = 0
        for (i in parsedBlocks.indices) {
            if (i > 0) out.append("\n\n")
            val item = parsedBlocks[i]
            if (item is String) {
                out.append(item)
            } else if (item is CueBlock) {
                out.append(item.headerLines.joinToString("\n"))
                out.append("\n")
                val isTranslatedSlot = cueIndices.getOrNull(cueCounter) == i
                if (isTranslatedSlot) {
                    val originalClean = cueTexts[cueCounter]
                    val arabic = translatedMap[cueCounter] ?: originalClean
                    if (dualSubtitles && arabic != originalClean) {
                        out.append(originalClean).append("\n").append(arabic)
                    } else {
                        out.append(arabic)
                    }
                    cueCounter++
                } else {
                    out.append(item.textLines.joinToString("\n"))
                }
            }
        }
        return out.toString()
    }

    private fun cacheFileFor(context: Context, key: String): File {
        val dir = File(context.cacheDir, "translated_subs").apply { mkdirs() }
        val hash = MessageDigest.getInstance("SHA-256")
            .digest(key.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
            .take(24)
        return File(dir, "$hash.sub")
    }

    private fun readDiskCache(context: Context, key: String): ByteArray? = runCatching {
        val file = cacheFileFor(context, key)
        if (file.exists() && file.length() > 0L) {
            file.setLastModified(System.currentTimeMillis())
            file.readBytes()
        } else null
    }.getOrNull()

    private fun writeDiskCache(context: Context, key: String, bytes: ByteArray) {
        runCatching {
            val file = cacheFileFor(context, key)
            file.writeBytes(bytes)
            val dir = file.parentFile ?: return
            val all = dir.listFiles()?.sortedByDescending { it.lastModified() } ?: return
            if (all.size > MAX_DISK_CACHE_FILES) {
                all.drop(MAX_DISK_CACHE_FILES).forEach { it.delete() }
            }
        }
    }

    private fun isMostlyArabic(text: String): Boolean {
        var arabic = 0
        var letters = 0
        val sample = text.take(1500)
        for (ch in sample) {
            if (ch.isLetter()) {
                letters++
                if (ch in '\u0600'..'\u06FF') arabic++
            }
        }
        return letters > 20 && (arabic * 100 / letters) >= 40
    }

    private fun buildCorsResponse(mime: String, bytes: ByteArray): WebResourceResponse {
        val headers = mapOf(
            "Access-Control-Allow-Origin" to "*",
            "Access-Control-Allow-Methods" to "GET, OPTIONS",
            "Access-Control-Allow-Headers" to "*",
            "Cache-Control" to "no-cache"
        )
        return WebResourceResponse(
            mime,
            "UTF-8",
            200,
            "OK",
            headers,
            ByteArrayInputStream(bytes)
        )
    }
}
