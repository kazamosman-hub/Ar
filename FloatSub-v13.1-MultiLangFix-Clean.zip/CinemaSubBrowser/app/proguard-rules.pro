-keep class org.vosk.** { *; }
-keep class com.sun.jna.** { *; }
-keep class com.google.mlkit.** { *; }
-keepclassmembers class com.cinemasub.browser.browser.CaptionJsBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-dontwarn androidx.media3.**
