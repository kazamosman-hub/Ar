package com.floatsub.app.audio

import android.media.MediaCodec
import android.media.MediaFormat
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicInteger

class OpusOggStreamEncoder private constructor(
    private val codec: MediaCodec,
    private val sampleRate: Int,
    private val channelCount: Int
) {
    companion object {
        private val OGG_CRC_TABLE = IntArray(256) { i ->
            var r = i shl 24
            for (bit in 0 until 8) {
                r = if ((r and 0x80000000.toInt()) != 0) {
                    (r shl 1) xor 0x04C11DB7
                } else {
                    r shl 1
                }
            }
            r
        }

        private val serialCounter = AtomicInteger(0x46535501)

        fun tryCreate(
            sampleRate: Int = 16000,
            channelCount: Int = 1,
            bitRate: Int = 24000
        ): OpusOggStreamEncoder? {
            var codec: MediaCodec? = null
            return try {
                val format = MediaFormat.createAudioFormat(
                    MediaFormat.MIMETYPE_AUDIO_OPUS,
                    sampleRate,
                    channelCount
                ).apply {
                    setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
                    setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                }
                codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_OPUS)
                codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                codec.start()
                OpusOggStreamEncoder(codec, sampleRate, channelCount)
            } catch (_: Exception) {
                runCatching { codec?.release() }
                null
            }
        }
    }

    private val bufferInfo = MediaCodec.BufferInfo()
    private var inputPtsUs: Long = 0L
    private var serialNumber: Int = serialCounter.getAndIncrement()
    private var pageSeq: Int = 0
    private var granulePos: Long = 0L
    private val stateLock = Any()

    /**
     * Generates fresh RFC 7845 Ogg/Opus header pages (OpusHead + OpusTags).
     * Must be sent once at the start of every new WebSocket connection.
     */
    fun resetAndBuildHeaders(): ByteArray = synchronized(stateLock) {
        serialNumber = serialCounter.getAndIncrement()
        pageSeq = 0
        granulePos = 0L

        val opusHead = ByteBuffer.allocate(19).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("OpusHead".toByteArray(Charsets.US_ASCII))
            put(1.toByte())                  // Version
            put(channelCount.toByte())       // Channel count
            putShort(312.toShort())          // Pre-skip (48kHz units)
            putInt(sampleRate)               // Input sample rate
            putShort(0.toShort())            // Output gain
            put(0.toByte())                  // Channel mapping family
        }.array()

        val vendor = "FloatSub".toByteArray(Charsets.US_ASCII)
        val opusTags = ByteBuffer.allocate(8 + 4 + vendor.size + 4).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("OpusTags".toByteArray(Charsets.US_ASCII))
            putInt(vendor.size)
            put(vendor)
            putInt(0)                        // 0 user comments
        }.array()

        val out = ByteArrayOutputStream(128)
        out.write(buildOggPage(listOf(opusHead), headerType = 0x02, granule = 0L, seq = pageSeq++))
        out.write(buildOggPage(listOf(opusTags), headerType = 0x00, granule = 0L, seq = pageSeq++))
        out.toByteArray()
    }

    /**
     * Encodes raw 16-bit PCM mono bytes into one Ogg page containing the resulting Opus packets.
     * Returns null if encoder is still buffering or on transient error.
     */
    fun encodePcmToOggPage(pcmBytes: ByteArray, length: Int): ByteArray? = synchronized(stateLock) {
        if (length <= 0) return null
        val packets = mutableListOf<ByteArray>()
        var offset = 0

        try {
            while (offset < length) {
                val inIdx = codec.dequeueInputBuffer(15_000L)
                if (inIdx >= 0) {
                    val inBuf = codec.getInputBuffer(inIdx)
                    if (inBuf != null) {
                        inBuf.clear()
                        val toWrite = minOf(inBuf.remaining(), length - offset)
                        inBuf.put(pcmBytes, offset, toWrite)
                        val samplesCount = toWrite / (2 * channelCount)
                        codec.queueInputBuffer(inIdx, 0, toWrite, inputPtsUs, 0)
                        inputPtsUs += (samplesCount * 1_000_000L) / sampleRate
                        offset += toWrite
                    }
                }
                drainOutputPackets(packets)
                if (inIdx < 0) break
            }
            drainOutputPackets(packets)
        } catch (_: Exception) {
            return null
        }

        if (packets.isEmpty()) return null
        for (pkt in packets) {
            granulePos += opusPacketGranuleSamples48k(pkt)
        }
        return buildOggPage(packets, headerType = 0x00, granule = granulePos, seq = pageSeq++)
    }

    private fun drainOutputPackets(outList: MutableList<ByteArray>) {
        while (true) {
            val outIdx = codec.dequeueOutputBuffer(bufferInfo, 0L)
            if (outIdx < 0) break
            try {
                val isConfig = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                if (!isConfig && bufferInfo.size > 0) {
                    val outBuf = codec.getOutputBuffer(outIdx)
                    if (outBuf != null) {
                        outBuf.position(bufferInfo.offset)
                        outBuf.limit(bufferInfo.offset + bufferInfo.size)
                        val packet = ByteArray(bufferInfo.size)
                        outBuf.get(packet)
                        // Guard against Android's AOPUSHDR wrapper if emitted without CONFIG flag
                        val isAopusHeader = packet.size >= 8 &&
                            packet[0] == 'A'.code.toByte() &&
                            packet[1] == 'O'.code.toByte() &&
                            packet[2] == 'P'.code.toByte() &&
                            packet[3] == 'U'.code.toByte()
                        if (!isAopusHeader) {
                            outList.add(packet)
                        }
                    }
                }
            } finally {
                codec.releaseOutputBuffer(outIdx, false)
            }
        }
    }

    // Computes exact 48kHz granule duration from Opus TOC byte (RFC 6716 Section 3.1)
    private fun opusPacketGranuleSamples48k(packet: ByteArray): Long {
        if (packet.isEmpty()) return 960L
        val toc = packet[0].toInt() and 0xFF
        val config = (toc shr 3) and 0x1F
        val frameSize48k = when {
            config < 12 -> when (config and 0x03) {
                0 -> 480L   // 10ms
                1 -> 960L   // 20ms
                2 -> 1920L  // 40ms
                else -> 2880L // 60ms
            }
            config < 16 -> if ((config and 0x01) == 0) 480L else 960L
            else -> when (config and 0x03) {
                0 -> 120L   // 2.5ms
                1 -> 240L   // 5ms
                2 -> 480L   // 10ms
                else -> 960L // 20ms
            }
        }
        val frameCount = when (toc and 0x03) {
            0 -> 1L
            1, 2 -> 2L
            else -> if (packet.size > 1) (packet[1].toInt() and 0x3F).coerceAtLeast(1).toLong() else 1L
        }
        return frameSize48k * frameCount
    }

    private fun buildOggPage(
        packets: List<ByteArray>,
        headerType: Int,
        granule: Long,
        seq: Int
    ): ByteArray {
        val lacing = ByteArrayOutputStream(packets.size * 2)
        var payloadSize = 0
        for (pkt in packets) {
            payloadSize += pkt.size
            var rem = pkt.size
            while (rem >= 255) {
                lacing.write(255)
                rem -= 255
            }
            lacing.write(rem)
        }
        val lacingBytes = lacing.toByteArray()
        val pageSize = 27 + lacingBytes.size + payloadSize
        val buf = ByteBuffer.allocate(pageSize).order(ByteOrder.LITTLE_ENDIAN)

        buf.put("OggS".toByteArray(Charsets.US_ASCII)) // 0..3
        buf.put(0.toByte())                            // 4: version
        buf.put(headerType.toByte())                   // 5: header type
        buf.putLong(granule)                           // 6..13: granule position
        buf.putInt(serialNumber)                       // 14..17: bitstream serial
        buf.putInt(seq)                                // 18..21: page sequence
        buf.putInt(0)                                  // 22..25: CRC placeholder
        buf.put(lacingBytes.size.toByte())             // 26: segment count
        buf.put(lacingBytes)                           // 27..: segment table
        for (pkt in packets) {
            buf.put(pkt)
        }

        val page = buf.array()
        val crc = computeOggCrc(page)
        page[22] = (crc and 0xFF).toByte()
        page[23] = ((crc ushr 8) and 0xFF).toByte()
        page[24] = ((crc ushr 16) and 0xFF).toByte()
        page[25] = ((crc ushr 24) and 0xFF).toByte()
        return page
    }

    private fun computeOggCrc(data: ByteArray): Int {
        var crc = 0
        for (b in data) {
            val idx = ((crc ushr 24) xor (b.toInt() and 0xFF)) and 0xFF
            crc = (crc shl 8) xor OGG_CRC_TABLE[idx]
        }
        return crc
    }

    fun release() = synchronized(stateLock) {
        runCatching { codec.stop() }
        runCatching { codec.release() }
    }
}
