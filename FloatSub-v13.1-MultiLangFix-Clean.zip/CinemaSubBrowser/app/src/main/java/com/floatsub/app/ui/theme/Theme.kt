package com.floatsub.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val FloatSubDarkColors = darkColorScheme(
    primary = Color(0xFFE50914),
    onPrimary = Color.White,
    secondary = Color(0xFF22C55E),
    background = Color(0xFF0B0B0E),
    surface = Color(0xFF141419),
    surfaceVariant = Color(0xFF1E1E26),
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun FloatSubTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = FloatSubDarkColors,
        content = content
    )
}
