package com.floatsub.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.floatsub.app.model.DeepgramLanguage
import com.floatsub.app.model.PipelineStatus
import com.floatsub.app.model.SubtitleBgOpacity
import com.floatsub.app.model.SubtitleFontSize
import com.floatsub.app.model.SubtitleTextColor
import com.floatsub.app.model.TranslationEngine

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FloatSubScreen(
    viewModel: FloatSubViewModel,
    hasOverlayPermission: Boolean,
    hasAudioPermission: Boolean,
    onRequestOverlayPermission: () -> Unit,
    onRequestAudioPermission: () -> Unit,
    onStartFloating: () -> Unit,
    onStopFloating: () -> Unit
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val subState by viewModel.subtitleState.collectAsStateWithLifecycle()
    var selectedTab by remember { mutableIntStateOf(0) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0B0B0E))
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // App Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFE50914)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Subtitles,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "FloatSub",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = "ترجمة عائمة فورية فوق أي تطبيق",
                            fontSize = 12.sp,
                            color = Color(0xFF9CA3AF)
                        )
                    }
                }

                // Live Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (subState.isLiveEnabled) Color(0x3322C55E) else Color(0xFF1C1C22))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (subState.isLiveEnabled) Color(0xFF22C55E) else Color(0xFF71717A))
                        )
                        Text(
                            text = if (subState.isLiveEnabled) "نشط الآن" else "متوقف",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (subState.isLiveEnabled) Color(0xFF4ADE80) else Color(0xFFA1A1AA)
                        )
                    }
                }
            }

            // Permissions Card (shown only if something is missing)
            if (!hasOverlayPermission || !hasAudioPermission) {
                CardBox(
                    title = "الأذونات المطلوبة للتشغيل",
                    icon = Icons.Default.Layers,
                    accent = Color(0xFFF59E0B)
                ) {
                    PermissionRow(
                        label = "الظهور فوق التطبيقات الأخرى",
                        granted = hasOverlayPermission,
                        onGrant = onRequestOverlayPermission
                    )
                    PermissionRow(
                        label = "إذن التقاط صوت النظام",
                        granted = hasAudioPermission,
                        onGrant = onRequestAudioPermission
                    )
                }
            }

            // Hero Launch Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xFF16161C))
                    .border(
                        1.dp,
                        if (subState.isLiveEnabled) Color(0xFF22C55E) else Color(0xFF27272E),
                        RoundedCornerShape(18.dp)
                    )
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val statusMsg = when (val st = subState.status) {
                    is PipelineStatus.DownloadingModels -> st.messageAr
                    is PipelineStatus.Error -> st.messageAr
                    is PipelineStatus.Listening -> "الترجمة العائمة تعمل الآن — افتح يوتيوب أو تيليجرام أو أي فيديو!"
                    PipelineStatus.Idle -> "اضغط تشغيل، ثم افتح أي تطبيق (يوتيوب، تيليجرام، كروم، كورسات) وستظهر الترجمة فوق الفيديو فوراً."
                }
                Text(
                    text = statusMsg,
                    fontSize = 12.sp,
                    color = when (subState.status) {
                        is PipelineStatus.Error -> Color(0xFFFCA5A5)
                        is PipelineStatus.Listening -> Color(0xFF86EFAC)
                        else -> Color(0xFFD4D4D8)
                    }
                )

                Button(
                    onClick = {
                        if (subState.isLiveEnabled) onStopFloating() else onStartFloating()
                    },
                    enabled = hasOverlayPermission && hasAudioPermission,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (subState.isLiveEnabled) Color(0xFFDC2626) else Color(0xFF16A34A),
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = if (subState.isLiveEnabled) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = if (subState.isLiveEnabled) "إيقاف الترجمة العائمة" else "تشغيل الترجمة العائمة الآن",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "تلميح: اضغط على الدائرة العائمة (AR) لإظهار أزرار الإيقاف المؤقت ⏸ أو المسح الفوري ⌫ أو تحريك المكان ✥ أو الإغلاق ✕.",
                    fontSize = 11.sp,
                    color = Color(0xFF9CA3AF)
                )
            }

            // 2-Tab Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF18181E))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                TabPill(
                    label = "الذكاء AI والصوت",
                    icon = Icons.Default.AutoAwesome,
                    selected = selectedTab == 0,
                    modifier = Modifier.weight(1f)
                ) { selectedTab = 0 }
                TabPill(
                    label = "مظهر الترجمة",
                    icon = Icons.Default.Tune,
                    selected = selectedTab == 1,
                    modifier = Modifier.weight(1f)
                ) { selectedTab = 1 }
            }

            if (selectedTab == 0) {
                // Deepgram Speech-to-Text Card
                CardBox(
                    title = "محرك الصوت المباشر (Deepgram)",
                    icon = Icons.Default.Bolt,
                    accent = Color(0xFF22C55E)
                ) {
                    Text(
                        text = "أضف مفتاح Deepgram للحصول على أسرع وأدق تفريغ صوت لحظي (مجاني $200 بدون فيزا). بدونه سيعمل التطبيق أوفلاين عبر Vosk.",
                        fontSize = 12.sp,
                        color = Color(0xFF9CA3AF)
                    )
                    OutlinedTextField(
                        value = uiState.aiConfig.deepgramApiKey,
                        onValueChange = { viewModel.updateDeepgramKey(context, it) },
                        label = { Text("مفتاح Deepgram (console.deepgram.com)") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    ) {
                        DeepgramLanguage.entries.forEach { lang ->
                            FilterChip(
                                selected = uiState.aiConfig.deepgramLanguage == lang,
                                onClick = { viewModel.updateDeepgramLanguage(context, lang) },
                                label = { Text(lang.labelAr, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF16A34A),
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                    Text(
                        text = "لأفضل نتيجة في الألماني والإيطالي والفرنسي والإسباني والمكسيكي والياباني: اختر اللغة مباشرة من القائمة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF1F1F27))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "ضغط الصوت Opus (توفير 85% من الباقة)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                            Text(
                                text = "يقلل الاستهلاك من 230MB إلى ~25MB في الساعتين بدون تأخير",
                                fontSize = 11.sp,
                                color = Color(0xFF4ADE80)
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Switch(
                            checked = uiState.aiConfig.opusCompressionEnabled,
                            onCheckedChange = { viewModel.updateOpusCompression(context, it) }
                        )
                    }

                    Button(
                        onClick = { viewModel.testDeepgramKey() },
                        enabled = !uiState.isTestingDeepgramKey,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF27272A))
                    ) {
                        if (uiState.isTestingDeepgramKey) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                        } else {
                            Text("اختبار مفتاح Deepgram", color = Color.White)
                        }
                    }
                    uiState.deepgramTestResult?.let { (ok, msg) -> ResultBanner(ok, msg) }
                }

                // AI Translation Engines Card
                CardBox(
                    title = "محرك الترجمة بالذكاء الاصطناعي",
                    icon = Icons.Default.AutoAwesome,
                    accent = Color(0xFFA855F7)
                ) {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        TranslationEngine.entries.forEach { engine ->
                            FilterChip(
                                selected = uiState.aiConfig.engine == engine,
                                onClick = { viewModel.updateEngine(context, engine) },
                                label = { Text(engine.labelAr, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFE50914),
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    if (uiState.aiConfig.engine == TranslationEngine.GEMINI_AI || uiState.aiConfig.engine == TranslationEngine.AUTO_HYBRID) {
                        OutlinedTextField(
                            value = uiState.aiConfig.geminiApiKey,
                            onValueChange = { viewModel.updateGeminiKey(context, it) },
                            label = { Text("مفتاح Gemini AI (aistudio.google.com)") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (uiState.aiConfig.engine == TranslationEngine.GROQ_AI || uiState.aiConfig.engine == TranslationEngine.AUTO_HYBRID) {
                        OutlinedTextField(
                            value = uiState.aiConfig.groqApiKey,
                            onValueChange = { viewModel.updateGroqKey(context, it) },
                            label = { Text("مفتاح Groq AI (console.groq.com)") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (uiState.aiConfig.engine != TranslationEngine.GOOGLE_FREE) {
                        Button(
                            onClick = { viewModel.testAiKeys() },
                            enabled = !uiState.isTestingApiKey,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF27272A))
                        ) {
                            if (uiState.isTestingApiKey) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                            } else {
                                Text("اختبار مفاتيح الذكاء الاصطناعي", color = Color.White)
                            }
                        }
                        uiState.apiKeyTestResult?.let { (ok, msg) -> ResultBanner(ok, msg) }
                    }
                }
            } else {
                // Live Preview Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF050507))
                        .border(1.dp, Color(0xFF27272A), RoundedCornerShape(14.dp))
                        .padding(vertical = 22.dp, horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(uiState.styleConfig.bgOpacity.color)
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                    ) {
                        Text(
                            text = "هكذا ستظهر الترجمة العائمة فوق الفيديوهات",
                            color = uiState.styleConfig.textColor.color,
                            fontSize = uiState.styleConfig.fontSize.sp.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                CardBox(
                    title = "تخصيص الخط والخلفية",
                    icon = Icons.Default.Tune,
                    accent = Color(0xFFF5C518)
                ) {
                    Text("حجم الخط", fontSize = 12.sp, color = Color(0xFFD4D4D8))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SubtitleFontSize.entries.forEach { sz ->
                            FilterChip(
                                selected = uiState.styleConfig.fontSize == sz,
                                onClick = { viewModel.updateFontSize(context, sz) },
                                label = { Text(sz.labelAr, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFE50914),
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Text("لون النص", fontSize = 12.sp, color = Color(0xFFD4D4D8))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SubtitleTextColor.entries.forEach { clr ->
                            FilterChip(
                                selected = uiState.styleConfig.textColor == clr,
                                onClick = { viewModel.updateTextColor(context, clr) },
                                label = { Text(clr.labelAr, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFE50914),
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Text("خلفية الترجمة", fontSize = 12.sp, color = Color(0xFFD4D4D8))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SubtitleBgOpacity.entries.forEach { bg ->
                            FilterChip(
                                selected = uiState.styleConfig.bgOpacity == bg,
                                onClick = { viewModel.updateBgOpacity(context, bg) },
                                label = { Text(bg.labelAr, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFE50914),
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = { viewModel.resetOverlayPosition(context) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إعادة ضبط مكان الترجمة للوضع الافتراضي", color = Color(0xFFD4D4D8))
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun PermissionRow(label: String, granted: Boolean, onGrant: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = if (granted) Icons.Default.CheckCircle else Icons.Default.Warning,
                contentDescription = null,
                tint = if (granted) Color(0xFF4ADE80) else Color(0xFFF59E0B),
                modifier = Modifier.size(18.dp)
            )
            Text(text = label, fontSize = 13.sp, color = Color.White)
        }
        if (!granted) {
            Button(
                onClick = onGrant,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE50914))
            ) {
                Text("تفعيل", fontSize = 12.sp, color = Color.White)
            }
        } else {
            Text("مفعّل ✅", fontSize = 12.sp, color = Color(0xFF4ADE80), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun TabPill(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) Color(0xFFE50914) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (selected) Color.White else Color(0xFF9CA3AF),
            modifier = Modifier.size(16.dp)
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) Color.White else Color(0xFF9CA3AF)
        )
    }
}

@Composable
private fun CardBox(
    title: String,
    icon: ImageVector,
    accent: Color,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF16161C))
            .border(1.dp, Color(0xFF27272E), RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = accent, modifier = Modifier.size(16.dp))
            }
            Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        content()
    }
}

@Composable
private fun ResultBanner(ok: Boolean, message: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (ok) Color(0x3322C55E) else Color(0x33EF4444))
            .padding(10.dp)
    ) {
        Text(
            text = message,
            fontSize = 12.sp,
            color = if (ok) Color(0xFF86EFAC) else Color(0xFFFCA5A5)
        )
    }
}
