package com.floatsub.app.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.floatsub.app.MainActivity
import com.floatsub.app.model.PipelineStatus
import com.floatsub.app.model.SubtitleState
import com.floatsub.app.model.SubtitleStyleConfig
import com.floatsub.app.translation.TranslationSettingsStore
import kotlin.math.abs
import kotlin.math.roundToInt

class FloatingSubtitleWindow(
    private val context: Context,
    private val onTogglePause: () -> Unit,
    private val onClearRequested: () -> Unit,
    private val onStopRequested: () -> Unit
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var subtitleRoot: FrameLayout? = null
    private var subtitleTextView: TextView? = null
    private var subtitleParams: WindowManager.LayoutParams? = null

    private var controlRoot: LinearLayout? = null
    private var expandedPanel: LinearLayout? = null
    private var statusDotView: View? = null
    private var pauseBtnView: TextView? = null
    private var moveBtnView: TextView? = null
    private var controlParams: WindowManager.LayoutParams? = null

    private var isShown = false
    private var isMoveMode = false
    private var isMenuExpanded = false
    private var currentStyle: SubtitleStyleConfig = TranslationSettingsStore.styleConfig.value

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), context.resources.displayMetrics).roundToInt()

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        mainHandler.post {
            if (isShown || !Settings.canDrawOverlays(context)) return@post
            currentStyle = TranslationSettingsStore.styleConfig.value

            // 1. Subtitle Banner Overlay (touch-through by default so it NEVER blocks apps underneath!)
            val subContainer = FrameLayout(context).apply {
                setPadding(dp(14), dp(4), dp(14), dp(4))
            }

            val tv = TextView(context).apply {
                gravity = Gravity.CENTER
                textDirection = View.TEXT_DIRECTION_RTL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                maxLines = 3
                setShadowLayer(6f, 2f, 2f, Color.BLACK)
                setPadding(dp(16), dp(8), dp(16), dp(8))
                visibility = View.GONE
            }
            subContainer.addView(
                tv,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            )

            val subLp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                y = currentStyle.overlayYOffsetPx
            }

            // Allow dragging the subtitle banner vertically when Move Mode is enabled
            var initialY = 0
            var initialTouchY = 0f
            subContainer.setOnTouchListener { _, event ->
                if (!isMoveMode) return@setOnTouchListener false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialY = subLp.y
                        initialTouchY = event.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val deltaY = (initialTouchY - event.rawY).roundToInt()
                        val screenH = context.resources.displayMetrics.heightPixels
                        subLp.y = (initialY + deltaY).coerceIn(dp(24), screenH - dp(120))
                        runCatching { windowManager.updateViewLayout(subContainer, subLp) }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        val updated = currentStyle.copy(overlayYOffsetPx = subLp.y)
                        currentStyle = updated
                        TranslationSettingsStore.updateStyle(context, updated)
                        true
                    }
                    else -> false
                }
            }

            // 2. Compact Floating Control Pill (expandable, draggable, unobtrusive)
            val pillRoot = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply {
                    setColor(0xCC141419.toInt())
                    cornerRadius = dp(22).toFloat()
                    setStroke(dp(1), 0x44FFFFFF)
                }
                setPadding(dp(8), dp(6), dp(8), dp(6))
            }

            val dot = View(context).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xFF22C55E.toInt())
                }
            }
            val dotLp = LinearLayout.LayoutParams(dp(10), dp(10)).apply {
                marginEnd = dp(6)
            }
            pillRoot.addView(dot, dotLp)

            val mainBadge = TextView(context).apply {
                text = "AR"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(2), dp(2), dp(4), dp(2))
            }
            pillRoot.addView(mainBadge)

            val panel = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                visibility = View.GONE
            }

            fun makeMiniBtn(label: String, color: Int = Color.WHITE, onClick: () -> Unit): TextView =
                TextView(context).apply {
                    text = label
                    setTextColor(color)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    setPadding(dp(9), dp(4), dp(9), dp(4))
                    setOnClickListener { onClick() }
                }

            val pauseBtn = makeMiniBtn("⏸") { onTogglePause() }
            val clearBtn = makeMiniBtn("⌫", 0xFF38BDF8.toInt()) {
                onClearRequested()
                subtitleTextView?.text = ""
                subtitleTextView?.visibility = View.GONE
            }
            val moveBtn = makeMiniBtn("✥") { toggleMoveMode() }
            val settingsBtn = makeMiniBtn("⚙") {
                val intent = Intent(context, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                context.startActivity(intent)
            }
            val stopBtn = makeMiniBtn("✕", 0xFFF87171.toInt()) { onStopRequested() }

            panel.addView(pauseBtn)
            panel.addView(clearBtn)
            panel.addView(moveBtn)
            panel.addView(settingsBtn)
            panel.addView(stopBtn)
            pillRoot.addView(panel)

            val ctrlLp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = dp(12)
                y = dp(110)
            }

            var ctrlStartX = 0
            var ctrlStartY = 0
            var touchStartX = 0f
            var touchStartY = 0f
            var dragged = false

            val dragListener = View.OnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        ctrlStartX = ctrlLp.x
                        ctrlStartY = ctrlLp.y
                        touchStartX = event.rawX
                        touchStartY = event.rawY
                        dragged = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (touchStartX - event.rawX).roundToInt()
                        val dy = (event.rawY - touchStartY).roundToInt()
                        if (abs(dx) > dp(4) || abs(dy) > dp(4)) dragged = true
                        ctrlLp.x = (ctrlStartX + dx).coerceAtLeast(0)
                        ctrlLp.y = (ctrlStartY + dy).coerceAtLeast(dp(24))
                        runCatching { windowManager.updateViewLayout(pillRoot, ctrlLp) }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!dragged) {
                            isMenuExpanded = !isMenuExpanded
                            panel.visibility = if (isMenuExpanded) View.VISIBLE else View.GONE
                        }
                        true
                    }
                    else -> false
                }
            }
            mainBadge.setOnTouchListener(dragListener)
            dot.setOnTouchListener(dragListener)

            runCatching {
                windowManager.addView(subContainer, subLp)
                windowManager.addView(pillRoot, ctrlLp)
                subtitleRoot = subContainer
                subtitleTextView = tv
                subtitleParams = subLp
                controlRoot = pillRoot
                expandedPanel = panel
                statusDotView = dot
                pauseBtnView = pauseBtn
                moveBtnView = moveBtn
                controlParams = ctrlLp
                isShown = true
                applyStyle(currentStyle)
            }
        }
    }

    private fun toggleMoveMode() {
        isMoveMode = !isMoveMode
        val sub = subtitleRoot ?: return
        val lp = subtitleParams ?: return
        val tv = subtitleTextView ?: return

        lp.flags = if (isMoveMode) {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
        runCatching { windowManager.updateViewLayout(sub, lp) }

        moveBtnView?.setTextColor(if (isMoveMode) 0xFFF5C518.toInt() else Color.WHITE)
        if (isMoveMode) {
            tv.visibility = View.VISIBLE
            tv.text = "اسحب الترجمة لأعلى أو أسفل ثم اضغط ✥ للتثبيت"
        }
    }

    fun applyStyle(style: SubtitleStyleConfig) {
        mainHandler.post {
            currentStyle = style
            val tv = subtitleTextView ?: return@post
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, style.fontSize.sp)
            tv.setTextColor(style.textColor.argb)
            tv.background = GradientDrawable().apply {
                setColor(style.bgOpacity.argb)
                cornerRadius = dp(10).toFloat()
            }
            val sub = subtitleRoot
            val lp = subtitleParams
            if (sub != null && lp != null && lp.y != style.overlayYOffsetPx) {
                lp.y = style.overlayYOffsetPx
                runCatching { windowManager.updateViewLayout(sub, lp) }
            }
        }
    }

    fun updateState(state: SubtitleState) {
        mainHandler.post {
            if (!isShown) return@post
            val tv = subtitleTextView ?: return@post

            // Update status dot & pause icon
            val dotColor = when {
                state.isPaused -> 0xFFF59E0B.toInt()
                state.status is PipelineStatus.Error -> 0xFFEF4444.toInt()
                state.status is PipelineStatus.DownloadingModels -> 0xFF38BDF8.toInt()
                else -> 0xFF22C55E.toInt()
            }
            (statusDotView?.background as? GradientDrawable)?.setColor(dotColor)
            pauseBtnView?.text = if (state.isPaused) "▶" else "⏸"

            if (isMoveMode) return@post

            if (state.isPaused) {
                tv.visibility = View.GONE
                return@post
            }

            val textToShow = when (val st = state.status) {
                is PipelineStatus.DownloadingModels -> st.messageAr
                is PipelineStatus.Error -> st.messageAr
                is PipelineStatus.Listening -> state.arabicText
                PipelineStatus.Idle -> ""
            }

            if (textToShow.isBlank()) {
                tv.visibility = View.GONE
            } else {
                tv.text = textToShow
                tv.visibility = View.VISIBLE
            }
        }
    }

    fun hide() {
        mainHandler.post {
            isMoveMode = false
            isMenuExpanded = false
            subtitleRoot?.let { runCatching { windowManager.removeView(it) } }
            controlRoot?.let { runCatching { windowManager.removeView(it) } }
            subtitleRoot = null
            subtitleTextView = null
            subtitleParams = null
            controlRoot = null
            expandedPanel = null
            statusDotView = null
            pauseBtnView = null
            moveBtnView = null
            controlParams = null
            isShown = false
        }
    }
}
