package com.cinemasub.browser.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinemasub.browser.model.AiTranslationConfig
import com.cinemasub.browser.model.DeepgramLanguage
import com.cinemasub.browser.model.SubtitleBgOpacity
import com.cinemasub.browser.model.SubtitleFontSize
import com.cinemasub.browser.model.SubtitleStyleConfig
import com.cinemasub.browser.model.SubtitleTextColor
import com.cinemasub.browser.model.TranslationEngine

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SubtitleSettingsSheet(
    styleConfig: SubtitleStyleConfig,
    aiConfig: AiTranslationConfig,
    adBlockerEnabled: Boolean,
    blockedAdsCount: Int,
    playbackSpeed: Float,
    externalSubtitleFileName: String?,
    isLoadingExternalSubtitle: Boolean,
    hasDetectedVideoStream: Boolean,
    hasDetectedPlayerUrl: Boolean,
    isGeneratingProactive: Boolean,
    proactiveProgressPercent: Int,
    proactiveStatusMessage: String?,
    isTestingApiKey: Boolean,
    apiKeyTestResult: Pair<Boolean, String>?,
    isTestingDeepgramKey: Boolean,
    deepgramTestResult: Pair<Boolean, String>?,
    onAdBlockerChange: (Boolean) -> Unit,
    onPlaybackSpeedChange: (Float) -> Unit,
    onImportExternalSubtitle: () -> Unit,
    onClearExternalSubtitle: () -> Unit,
    onStartProactiveSubtitles: () -> Unit,
    onCancelProactiveSubtitles: () -> Unit,
    onOpenDirectPlayer: () -> Unit,
    onEngineChange: (TranslationEngine) -> Unit,
    onGeminiKeyChange: (String) -> Unit,
    onGroqKeyChange: (String) -> Unit,
    onSambaNovaKeyChange: (String) -> Unit,
    onDeepgramKeyChange: (String) -> Unit,
    onDeepgramLanguageChange: (DeepgramLanguage) -> Unit,
    onSyncOffsetChange: (Float) -> Unit,
    onTestApiKey: () -> Unit,
    onTestDeepgramKey: () -> Unit,
    onFontSizeChange: (SubtitleFontSize) -> Unit,
    onTextColorChange: (SubtitleTextColor) -> Unit,
    onBgOpacityChange: (SubtitleBgOpacity) -> Unit,
    onVerticalBiasChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedTab by remember { mutableIntStateOf(0) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF111114),
        contentColor = Color.White,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp)
                    .padding(bottom = 26.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "إعدادات CinemaSub",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = "تحكم كامل في الترجمة والذكاء الاصطناعي والمظهر",
                            fontSize = 12.sp,
                            color = Color(0xFF9CA3AF)
                        )
                    }
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF27272A),
                        modifier = Modifier
                            .size(34.dp)
                            .clickable(onClick = onDismiss)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = Color(0xFFD4D4D8),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF1C1C21))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    SettingsTabPill(
                        label = "الترجمة",
                        icon = Icons.Default.Subtitles,
                        selected = selectedTab == 0,
                        modifier = Modifier.weight(1f)
                    ) { selectedTab = 0 }
                    SettingsTabPill(
                        label = "الذكاء AI",
                        icon = Icons.Default.AutoAwesome,
                        selected = selectedTab == 1,
                        modifier = Modifier.weight(1f)
                    ) { selectedTab = 1 }
                    SettingsTabPill(
                        label = "المظهر",
                        icon = Icons.Default.Tune,
                        selected = selectedTab == 2,
                        modifier = Modifier.weight(1f)
                    ) { selectedTab = 2 }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (selectedTab) {
                        0 -> {
                            SettingsCard(
                                title = "الترجمة الاستباقية (توقيت 100%)",
                                icon = Icons.Default.Bolt,
                                accentColor = Color(0xFFE50914)
                            ) {
                                Text(
                                    text = proactiveStatusMessage
                                        ?: if (hasDetectedVideoStream) {
                                            "تم رصد بث الفيديو ✅ جاهز لتوليد ترجمة متطابقة مع الصوت."
                                        } else {
                                            "شغّل الفيديو في المتصفح ثانيتين لرصده تلقائياً (يدعم .m3u8 و .mp4)."
                                        },
                                    fontSize = 12.sp,
                                    color = when {
                                        proactiveProgressPercent == 100 -> Color(0xFF4ADE80)
                                        hasDetectedVideoStream -> Color(0xFF93C5FD)
                                        else -> Color(0xFF9CA3AF)
                                    }
                                )

                                if (isGeneratingProactive) {
                                    LinearProgressIndicator(
                                        progress = { (proactiveProgressPercent / 100f).coerceIn(0.02f, 1f) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(4.dp)),
                                        color = Color(0xFFE50914),
                                        trackColor = Color(0xFF27272A)
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = onStartProactiveSubtitles,
                                        enabled = hasDetectedVideoStream && !isGeneratingProactive,
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFFE50914),
                                            contentColor = Color.White
                                        )
                                    ) {
                                        Text(
                                            text = if (isGeneratingProactive) "جاري التجهيز ($proactiveProgressPercent%)..."
                                            else "توليد ترجمة 100%",
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    if (isGeneratingProactive) {
                                        OutlinedButton(
                                            onClick = onCancelProactiveSubtitles,
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text("إيقاف", color = Color(0xFFF87171))
                                        }
                                    }
                                }

                                if (hasDetectedVideoStream) {
                                    Button(
                                        onClick = onOpenDirectPlayer,
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF2563EB),
                                            contentColor = Color.White
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            "تشغيل في المشغّل السينمائي (تزامن 100%)",
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            SettingsCard(
                                title = "ملف ترجمة خارجي (.srt / .vtt)",
                                icon = Icons.Default.UploadFile,
                                accentColor = Color(0xFFF59E0B)
                            ) {
                                Text(
                                    text = externalSubtitleFileName
                                        ?: "اختر ملف ترجمة من جهازك لتركيبه وترجمته تلقائياً.",
                                    fontSize = 12.sp,
                                    color = if (externalSubtitleFileName != null) Color(0xFF4ADE80) else Color(0xFF9CA3AF)
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = onImportExternalSubtitle,
                                        enabled = !isLoadingExternalSubtitle,
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        if (isLoadingExternalSubtitle) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(16.dp),
                                                strokeWidth = 2.dp
                                            )
                                        } else {
                                            Text("اختيار ملف ترجمة", fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                    if (externalSubtitleFileName != null) {
                                        OutlinedButton(
                                            onClick = onClearExternalSubtitle,
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text("مسح", color = Color(0xFFF87171))
                                        }
                                    }
                                }
                            }

                            SettingsCard(
                                title = "ضبط توقيت الترجمة",
                                icon = Icons.Default.Tune,
                                accentColor = Color(0xFF38BDF8)
                            ) {
                                val sign = if (styleConfig.syncOffsetSec > 0f) "+" else ""
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "الإزاحة الحالية: $sign${String.format("%.1f", styleConfig.syncOffsetSec)} ثانية",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFFF5C518)
                                    )
                                    Text(
                                        text = "تصفير",
                                        fontSize = 12.sp,
                                        color = Color(0xFF93C5FD),
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { onSyncOffsetChange(0f) }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                Slider(
                                    value = styleConfig.syncOffsetSec,
                                    onValueChange = { raw ->
                                        val snapped = (kotlin.math.round(raw * 5f) / 5f).coerceIn(-5f, 5f)
                                        onSyncOffsetChange(snapped)
                                    },
                                    valueRange = -5f..5f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = Color(0xFFE50914),
                                        activeTrackColor = Color(0xFFE50914)
                                    )
                                )
                            }
                        }

                        1 -> {
                            SettingsCard(
                                title = "محرك الترجمة بالذكاء الاصطناعي",
                                icon = Icons.Default.AutoAwesome,
                                accentColor = Color(0xFFA855F7)
                            ) {
                                Text(
                                    text = "اختر «الكل معاً (ذكي)» لتبديل تلقائي بين المفاتيح وتجنب أي حد استخدام.",
                                    fontSize = 12.sp,
                                    color = Color(0xFF9CA3AF)
                                )
                                FlowRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    TranslationEngine.entries.forEach { engine ->
                                        FilterChip(
                                            selected = aiConfig.engine == engine,
                                            onClick = { onEngineChange(engine) },
                                            label = { Text(engine.labelAr, fontSize = 12.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Color(0xFFE50914),
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                }

                                if (aiConfig.engine == TranslationEngine.GEMINI_AI || aiConfig.engine == TranslationEngine.AUTO_HYBRID) {
                                    OutlinedTextField(
                                        value = aiConfig.geminiApiKey,
                                        onValueChange = onGeminiKeyChange,
                                        label = { Text("مفتاح Gemini AI (aistudio.google.com)") },
                                        singleLine = true,
                                        visualTransformation = PasswordVisualTransformation(),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }

                                if (aiConfig.engine == TranslationEngine.GROQ_AI || aiConfig.engine == TranslationEngine.AUTO_HYBRID) {
                                    OutlinedTextField(
                                        value = aiConfig.groqApiKey,
                                        onValueChange = onGroqKeyChange,
                                        label = { Text("مفتاح Groq AI (console.groq.com)") },
                                        singleLine = true,
                                        visualTransformation = PasswordVisualTransformation(),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }

                                if (aiConfig.engine == TranslationEngine.SAMBANOVA_AI || aiConfig.engine == TranslationEngine.AUTO_HYBRID) {
                                    OutlinedTextField(
                                        value = aiConfig.sambaNovaApiKey,
                                        onValueChange = onSambaNovaKeyChange,
                                        label = { Text("مفتاح SambaNova المجاني (cloud.sambanova.ai)") },
                                        placeholder = { Text("ممتاز وسريع جداً للترجمة الاستباقية") },
                                        singleLine = true,
                                        visualTransformation = PasswordVisualTransformation(),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }

                                if (aiConfig.engine != TranslationEngine.GOOGLE_FREE) {
                                    Button(
                                        onClick = onTestApiKey,
                                        enabled = !isTestingApiKey,
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF27272A),
                                            contentColor = Color.White
                                        )
                                    ) {
                                        if (isTestingApiKey) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(16.dp),
                                                strokeWidth = 2.dp,
                                                color = Color.White
                                            )
                                        } else {
                                            Text("اختبار مفاتيح الذكاء الاصطناعي")
                                        }
                                    }

                                    apiKeyTestResult?.let { (ok, msg) ->
                                        StatusResultBanner(ok = ok, message = msg)
                                    }
                                }
                            }

                            SettingsCard(
                                title = "محرك تفريغ الصوت (Deepgram)",
                                icon = Icons.Default.Bolt,
                                accentColor = Color(0xFF22C55E)
                            ) {
                                OutlinedTextField(
                                    value = aiConfig.deepgramApiKey,
                                    onValueChange = onDeepgramKeyChange,
                                    label = { Text("مفتاح Deepgram (مجاني $200 بدون فيزا)") },
                                    placeholder = { Text("console.deepgram.com") },
                                    singleLine = true,
                                    visualTransformation = PasswordVisualTransformation(),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Text(
                                    text = "لغة الصوت",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFD4D4D8)
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    DeepgramLanguage.entries.forEach { lang ->
                                        FilterChip(
                                            selected = aiConfig.deepgramLanguage == lang,
                                            onClick = { onDeepgramLanguageChange(lang) },
                                            label = { Text(lang.labelAr, fontSize = 12.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Color(0xFF16A34A),
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                }

                                Button(
                                    onClick = onTestDeepgramKey,
                                    enabled = !isTestingDeepgramKey,
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF27272A),
                                        contentColor = Color.White
                                    )
                                ) {
                                    if (isTestingDeepgramKey) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(16.dp),
                                            strokeWidth = 2.dp,
                                            color = Color.White
                                        )
                                    } else {
                                        Text("اختبار مفتاح Deepgram")
                                    }
                                }

                                deepgramTestResult?.let { (ok, msg) ->
                                    StatusResultBanner(ok = ok, message = msg)
                                }
                            }
                        }

                        2 -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0xFF09090B))
                                    .border(1.dp, Color(0xFF27272A), RoundedCornerShape(14.dp))
                                    .padding(vertical = 18.dp, horizontal = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(styleConfig.bgOpacity.color)
                                        .padding(horizontal = 14.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "هكذا ستظهر الترجمة السينمائية على الشاشة",
                                        color = styleConfig.textColor.color,
                                        fontSize = styleConfig.fontSize.sp.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }

                            SettingsCard(
                                title = "تخصيص خط ومكان الترجمة",
                                icon = Icons.Default.Subtitles,
                                accentColor = Color(0xFFF5C518)
                            ) {
                                Text("حجم الخط", fontSize = 12.sp, color = Color(0xFFD4D4D8))
                                FlowRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    SubtitleFontSize.entries.forEach { size ->
                                        FilterChip(
                                            selected = styleConfig.fontSize == size,
                                            onClick = { onFontSizeChange(size) },
                                            label = { Text(size.labelAr, fontSize = 12.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Color(0xFFE50914),
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                }

                                Text("لون النص", fontSize = 12.sp, color = Color(0xFFD4D4D8))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    SubtitleTextColor.entries.forEach { colorOption ->
                                        FilterChip(
                                            selected = styleConfig.textColor == colorOption,
                                            onClick = { onTextColorChange(colorOption) },
                                            label = { Text(colorOption.labelAr, fontSize = 12.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Color(0xFFE50914),
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                }

                                Text("خلفية الترجمة", fontSize = 12.sp, color = Color(0xFFD4D4D8))
                                FlowRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    SubtitleBgOpacity.entries.forEach { bgOption ->
                                        FilterChip(
                                            selected = styleConfig.bgOpacity == bgOption,
                                            onClick = { onBgOpacityChange(bgOption) },
                                            label = { Text(bgOption.labelAr, fontSize = 12.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Color(0xFFE50914),
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                }

                                Text(
                                    text = "ارتفاع الترجمة على الشاشة (${(styleConfig.verticalBias * 100).toInt()}%)",
                                    fontSize = 12.sp,
                                    color = Color(0xFFD4D4D8)
                                )
                                Slider(
                                    value = styleConfig.verticalBias,
                                    onValueChange = onVerticalBiasChange,
                                    valueRange = 0.12f..0.90f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = Color(0xFFE50914),
                                        activeTrackColor = Color(0xFFE50914)
                                    )
                                )
                            }

                            SettingsCard(
                                title = "المتصفح وسرعة الفيديو",
                                icon = Icons.Default.Speed,
                                accentColor = Color(0xFF4ADE80)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Shield,
                                            contentDescription = null,
                                            tint = if (adBlockerEnabled) Color(0xFF4ADE80) else Color(0xFF71717A),
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Column {
                                            Text(
                                                text = "مانع الإعلانات والنوافذ المنبثقة",
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = if (adBlockerEnabled) "تم حظر $blockedAdsCount إعلان في هذه الصفحة" else "متوقف",
                                                fontSize = 11.sp,
                                                color = if (adBlockerEnabled) Color(0xFF4ADE80) else Color(0xFF9CA3AF)
                                            )
                                        }
                                    }
                                    Switch(
                                        checked = adBlockerEnabled,
                                        onCheckedChange = onAdBlockerChange
                                    )
                                }

                                Text("سرعة تشغيل الفيديو", fontSize = 12.sp, color = Color(0xFFD4D4D8))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf(1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                                        FilterChip(
                                            selected = playbackSpeed == spd,
                                            onClick = { onPlaybackSpeedChange(spd) },
                                            label = { Text("${spd}x", fontSize = 12.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Color(0xFFE50914),
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(6.dp))
                }
            }
        }
    }
}

@Composable
private fun SettingsTabPill(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bgColor = if (selected) Color(0xFFE50914) else Color.Transparent
    val contentColor = if (selected) Color.White else Color(0xFF9CA3AF)

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(bgColor)
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp, horizontal = 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = contentColor,
            modifier = Modifier.size(16.dp)
        )
        Spacer(Modifier.width(5.dp))
        Text(
            text = label,
            color = contentColor,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
private fun SettingsCard(
    title: String,
    icon: ImageVector,
    accentColor: Color,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF1A1A20))
            .border(1.dp, Color(0xFF27272E), RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(accentColor.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
        content()
    }
}

@Composable
private fun StatusResultBanner(ok: Boolean, message: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (ok) Color(0x3322C55E) else Color(0x33EF4444))
            .padding(10.dp)
    ) {
        Text(
            text = message,
            fontSize = 12.sp,
            color = if (ok) Color(0xFF86EFAC) else Color(0xFFFCA5A5)
        )
    }
}
