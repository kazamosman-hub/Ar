package com.cinemasub.browser.browser

import android.webkit.JavascriptInterface
import org.json.JSONArray

class CaptionJsBridge(
    private val onCaptionCue: (String) -> Unit,
    private val onPreloadBatch: (List<String>) -> Unit
) {
    @JavascriptInterface
    fun onCaption(text: String?) {
        onCaptionCue(text?.trim().orEmpty())
    }

    @JavascriptInterface
    fun onPreloadBatch(jsonArrayStr: String?) {
        if (jsonArrayStr.isNullOrBlank()) return
        val list = runCatching {
            val arr = JSONArray(jsonArrayStr)
            buildList {
                for (i in 0 until arr.length()) {
                    val item = arr.optString(i, "").trim()
                    if (item.isNotEmpty()) add(item)
                }
            }
        }.getOrDefault(emptyList())
        if (list.isNotEmpty()) {
            onPreloadBatch(list)
        }
    }
}

object WebCaptionInjector {

    const val BRIDGE_NAME = "CinemaSubBridge"

    fun setEnabledScript(enabled: Boolean): String =
        "if (window.__cinemaSubSetEnabled) { window.__cinemaSubSetEnabled($enabled); }"

    fun setSyncOffsetScript(offsetSec: Float): String =
        "if (window.__cinemaSubSetSyncOffset) { window.__cinemaSubSetSyncOffset($offsetSec); }"

    val INJECT_SCRIPT: String = """
        (function() {
            if (window.__cinemaSubInstalled) return;
            window.__cinemaSubInstalled = true;
            window.__cinemaSubEnabled = false;
            window.__cinemaSubSyncOffset = 0;

            var lastSentText = "";
            var preloadedSet = new Set();
            var trackedVideos = new WeakSet();
            var trackedTextTracks = new WeakSet();

            function cleanText(raw) {
                if (!raw) return "";
                return raw
                    .replace(/<[^>]*>/g, " ")
                    .replace(/\s+/g, " ")
                    .trim();
            }

            function emitCaption(text) {
                if (!window.__cinemaSubEnabled) return;
                var cleaned = cleanText(text);
                if (cleaned === lastSentText) return;
                lastSentText = cleaned;
                try {
                    if (window.CinemaSubBridge && window.CinemaSubBridge.onCaption) {
                        window.CinemaSubBridge.onCaption(cleaned);
                    }
                } catch (e) {}
            }

            // Send next 10 upcoming cues together as ONE batch so AI translates the whole scene coherently!
            function preloadUpcomingBatch(track, startIdx) {
                if (!window.__cinemaSubEnabled || !track || !track.cues) return;
                try {
                    var cues = track.cues;
                    var batch = [];
                    var maxEnd = Math.min(cues.length, startIdx + 12);
                    for (var i = Math.max(0, startIdx); i < maxEnd && batch.length < 10; i++) {
                        var t = cleanText(cues[i].text);
                        if (t && !preloadedSet.has(t)) {
                            if (preloadedSet.size > 600) preloadedSet.clear();
                            preloadedSet.add(t);
                            batch.push(t);
                        }
                    }
                    if (batch.length > 0 && window.CinemaSubBridge && window.CinemaSubBridge.onPreloadBatch) {
                        window.CinemaSubBridge.onPreloadBatch(JSON.stringify(batch));
                    }
                } catch (e) {}
            }

            function preloadFromCue(track, activeCue) {
                if (!track || !track.cues || !activeCue) return;
                var cues = track.cues;
                for (var i = 0; i < cues.length; i++) {
                    if (cues[i] === activeCue) {
                        preloadUpcomingBatch(track, i + 1);
                        return;
                    }
                }
            }

            function preloadAroundTime(video) {
                if (!video || !video.textTracks) return;
                var nowTime = video.currentTime - window.__cinemaSubSyncOffset;
                for (var t = 0; t < video.textTracks.length; t++) {
                    var tr = video.textTracks[t];
                    if ((tr.kind === "subtitles" || tr.kind === "captions") && tr.cues && tr.cues.length > 0) {
                        for (var c = 0; c < tr.cues.length; c++) {
                            if (tr.cues[c].endTime >= nowTime) {
                                preloadUpcomingBatch(tr, c);
                                return;
                            }
                        }
                    }
                }
            }

            function toggleHideOriginalCss(hide) {
                var styleId = "cinemasub-hide-orig-captions";
                var existing = document.getElementById(styleId);
                if (hide) {
                    if (!existing) {
                        var style = document.createElement("style");
                        style.id = styleId;
                        style.textContent = [
                            ".ytp-caption-window-container,",
                            ".caption-window,",
                            ".vjs-text-track-display,",
                            ".jw-captions,",
                            ".plyr__captions,",
                            ".vp-captions,",
                            ".shaka-text-container,",
                            ".bmpui-ui-subtitle-label {",
                            "  opacity: 0 !important;",
                            "  pointer-events: none !important;",
                            "}"
                        ].join("\n");
                        (document.head || document.documentElement).appendChild(style);
                    }
                } else if (existing) {
                    existing.remove();
                }
            }

            function tryEnableSiteCaptions() {
                if (!window.__cinemaSubEnabled) return;
                try {
                    var ytBtn = document.querySelector(".ytp-subtitles-button");
                    if (ytBtn && ytBtn.getAttribute("aria-pressed") === "false") {
                        ytBtn.click();
                    }
                } catch (e) {}
            }

            function bindTrack(track) {
                if (!track || trackedTextTracks.has(track)) return;
                trackedTextTracks.add(track);
                track.addEventListener("cuechange", function() {
                    if (!window.__cinemaSubEnabled) return;
                    // When syncOffset != 0, the timestamp ticker handles exact cue timing
                    if (Math.abs(window.__cinemaSubSyncOffset) >= 0.05) return;
                    var cues = track.activeCues;
                    if (!cues || cues.length === 0) {
                        emitCaption("");
                        return;
                    }
                    var parts = [];
                    for (var i = 0; i < cues.length; i++) {
                        if (cues[i] && cues[i].text) {
                            parts.push(cues[i].text);
                        }
                    }
                    emitCaption(parts.join(" "));
                    preloadFromCue(track, cues[cues.length - 1]);
                });
            }

            function attachVideoTracks(video) {
                if (!video || !video.textTracks) return;
                var tracks = video.textTracks;
                var chosenTrack = null;

                for (var i = 0; i < tracks.length; i++) {
                    var t = tracks[i];
                    if (t.kind === "subtitles" || t.kind === "captions") {
                        bindTrack(t);
                        if (window.__cinemaSubEnabled) {
                            if (t.mode === "showing") {
                                t.mode = "hidden";
                                chosenTrack = t;
                            } else if (!chosenTrack && t.language && t.language.toLowerCase().indexOf("en") === 0) {
                                chosenTrack = t;
                            } else if (!chosenTrack) {
                                chosenTrack = t;
                            }
                        }
                    }
                }

                if (window.__cinemaSubEnabled && chosenTrack && chosenTrack.mode === "disabled") {
                    chosenTrack.mode = "hidden";
                }

                if (!trackedVideos.has(video)) {
                    trackedVideos.add(video);
                    video.addEventListener("seeked", function() {
                        if (window.__cinemaSubEnabled) {
                            lastSentText = "";
                            preloadAroundTime(video);
                        }
                    });
                    video.addEventListener("play", function() {
                        if (window.__cinemaSubEnabled) {
                            preloadAroundTime(video);
                        }
                    });
                    try {
                        tracks.addEventListener("addtrack", function(ev) {
                            if (ev && ev.track) {
                                bindTrack(ev.track);
                                if (window.__cinemaSubEnabled && ev.track.mode === "disabled") {
                                    ev.track.mode = "hidden";
                                }
                            }
                        });
                    } catch (e) {}
                }
            }

            function scanAllVideos() {
                var videos = document.querySelectorAll("video");
                for (var i = 0; i < videos.length; i++) {
                    attachVideoTracks(videos[i]);
                }
            }

            var domSelectors = [
                ".ytp-caption-segment",
                ".caption-visual-line",
                ".vjs-text-track-cue",
                ".jw-text-track-cue",
                ".plyr__caption",
                ".vp-captions span",
                ".shaka-text-container span",
                ".bmpui-ui-subtitle-label"
            ];

            var domEmptyTicks = 0;
            function readDomCaptions() {
                if (!window.__cinemaSubEnabled) return;
                for (var s = 0; s < domSelectors.length; s++) {
                    var nodes = document.querySelectorAll(domSelectors[s]);
                    if (nodes && nodes.length > 0) {
                        var parts = [];
                        for (var j = 0; j < nodes.length; j++) {
                            var txt = (nodes[j].innerText || nodes[j].textContent || "").trim();
                            if (txt) parts.push(txt);
                        }
                        var combined = parts.join(" ").trim();
                        if (combined.length > 0 && combined.length <= 260) {
                            domEmptyTicks = 0;
                            emitCaption(combined);
                            return;
                        }
                    }
                }
                domEmptyTicks++;
                if (domEmptyTicks >= 3 && lastSentText !== "") {
                    emitCaption("");
                }
            }

            var domTimer = null;
            var observer = new MutationObserver(function() {
                if (!window.__cinemaSubEnabled) return;
                if (domTimer) return;
                domTimer = setTimeout(function() {
                    domTimer = null;
                    readDomCaptions();
                }, 15);
            });

            if (document.body) {
                observer.observe(document.body, {
                    childList: true,
                    subtree: true,
                    characterData: true
                });
            }

            setInterval(function() {
                if (!window.__cinemaSubEnabled) return;
                scanAllVideos();
                readDomCaptions();
            }, 900);

            window.__cinemaSubSetSyncOffset = function(offsetSec) {
                window.__cinemaSubSyncOffset = Number(offsetSec) || 0;
            };

            // Exact timestamp-bound sync ticker for HTML5 video tracks (supports both - and + sync offsets)
            setInterval(function() {
                if (!window.__cinemaSubEnabled) return;
                var videos = document.querySelectorAll("video");
                for (var i = 0; i < videos.length; i++) {
                    var v = videos[i];
                    if (!v || v.paused || !v.textTracks) continue;
                    var offset = window.__cinemaSubSyncOffset;
                    if (Math.abs(offset) < 0.05) continue;
                    var targetTime = v.currentTime - offset;
                    var foundCue = false;
                    for (var t = 0; t < v.textTracks.length; t++) {
                        var tr = v.textTracks[t];
                        if ((tr.kind === "subtitles" || tr.kind === "captions") && tr.cues && tr.cues.length > 0) {
                            for (var c = 0; c < tr.cues.length; c++) {
                                var cue = tr.cues[c];
                                if (targetTime >= cue.startTime && targetTime <= cue.endTime) {
                                    emitCaption(cue.text);
                                    preloadUpcomingBatch(tr, c + 1);
                                    foundCue = true;
                                    break;
                                }
                            }
                            if (foundCue) break;
                        }
                    }
                    if (!foundCue && lastSentText !== "") {
                        emitCaption("");
                    }
                }
            }, 100);

            window.__cinemaSubSetEnabled = function(enabled) {
                window.__cinemaSubEnabled = !!enabled;
                lastSentText = "";
                toggleHideOriginalCss(window.__cinemaSubEnabled);
                if (window.__cinemaSubEnabled) {
                    tryEnableSiteCaptions();
                    scanAllVideos();
                    var videos = document.querySelectorAll("video");
                    for (var i = 0; i < videos.length; i++) {
                        preloadAroundTime(videos[i]);
                    }
                    readDomCaptions();
                }
            };
        })();
    """.trimIndent()
}
