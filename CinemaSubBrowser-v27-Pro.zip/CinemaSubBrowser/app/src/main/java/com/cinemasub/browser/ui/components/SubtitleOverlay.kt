package com.cinemasub.browser.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinemasub.browser.model.PipelineStatus
import com.cinemasub.browser.model.SubtitleState
import com.cinemasub.browser.model.SubtitleStyleConfig
import kotlin.math.roundToInt

@Composable
fun NetflixSubtitleOverlay(
    subtitleState: SubtitleState,
    styleConfig: SubtitleStyleConfig,
    onVerticalBiasChanged: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val displayText = when (val status = subtitleState.status) {
        is PipelineStatus.DownloadingModels -> status.messageAr
        is PipelineStatus.Error -> status.messageAr
        is PipelineStatus.Listening -> subtitleState.arabicText
        PipelineStatus.Idle -> ""
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        // Subtle live listening indicator dot in top-start corner when active & waiting for speech
        if (subtitleState.isLiveEnabled && subtitleState.status is PipelineStatus.Listening) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(10.dp)
                    .size(8.dp)
                    .background(Color(0xCC22C55E), CircleShape)
            )
        }

        AnimatedVisibility(
            visible = subtitleState.isLiveEnabled && displayText.isNotBlank(),
            enter = fadeIn(animationSpec = tween(110)),
            exit = fadeOut(animationSpec = tween(140)),
            modifier = Modifier.fillMaxSize()
        ) {
            val containerHeightPx = with(LocalDensity.current) { maxHeight.toPx() }
            var dragOffsetX by remember { mutableFloatStateOf(0f) }

            val yOffsetPx = (containerHeightPx * styleConfig.verticalBias) -
                with(LocalDensity.current) { 56.dp.toPx() }

            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset { IntOffset(dragOffsetX.roundToInt(), yOffsetPx.roundToInt()) }
                    .pointerInput(Unit) {
                        detectTapGestures(onDoubleTap = { dragOffsetX = 0f })
                    }
                    .pointerInput(containerHeightPx, styleConfig.verticalBias) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            dragOffsetX = (dragOffsetX + dragAmount.x).coerceIn(-180f, 180f)
                            val deltaBias = dragAmount.y / containerHeightPx
                            onVerticalBiasChanged(styleConfig.verticalBias + deltaBias)
                        }
                    }
                    .padding(horizontal = 16.dp)
                    .widthIn(max = 580.dp)
                    .background(
                        color = styleConfig.bgOpacity.color,
                        shape = RoundedCornerShape(10.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 7.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    val showEnglish = styleConfig.dualSubtitlesEnabled &&
                        subtitleState.status is PipelineStatus.Listening &&
                        subtitleState.originalEnglishText.isNotBlank() &&
                        subtitleState.originalEnglishText != displayText

                    if (showEnglish) {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            val engSize = (styleConfig.fontSize.sp * 0.72f).coerceAtLeast(12f)
                            Text(
                                text = subtitleState.originalEnglishText,
                                textAlign = TextAlign.Center,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                style = TextStyle(
                                    color = Color(0xFFE4E4E7),
                                    fontSize = engSize.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = FontFamily.SansSerif,
                                    lineHeight = (engSize * 1.28f).sp,
                                    shadow = Shadow(
                                        color = Color(0xEE000000),
                                        offset = Offset(1.5f, 1.5f),
                                        blurRadius = 4f
                                    )
                                )
                            )
                        }
                    }

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        AnimatedContent(
                            targetState = displayText,
                            transitionSpec = {
                                fadeIn(animationSpec = tween(90)) togetherWith fadeOut(animationSpec = tween(70))
                            },
                            label = "subtitle_text_transition"
                        ) { textValue ->
                            Text(
                                text = textValue,
                                textAlign = TextAlign.Center,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                style = TextStyle(
                                    color = styleConfig.textColor.color,
                                    fontSize = styleConfig.fontSize.sp.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.SansSerif,
                                    lineHeight = (styleConfig.fontSize.sp * 1.38f).sp,
                                    shadow = Shadow(
                                        color = Color(0xFF000000),
                                        offset = Offset(2f, 2f),
                                        blurRadius = 6f
                                    )
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
