package com.cinemasub.browser.audio

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class DeepgramStreamingClient(
    private val apiKey: String,
    private val scope: CoroutineScope,
    private val onTranscript: (text: String, isFinal: Boolean) -> Unit,
    private val onStatusChanged: (connected: Boolean, errorMsg: String?) -> Unit
) {
    companion object {
        suspend fun verifyApiKey(apiKey: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
            val trimmed = apiKey.trim()
            if (trimmed.isEmpty()) {
                return@withContext Pair(false, "أدخل مفتاح Deepgram أولاً.")
            }
            val verifyClient = OkHttpClient.Builder()
                .connectTimeout(8, TimeUnit.SECONDS)
                .readTimeout(8, TimeUnit.SECONDS)
                .build()
            runCatching {
                val request = Request.Builder()
                    .url("https://api.deepgram.com/v1/projects")
                    .addHeader("Authorization", "Token $trimmed")
                    .get()
                    .build()
                verifyClient.newCall(request).execute().use { resp ->
                    when (resp.code) {
                        in 200..299 -> Pair(true, "✅ مفتاح Deepgram شغال وجاهز للبث اللحظي!")
                        401, 403 -> Pair(false, "❌ مفتاح Deepgram غير صحيح أو منتهي الصلاحية (${resp.code})")
                        else -> Pair(false, "❌ خطأ من سيرفر Deepgram (${resp.code})")
                    }
                }
            }.getOrElse { e ->
                Pair(false, "❌ خطأ اتصال بـ Deepgram: ${e.localizedMessage ?: "تأكد من الإنترنت"}")
            }
        }
    }

    private val client = OkHttpClient.Builder()
        .connectionPool(ConnectionPool(4, 3, TimeUnit.MINUTES))
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(12, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    @Volatile
    private var webSocket: WebSocket? = null
    private val isConnected = AtomicBoolean(false)
    private val isClosedManually = AtomicBoolean(false)
    private val reconnectAttempts = AtomicInteger(0)
    private val maxReconnectAttempts = 6

    fun connect() {
        isClosedManually.set(false)
        openSocket()
    }

    private fun openSocket() {
        if (isClosedManually.get()) return
        val url = "wss://api.deepgram.com/v1/listen" +
            "?model=nova-2" +
            "&language=multi" +
            "&encoding=linear16" +
            "&sample_rate=16000" +
            "&channels=1" +
            "&smart_format=true" +
            "&interim_results=true" +
            "&endpointing=200" +
            "&utterance_end_ms=1000" +
            "&vad_events=true"

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Token ${apiKey.trim()}")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                isConnected.set(true)
                reconnectAttempts.set(0)
                onStatusChanged(true, null)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                runCatching {
                    val json = JSONObject(text)
                    val msgType = json.optString("type", "")
                    if (msgType == "UtteranceEnd") {
                        return
                    }
                    val channel = json.optJSONObject("channel") ?: return
                    val alts = channel.optJSONArray("alternatives") ?: return
                    if (alts.length() == 0) return
                    val transcript = alts.optJSONObject(0)?.optString("transcript", "")?.trim().orEmpty()
                    if (transcript.isNotEmpty()) {
                        val isFinal = json.optBoolean("is_final", false) || json.optBoolean("speech_final", false)
                        onTranscript(transcript, isFinal)
                    }
                }
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                isConnected.set(false)
                if (isClosedManually.get()) return

                val code = response?.code
                if (code == 401 || code == 402 || code == 403) {
                    onStatusChanged(false, "مفتاح Deepgram غير صالح أو انتهى الرصيد ($code)")
                    return
                }

                scheduleReconnect()
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                isConnected.set(false)
                if (!isClosedManually.get() && code != 1000) {
                    scheduleReconnect()
                }
            }
        })
    }

    private fun scheduleReconnect() {
        val attempt = reconnectAttempts.incrementAndGet()
        if (attempt > maxReconnectAttempts) {
            onStatusChanged(false, "انقطع الاتصال بالبث المباشر، أعد التشغيل")
            return
        }
        val backoffMs = (1000L * attempt).coerceAtMost(4000L)
        scope.launch(Dispatchers.IO) {
            delay(backoffMs)
            if (!isClosedManually.get()) {
                openSocket()
            }
        }
    }

    fun sendPcmAudio(data: ByteArray, length: Int) {
        if (!isConnected.get() || length <= 0) return
        webSocket?.send(data.toByteString(0, length))
    }

    fun sendKeepAlive() {
        if (!isConnected.get()) return
        webSocket?.send("""{"type":"KeepAlive"}""")
    }

    fun close() {
        isClosedManually.set(true)
        isConnected.set(false)
        runCatching {
            webSocket?.send("""{"type":"CloseStream"}""")
            webSocket?.close(1000, "Stopped")
        }
        webSocket = null
    }
}
