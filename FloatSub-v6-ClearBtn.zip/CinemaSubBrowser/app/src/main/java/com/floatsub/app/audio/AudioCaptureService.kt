package com.floatsub.app.audio

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.floatsub.app.MainActivity
import com.floatsub.app.overlay.FloatingSubtitleWindow
import com.floatsub.app.model.PipelineStatus
import com.floatsub.app.model.SubtitleSourceMode
import com.floatsub.app.model.SubtitleState
import com.floatsub.app.translation.ArabicTranslator
import com.floatsub.app.translation.TranslationSettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.sqrt

class AudioCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.floatsub.app.action.START_CAPTURE"
        const val ACTION_STOP = "com.floatsub.app.action.STOP_CAPTURE"
        const val ACTION_TOGGLE_PAUSE = "com.floatsub.app.action.TOGGLE_PAUSE"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private const val CHANNEL_ID = "floatsub_live_translation"
        private const val NOTIFICATION_ID = 1001
        private const val SAMPLE_RATE = 16000

        private const val MAX_WORDS_PER_CUE = 7
        private const val PAUSE_COMMIT_MS = 280L
        private const val SILENCE_CLEAR_MS = 2500L
        private const val MIN_FINAL_DISPLAY_MS = 1500L

        private val _subtitleState = MutableStateFlow(SubtitleState())
        val subtitleState: StateFlow<SubtitleState> = _subtitleState.asStateFlow()
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var captureJob: Job? = null
    private var translationJob: Job? = null
    private var whisperJob: Job? = null
    private var overlaySyncJob: Job? = null
    private var styleSyncJob: Job? = null
    private var floatingWindow: FloatingSubtitleWindow? = null
    @Volatile private var isPaused: Boolean = false
    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var voskModel: Model? = null
    private var recognizer: Recognizer? = null
    private val translator = ArabicTranslator()
    @Volatile private var lastEnglishSentence: String = ""
    @Volatile private var lastArabicDisplayedMs: Long = 0L
    @Volatile private var lastFinalDisplayedMs: Long = 0L
    private val translationEpoch = AtomicLong(0L)

    private val pendingTranslationFlow = MutableSharedFlow<Triple<String, Boolean, Long>>(
        replay = 0,
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    private val pendingWhisperAudioFlow = MutableSharedFlow<ByteArray>(
        replay = 0,
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    override fun onCreate() {
        super.onCreate()
        TranslationSettingsStore.init(applicationContext)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE_PAUSE -> {
                isPaused = !isPaused
                translationEpoch.incrementAndGet()
                if (isPaused) {
                    lastEnglishSentence = ""
                    translator.clearSceneHistory()
                }
                _subtitleState.update { it.copy(isPaused = isPaused, arabicText = if (isPaused) "" else it.arabicText) }
                return START_NOT_STICKY
            }
            ACTION_STOP -> {
                stopPipeline()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }

                if (resultCode != Activity.RESULT_OK || resultData == null) {
                    _subtitleState.update {
                        it.copy(
                            isLiveEnabled = false,
                            sourceMode = SubtitleSourceMode.NONE,
                            status = PipelineStatus.Error("تم إلغاء إذن التقاط الصوت")
                        )
                    }
                    stopSelf()
                    return START_NOT_STICKY
                }

                startForegroundCompat()
                startPipeline(resultCode, resultData)
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        createNotificationChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @SuppressLint("MissingPermission")
    private fun startPipeline(resultCode: Int, resultData: Intent) {
        captureJob?.cancel()
        translationJob?.cancel()
        whisperJob?.cancel()
        overlaySyncJob?.cancel()
        styleSyncJob?.cancel()
        isPaused = false

        floatingWindow?.hide()
        floatingWindow = FloatingSubtitleWindow(
            context = applicationContext,
            onTogglePause = {
                isPaused = !isPaused
                translationEpoch.incrementAndGet()
                if (isPaused) {
                    lastEnglishSentence = ""
                    translator.clearSceneHistory()
                }
                _subtitleState.update { it.copy(isPaused = isPaused, arabicText = if (isPaused) "" else it.arabicText) }
            },
            onClearRequested = {
                translationEpoch.incrementAndGet()
                lastEnglishSentence = ""
                translator.clearSceneHistory()
                _subtitleState.update { it.copy(arabicText = "", originalEnglishText = "") }
            },
            onStopRequested = {
                stopPipeline()
                stopSelf()
            }
        ).also { it.show() }

        overlaySyncJob = serviceScope.launch(Dispatchers.Main) {
            subtitleState.collect { st ->
                floatingWindow?.updateState(st)
            }
        }
        styleSyncJob = serviceScope.launch(Dispatchers.Main) {
            TranslationSettingsStore.styleConfig.collect { style ->
                floatingWindow?.applyStyle(style)
            }
        }

        translationJob = serviceScope.launch(Dispatchers.IO) {
            pendingTranslationFlow.collectLatest { (sentence, isFinal, itemEpoch) ->
                if (isPaused || itemEpoch != translationEpoch.get()) return@collectLatest
                val prev = lastEnglishSentence
                val arabic = if (isFinal) {
                    lastEnglishSentence = sentence
                    withTimeoutOrNull(950L) {
                        translator.translateToArabic(sentence, prev)
                    } ?: translator.translateInterimFast(sentence)
                } else {
                    withTimeoutOrNull(550L) {
                        translator.translateInterimFast(sentence)
                    }.orEmpty()
                }
                // Drop stale translation if user switched video or paused while it was in-flight!
                if (isPaused || itemEpoch != translationEpoch.get()) return@collectLatest
                if (arabic.isNotBlank()) {
                    val nowDisplayed = System.currentTimeMillis()
                    lastArabicDisplayedMs = nowDisplayed
                    if (isFinal) {
                        lastFinalDisplayedMs = nowDisplayed
                    }
                    _subtitleState.update {
                        it.copy(
                            originalEnglishText = sentence,
                            arabicText = arabic
                        )
                    }
                }
            }
        }

        captureJob = serviceScope.launch(Dispatchers.IO) {
            try {
                val deepgramKey = TranslationSettingsStore.currentConfig.deepgramApiKey.trim()
                val groqKey = TranslationSettingsStore.currentConfig.groqApiKey.trim()
                val useDeepgram = deepgramKey.isNotBlank()
                val useGroqWhisper = !useDeepgram && groqKey.isNotBlank()

                _subtitleState.update {
                    it.copy(
                        isLiveEnabled = true,
                        sourceMode = SubtitleSourceMode.LIVE_AUDIO,
                        status = PipelineStatus.DownloadingModels(
                            when {
                                useDeepgram -> "جاري الاتصال بالبث اللحظي (Deepgram Nova-2)..."
                                useGroqWhisper -> "جاري تشغيل Whisper السريع..."
                                else -> "جاري تجهيز محرك الصوت المباشر..."
                            }
                        )
                    )
                }

                serviceScope.launch { translator.ensureModelDownloaded() }

                val projectionManager =
                    getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
                    ?: throw IllegalStateException("MediaProjection unavailable")

                mediaProjection?.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() {
                        stopPipeline()
                        stopSelf()
                    }
                }, null)

                val captureConfig = AudioPlaybackCaptureConfiguration.Builder(mediaProjection!!)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()

                val audioFormat = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build()

                val minBuffer = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(2048)

                audioRecord = AudioRecord.Builder()
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(minBuffer * 2)
                    .setAudioPlaybackCaptureConfig(captureConfig)
                    .build()

                if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                    throw IllegalStateException("فشل تهيئة مسجل الصوت الداخلي")
                }

                when {
                    useDeepgram -> runDeepgramStreamingLoop(deepgramKey)
                    useGroqWhisper -> runGroqWhisperLoop(groqKey)
                    else -> runVoskOfflineLoop()
                }
            } catch (e: Exception) {
                _subtitleState.update {
                    it.copy(
                        isLiveEnabled = false,
                        sourceMode = SubtitleSourceMode.NONE,
                        status = PipelineStatus.Error(
                            e.localizedMessage ?: "حدث خطأ أثناء تشغيل الترجمة الفورية"
                        )
                    )
                }
                stopSelf()
            }
        }
    }

    // WatchTranslate-grade sub-second live streaming via Deepgram Nova-2 WebSocket
    // With Opus 24kbps compression + automatic 8-second self-healing fallback to PCM if device Opus codec is incompatible!
    private suspend fun runDeepgramStreamingLoop(deepgramKey: String) {
        val cfg = TranslationSettingsStore.currentConfig
        val tryOpusFirst = cfg.opusCompressionEnabled
        val fellBack = runDeepgramSession(deepgramKey = deepgramKey, enableOpus = tryOpusFirst)
        if (fellBack && captureJob?.isActive == true) {
            runDeepgramSession(deepgramKey = deepgramKey, enableOpus = false)
        }
    }

    // Returns true if Opus watchdog triggered an automatic switch to raw PCM
    private suspend fun runDeepgramSession(deepgramKey: String, enableOpus: Boolean): Boolean {
        lastArabicDisplayedMs = System.currentTimeMillis()
        lastFinalDisplayedMs = 0L
        var lastSentText = ""
        val cfg = TranslationSettingsStore.currentConfig
        val dgLangCode = cfg.deepgramLanguage.code

        val opusEncoder = if (enableOpus) {
            OpusOggStreamEncoder.tryCreate(sampleRate = SAMPLE_RATE, channelCount = 1, bitRate = 24000)
        } else {
            null
        }
        val usingOpus = opusEncoder != null
        val receivedAnyTranscript = AtomicBoolean(false)
        val socketConnectedAtMs = AtomicLong(0L)
        var activeAudioMs = 0L
        var shouldFallbackToPcm = false

        var lastInterimEmitMs = 0L
        val dgClient = DeepgramStreamingClient(
            apiKey = deepgramKey,
            languageCode = dgLangCode,
            useOggOpusContainer = usingOpus,
            onBuildStreamHeader = { opusEncoder?.resetAndBuildHeaders() },
            scope = serviceScope,
            onTranscript = { rawText, isFinal ->
                receivedAnyTranscript.set(true)
                if (isPaused) return@DeepgramStreamingClient
                val text = rawText.trim()
                if (text.isEmpty() || text == lastSentText) return@DeepgramStreamingClient
                val epochNow = translationEpoch.get()
                if (isFinal) {
                    lastSentText = text
                    lastInterimEmitMs = System.currentTimeMillis()
                    pendingTranslationFlow.tryEmit(Triple(text, true, epochNow))
                } else {
                    // Smart Interim: keep lip-sync tight during long continuous speech (>= 6 words)
                    val nowMs = System.currentTimeMillis()
                    val wordCount = text.split(' ').count { it.isNotBlank() }
                    if (wordCount >= 6 && nowMs - lastInterimEmitMs >= 850L) {
                        lastSentText = text
                        lastInterimEmitMs = nowMs
                        pendingTranslationFlow.tryEmit(Triple(text, false, epochNow))
                    }
                }
            },
            onStatusChanged = { connected, errorMsg ->
                if (connected) {
                    socketConnectedAtMs.compareAndSet(0L, System.currentTimeMillis())
                    _subtitleState.update { it.copy(status = PipelineStatus.Listening) }
                } else if (!errorMsg.isNullOrBlank()) {
                    _subtitleState.update { it.copy(status = PipelineStatus.Error(errorMsg)) }
                }
            }
        )

        try {
            dgClient.connect()
            if (audioRecord?.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                audioRecord?.startRecording()
            }
            _subtitleState.update { it.copy(status = PipelineStatus.Listening) }

            val buffer = ByteArray(1920) // 60ms = 3x 20ms Opus frames at 16kHz 16-bit mono
            var lastKeepAliveMs = System.currentTimeMillis()
            var continuousSilenceMs = 0L
            var hasClearedForSilence = false

            while (captureJob?.isActive == true && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                val bytesRead = audioRecord?.read(buffer, 0, buffer.size) ?: -1
                if (bytesRead <= 0) continue

                val now = System.currentTimeMillis()
                if (!isPaused) {
                    val rms = computeRms(buffer, bytesRead)
                    if (rms < 110.0) {
                        continuousSilenceMs += 60L
                        // Video switched or paused (>= 1.5s silence): immediately clear old subtitle & reset context!
                        if (continuousSilenceMs >= 1500L && !hasClearedForSilence) {
                            hasClearedForSilence = true
                            translationEpoch.incrementAndGet()
                            lastSentText = ""
                            lastEnglishSentence = ""
                            translator.clearSceneHistory()
                            if (_subtitleState.value.arabicText.isNotEmpty()) {
                                _subtitleState.update { it.copy(arabicText = "", originalEnglishText = "") }
                            }
                        }
                    } else {
                        continuousSilenceMs = 0L
                        hasClearedForSilence = false
                        if (usingOpus && !receivedAnyTranscript.get() && socketConnectedAtMs.get() > 0L && rms > 160.0) {
                            activeAudioMs += 60L
                            // If 8 seconds of real audio produced 0 transcripts in Opus mode, switch seamlessly to PCM!
                            if (activeAudioMs >= 8000L) {
                                shouldFallbackToPcm = true
                                break
                            }
                        }
                    }

                    if (opusEncoder != null) {
                        val oggPage = opusEncoder.encodePcmToOggPage(buffer, bytesRead)
                        if (oggPage != null && oggPage.isNotEmpty()) {
                            dgClient.sendPcmAudio(oggPage, oggPage.size)
                        }
                    } else {
                        dgClient.sendPcmAudio(buffer, bytesRead)
                    }
                }

                if (now - lastKeepAliveMs >= 8000L) {
                    dgClient.sendKeepAlive()
                    lastKeepAliveMs = now
                }

                if (lastArabicDisplayedMs > 0L && now - lastArabicDisplayedMs > SILENCE_CLEAR_MS && _subtitleState.value.arabicText.isNotEmpty()) {
                    _subtitleState.update { it.copy(arabicText = "", originalEnglishText = "") }
                }
            }
        } finally {
            dgClient.close()
            opusEncoder?.release()
        }
        return shouldFallbackToPcm
    }

    // Ultra-low-latency live audio capture using Groq Whisper + 250ms rolling overlap + direct single-hop translation
    private suspend fun runGroqWhisperLoop(groqKey: String) {
        whisperJob = serviceScope.launch(Dispatchers.IO) {
            pendingWhisperAudioFlow.collect { pcmBytes ->
                val rawEnglish = translator.transcribeAudioViaGroqWhisper(
                    pcm16Mono16k = pcmBytes,
                    apiKey = groqKey
                )
                if (!rawEnglish.isNullOrBlank()) {
                    val prev = lastEnglishSentence
                    val english = deduplicateOverlap(prev, rawEnglish)
                    if (english.isNotBlank()) {
                        lastEnglishSentence = english
                        val arabic = translator.translateToArabic(english, prev)
                        if (arabic.isNotBlank()) {
                            _subtitleState.update {
                                it.copy(
                                    originalEnglishText = english,
                                    arabicText = arabic
                                )
                            }
                        }
                    }
                }
            }
        }

        audioRecord?.startRecording()
        _subtitleState.update { it.copy(status = PipelineStatus.Listening) }

        val buffer = ByteArray(2048)
        val speechBuffer = ByteArrayOutputStream()
        val overlapBytesSize = 8000 // 250ms at 16kHz, 16-bit mono
        var lastTailOverlap = ByteArray(0)
        var speechStartedMs = 0L
        var lastVoiceMs = System.currentTimeMillis()
        var lastSubtitleMs = System.currentTimeMillis()
        val rmsThreshold = 300.0

        while (captureJob?.isActive == true && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
            val bytesRead = audioRecord?.read(buffer, 0, buffer.size) ?: -1
            if (bytesRead <= 0) continue

            val now = System.currentTimeMillis()
            val rms = computeRms(buffer, bytesRead)

            if (rms >= rmsThreshold) {
                if (speechBuffer.size() == 0) {
                    speechStartedMs = now
                    if (lastTailOverlap.isNotEmpty()) {
                        speechBuffer.write(lastTailOverlap)
                    }
                }
                speechBuffer.write(buffer, 0, bytesRead)
                lastVoiceMs = now
            } else if (speechBuffer.size() > 0) {
                speechBuffer.write(buffer, 0, bytesRead)
            }

            val speechDurationMs = if (speechBuffer.size() > 0) now - speechStartedMs else 0L
            val silenceAfterVoiceMs = now - lastVoiceMs

            val shouldFlush =
                (speechBuffer.size() > 0 && speechDurationMs >= 900L && silenceAfterVoiceMs >= 240L) ||
                    (speechBuffer.size() > 0 && speechDurationMs >= 2200L)

            if (shouldFlush) {
                val clip = speechBuffer.toByteArray()
                // Keep last 250ms only if speaker is still talking continuously (prevents chopped words)
                lastTailOverlap = if (silenceAfterVoiceMs < 180L && clip.size > overlapBytesSize) {
                    clip.copyOfRange(clip.size - overlapBytesSize, clip.size)
                } else {
                    ByteArray(0)
                }
                speechBuffer.reset()
                lastSubtitleMs = now
                pendingWhisperAudioFlow.tryEmit(clip)
            } else if (speechBuffer.size() == 0 &&
                now - lastSubtitleMs > SILENCE_CLEAR_MS &&
                _subtitleState.value.arabicText.isNotEmpty()
            ) {
                lastTailOverlap = ByteArray(0)
                _subtitleState.update { it.copy(arabicText = "", originalEnglishText = "") }
            }
        }
    }

    // Removes repeated words at the boundary caused by the 250ms rolling audio overlap
    private fun deduplicateOverlap(previous: String, current: String): String {
        val prevWords = previous.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val currWords = current.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (prevWords.isEmpty() || currWords.isEmpty()) return current.trim()

        fun norm(w: String): String = w.lowercase().replace(Regex("[^\\p{L}\\p{N}]"), "")

        val maxOverlap = minOf(4, prevWords.size, currWords.size)
        for (len in maxOverlap downTo 1) {
            var allMatch = true
            for (i in 0 until len) {
                val a = norm(prevWords[prevWords.size - len + i])
                val b = norm(currWords[i])
                if (a.isEmpty() || a != b) {
                    allMatch = false
                    break
                }
            }
            if (allMatch) {
                return currWords.drop(len).joinToString(" ").trim()
            }
        }
        return current.trim()
    }

    private fun computeRms(pcm16: ByteArray, length: Int): Double {
        var sumSq = 0.0
        val samples = length / 2
        if (samples <= 0) return 0.0
        for (i in 0 until samples) {
            val lo = pcm16[i * 2].toInt() and 0xFF
            val hi = pcm16[i * 2 + 1].toInt()
            val sample = (hi shl 8) or lo
            sumSq += sample * sample.toDouble()
        }
        return sqrt(sumSq / samples)
    }

    private suspend fun runVoskOfflineLoop() {
        val modelDir = VoskModelManager.ensureModelDownloaded(applicationContext) { progress ->
            _subtitleState.update {
                it.copy(
                    status = PipelineStatus.DownloadingModels(
                        "جاري تحميل نموذج التعرف على الصوت ($progress%)...",
                        progress
                    )
                )
            }
        }

        voskModel?.close()
        voskModel = Model(modelDir.absolutePath)
        recognizer?.close()
        recognizer = Recognizer(voskModel, SAMPLE_RATE.toFloat())

        audioRecord?.startRecording()
        _subtitleState.update { it.copy(status = PipelineStatus.Listening) }

        val buffer = ByteArray(2048)
        var consumedWordsCount = 0
        var lastSeenPartial = ""
        var lastPartialChangeMs = System.currentTimeMillis()
        var lastEmittedSentence = ""
        var lastSubtitleShownMs = System.currentTimeMillis()

        while (captureJob?.isActive == true && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
            val bytesRead = audioRecord?.read(buffer, 0, buffer.size) ?: -1
            if (bytesRead <= 0) continue

            val rec = recognizer ?: break
            val isFinal = rec.acceptWaveForm(buffer, bytesRead)
            val now = System.currentTimeMillis()

            if (isFinal) {
                val finalEnglish = parseJsonField(rec.result, "text")
                val words = finalEnglish.split(Regex("\\s+")).filter { it.isNotBlank() }
                val remaining = if (consumedWordsCount < words.size) words.drop(consumedWordsCount) else emptyList()
                consumedWordsCount = 0
                lastSeenPartial = ""

                if (remaining.isNotEmpty()) {
                    val sentence = remaining.takeLast(MAX_WORDS_PER_CUE + 3).joinToString(" ")
                    if (sentence != lastEmittedSentence) {
                        lastEmittedSentence = sentence
                        lastSubtitleShownMs = now
                        pendingTranslationFlow.tryEmit(Triple(sentence, true, translationEpoch.get()))
                    }
                }
            } else {
                val partialEnglish = parseJsonField(rec.partialResult, "partial")

                if (partialEnglish.isBlank()) {
                    if (now - lastSubtitleShownMs > SILENCE_CLEAR_MS &&
                        _subtitleState.value.arabicText.isNotEmpty()
                    ) {
                        _subtitleState.update { it.copy(arabicText = "", originalEnglishText = "") }
                    }
                    continue
                }

                if (partialEnglish != lastSeenPartial) {
                    lastSeenPartial = partialEnglish
                    lastPartialChangeMs = now
                }

                val words = partialEnglish.split(Regex("\\s+")).filter { it.isNotBlank() }
                if (words.size < consumedWordsCount) consumedWordsCount = 0
                val remaining = words.drop(consumedWordsCount)

                if (remaining.size >= MAX_WORDS_PER_CUE) {
                    val cueWords = remaining.take(MAX_WORDS_PER_CUE)
                    val sentence = cueWords.joinToString(" ")
                    consumedWordsCount += cueWords.size
                    lastEmittedSentence = sentence
                    lastSubtitleShownMs = now
                    pendingTranslationFlow.tryEmit(Triple(sentence, true, translationEpoch.get()))
                } else if (remaining.size >= 3 && (now - lastPartialChangeMs) >= PAUSE_COMMIT_MS) {
                    val sentence = remaining.joinToString(" ")
                    if (sentence != lastEmittedSentence) {
                        consumedWordsCount += remaining.size
                        lastEmittedSentence = sentence
                        lastSubtitleShownMs = now
                        pendingTranslationFlow.tryEmit(Triple(sentence, true, translationEpoch.get()))
                    }
                }
            }
        }
    }

    private fun parseJsonField(json: String?, key: String): String {
        if (json.isNullOrBlank()) return ""
        return runCatching { JSONObject(json).optString(key, "").trim() }.getOrDefault("")
    }

    private fun stopPipeline() {
        captureJob?.cancel()
        captureJob = null
        translationJob?.cancel()
        translationJob = null
        whisperJob?.cancel()
        whisperJob = null

        runCatching {
            audioRecord?.stop()
            audioRecord?.release()
        }
        audioRecord = null

        runCatching { mediaProjection?.stop() }
        mediaProjection = null

        runCatching { recognizer?.close() }
        recognizer = null

        overlaySyncJob?.cancel()
        styleSyncJob?.cancel()
        floatingWindow?.hide()
        floatingWindow = null
        isPaused = false

        runCatching { voskModel?.close() }
        voskModel = null

        _subtitleState.update {
            SubtitleState(
                isLiveEnabled = false,
                sourceMode = SubtitleSourceMode.NONE,
                arabicText = "",
                status = PipelineStatus.Idle
            )
        }
    }

    override fun onDestroy() {
        stopPipeline()
        translator.close()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "الترجمة الفورية للفيديو",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "يعمل في الخلفية لالتقاط صوت الفيديو وترجمته إلى العربية"
        }
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, AudioCaptureService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FloatSub - الترجمة العائمة نشطة")
            .setContentText("يتم الآن ترجمة صوت الفيديو إلى العربية")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف", stopIntent)
            .build()
    }
}
