package com.cinemasub.browser.browser

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

object AdBlocker {

    private val emptyResponseBytes = ByteArray(0)

    // Comprehensive O(1) blocklist: Major ad networks + Streaming pop-under/redirect networks
    private val blockedHosts: Set<String> = hashSetOf(
        // Google / YouTube / Big Tech Ads & Trackers
        "doubleclick.net",
        "googleadservices.com",
        "googlesyndication.com",
        "adservice.google.com",
        "pagead2.googlesyndication.com",
        "tpc.googlesyndication.com",
        "google-analytics.com",
        "googletagmanager.com",
        "googletagservices.com",
        "ads.youtube.com",
        "imasdk.googleapis.com",
        "amazon-adsystem.com",
        "ads.facebook.com",
        "an.facebook.com",
        "pixel.facebook.com",
        "ads.twitter.com",
        "ads-api.twitter.com",
        "analytics.tiktok.com",
        "ads.tiktok.com",
        "bat.bing.com",
        "ads.yahoo.com",
        "gemini.yahoo.com",

        // Streaming & Movie Site Pop-up / Pop-under / Redirect Networks
        "popads.net",
        "popcash.net",
        "propellerads.com",
        "propellerclick.com",
        "onclickalgo.com",
        "onclickmax.com",
        "onclickperformance.com",
        "onclkds.com",
        "monetag.com",
        "alwingulla.com",
        "o4ux.com",
        "adsterra.com",
        "highperformanceformat.com",
        "profitabledisplaynetwork.com",
        "profitablecpmrate.com",
        "topcreativeformat.com",
        "hilltopads.net",
        "hilltopads.com",
        "exoclick.com",
        "exosrv.com",
        "realsrv.com",
        "juicyads.com",
        "trafficjunky.net",
        "trafficjunky.com",
        "trafficstars.com",
        "tsyndicate.com",
        "clickadu.com",
        "clickadilla.com",
        "galaksion.com",
        "admaven.com",
        "ad-maven.com",
        "pushame.com",
        "pushwelcome.com",
        "pushnotifications.click",
        "notifpush.com",
        "acscdn.com",
        "adtng.com",
        "adspyglass.com",
        "adskeeper.com",
        "adskeeper.co.uk",
        "bidvertiser.com",
        "yllix.com",
        "a-ads.com",
        "adcash.com",
        "ufpcdn.com",
        "zeroredirect1.com",
        "zeroredirect2.com",
        "bet365.com",
        "1xbet.com",
        "melbet.com",

        // Programmatic, Native & Video Ad Trackers
        "adnxs.com",
        "adsrvr.org",
        "advertising.com",
        "criteo.com",
        "criteo.net",
        "outbrain.com",
        "taboola.com",
        "pubmatic.com",
        "rubiconproject.com",
        "openx.net",
        "casalemedia.com",
        "indexww.com",
        "smartadserver.com",
        "sharethrough.com",
        "teads.tv",
        "yieldmo.com",
        "triplelift.com",
        "33across.com",
        "lijit.com",
        "sovrn.com",
        "scorecardresearch.com",
        "quantserve.com",
        "moatads.com",
        "doubleverify.com",
        "adsafeprotected.com",
        "adcolony.com",
        "applovin.com",
        "unityads.unity3d.com",
        "vungle.com",
        "inmobi.com",
        "chartboost.com",
        "ironsrc.com",
        "mgid.com",
        "revcontent.com",
        "zedo.com",
        "spotxchange.com",
        "springserve.com",
        "lkqd.net",
        "innovid.com",
        "flashtalking.com",
        "serving-sys.com",
        "mediavine.com",
        "adthrive.com",
        "ezoic.net",
        "ezoic.com",
        "buysellads.com",
        "carbonads.net",
        "hotjar.com",
        "clarity.ms",
        "newrelic.com",
        "nr-data.net",
        "sentry.io",
        "segment.io",
        "mixpanel.com",
        "amplitude.com"
    )

    private val blockedUrlPatterns = listOf(
        "/pagead/",
        "/ptracking",
        "/api/stats/ads",
        "/adserver/",
        "/adsystem/",
        "/ads/vast",
        "/vast.xml",
        "/vpaid",
        "ad_type=",
        "doubleclick",
        "googlesyndication",
        "popunder",
        "pop-under",
        "popads",
        "adsterra",
        "propeller",
        "clicktrack",
        "banner_ad",
        "/banners/ad"
    )

    fun isAd(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
        val host = uri.host?.lowercase() ?: return false

        var currentHost = host
        while (currentHost.contains('.')) {
            if (currentHost in blockedHosts) return true
            currentHost = currentHost.substringAfter('.')
        }

        val lowerUrl = url.lowercase()
        return blockedUrlPatterns.any { lowerUrl.contains(it) }
    }

    fun isBlockedNavigation(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val lower = url.lowercase()
        // Block forced app-store / intent redirects triggered by streaming popups
        if (lower.startsWith("intent://") ||
            lower.startsWith("market://") ||
            lower.startsWith("tg://") ||
            lower.startsWith("whatsapp://")
        ) {
            return true
        }
        return isAd(url)
    }

    fun createEmptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(emptyResponseBytes))

    // Cosmetic + Anti-Popup + Anti-Click-Hijack Script (toggleable ON/OFF)
    fun getCosmeticAndPopupShieldScript(enabled: Boolean): String = if (enabled) {
        """
        (function() {
            window.__cinemaAdBlockEnabled = true;

            // 1. Block window.open popups cleanly
            if (!window.__origWindowOpen) {
                window.__origWindowOpen = window.open;
            }
            window.open = function() {
                if (window.__cinemaAdBlockEnabled) {
                    return null;
                }
                return window.__origWindowOpen.apply(window, arguments);
            };

            // 2. Neutralize target="_blank" popup hijacks pointing to ad domains
            if (!window.__cinemaPopupClickGuard) {
                window.__cinemaPopupClickGuard = true;
                document.addEventListener("click", function(e) {
                    if (!window.__cinemaAdBlockEnabled) return;
                    var el = e.target;
                    while (el && el.tagName !== "A" && el !== document.body) {
                        el = el.parentElement;
                    }
                    if (el && el.tagName === "A") {
                        var href = (el.getAttribute("href") || "").toLowerCase();
                        if (el.target === "_blank" && (
                            href.indexOf("pop") !== -1 ||
                            href.indexOf("click") !== -1 ||
                            href.indexOf("redirect") !== -1 ||
                            href.indexOf("bet") !== -1 ||
                            href.indexOf("ad") !== -1
                        )) {
                            e.preventDefault();
                            e.stopPropagation();
                        }
                    }
                }, true);
            }

            // 3. Cosmetic CSS to hide ad banners, floating popups, and invisible click-overlays
            var styleId = "cinemasub-adblock-css";
            if (!document.getElementById(styleId)) {
                var style = document.createElement("style");
                style.id = styleId;
                style.textContent = [
                    "ins.adsbygoogle,",
                    "[id*='google_ads'],",
                    "[id^='div-gpt-ad'],",
                    "[class*='adsbygoogle'],",
                    ".ytp-ad-module,",
                    ".ytp-ad-overlay-container,",
                    ".ytp-ad-player-overlay,",
                    "ytd-ad-slot-renderer,",
                    "ytm-promoted-sparkles-web-renderer,",
                    "ytm-companion-ad-renderer,",
                    ".ad-container, .ad-banner, .ads-banner, .ad-wrapper,",
                    ".popup-ad, .popunder, .floating-ad, .sticky-ad,",
                    "iframe[src*='doubleclick'], iframe[src*='googlesyndication'],",
                    "iframe[src*='adsterra'], iframe[src*='exoclick'], iframe[src*='popads'] {",
                    "  display: none !important;",
                    "  visibility: hidden !important;",
                    "  height: 0 !important;",
                    "  pointer-events: none !important;",
                    "}"
                ].join("\n");
                (document.head || document.documentElement).appendChild(style);
            }

            // 4. Auto-skip YouTube video ads if any slip through
            if (!window.__cinemaYtAdSkipper) {
                window.__cinemaYtAdSkipper = setInterval(function() {
                    if (!window.__cinemaAdBlockEnabled) return;
                    var skipBtn = document.querySelector(".ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern");
                    if (skipBtn) skipBtn.click();
                    var adShowing = document.querySelector(".ad-showing video");
                    if (adShowing && isFinite(adShowing.duration) && adShowing.duration > 0) {
                        adShowing.currentTime = adShowing.duration;
                    }
                }, 500);
            }
        })();
        """.trimIndent()
    } else {
        """
        (function() {
            window.__cinemaAdBlockEnabled = false;
            var style = document.getElementById("cinemasub-adblock-css");
            if (style) style.remove();
        })();
        """.trimIndent()
    }
}
