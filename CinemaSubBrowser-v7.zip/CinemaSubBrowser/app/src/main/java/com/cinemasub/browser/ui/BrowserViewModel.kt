package com.cinemasub.browser.ui

import android.content.Context
import android.util.Patterns
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cinemasub.browser.audio.AudioCaptureService
import com.cinemasub.browser.model.AiTranslationConfig
import com.cinemasub.browser.model.Bookmark
import com.cinemasub.browser.model.PipelineStatus
import com.cinemasub.browser.model.QuickLink
import com.cinemasub.browser.model.SubtitleBgOpacity
import com.cinemasub.browser.model.SubtitleFontSize
import com.cinemasub.browser.model.SubtitleSourceMode
import com.cinemasub.browser.model.SubtitleState
import com.cinemasub.browser.model.SubtitleStyleConfig
import com.cinemasub.browser.model.SubtitleTextColor
import com.cinemasub.browser.model.TranslationEngine
import com.cinemasub.browser.translation.ArabicTranslator
import com.cinemasub.browser.translation.TranslationSettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.net.URLEncoder

data class BrowserUiState(
    val currentUrl: String = "",
    val addressBarText: String = "",
    val isHomeVisible: Boolean = true,
    val isLoading: Boolean = false,
    val loadingProgress: Int = 0,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val adBlockerEnabled: Boolean = TranslationSettingsStore.isAdBlockerEnabled,
    val blockedAdsCount: Int = 0,
    val isFullscreenVideo: Boolean = false,
    val showFullscreenPrompt: Boolean = false,
    val webCaptionEnabled: Boolean = false,
    val hasReceivedWebCaption: Boolean = false,
    val subtitleStyle: SubtitleStyleConfig = SubtitleStyleConfig(),
    val aiConfig: AiTranslationConfig = TranslationSettingsStore.currentConfig,
    val bookmarks: List<Bookmark> = listOf(
        Bookmark("YouTube", "https://m.youtube.com"),
        Bookmark("Vimeo", "https://vimeo.com"),
        Bookmark("TED Talks", "https://www.ted.com/talks")
    )
)

class BrowserViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(BrowserUiState())
    val uiState: StateFlow<BrowserUiState> = _uiState.asStateFlow()

    private val webCaptionTranslator = ArabicTranslator()
    private val _webSubtitleState = MutableStateFlow(SubtitleState())

    private val incomingWebCues = MutableSharedFlow<String>(
        replay = 0,
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    // Background lookahead queue: pre-translates upcoming cues BEFORE the video reaches them
    private val preloadCues = MutableSharedFlow<String>(
        replay = 0,
        extraBufferCapacity = 6,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    val subtitleState: StateFlow<SubtitleState> = combine(
        _webSubtitleState,
        AudioCaptureService.subtitleState
    ) { webState, audioState ->
        when {
            audioState.isLiveEnabled -> audioState
            webState.isLiveEnabled -> webState
            else -> SubtitleState()
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SubtitleState()
    )

    val quickLinks = listOf(
        QuickLink("YouTube", "https://m.youtube.com", Color(0xFFE50914)),
        QuickLink("Vimeo", "https://vimeo.com", Color(0xFF1AB7EA)),
        QuickLink("Dailymotion", "https://www.dailymotion.com", Color(0xFF0066DC)),
        QuickLink("Google", "https://www.google.com", Color(0xFF34A853))
    )

    init {
        viewModelScope.launch(Dispatchers.IO) {
            webCaptionTranslator.ensureModelDownloaded()
        }

        // Background pre-translator for upcoming video lines (eliminates AI latency!)
        viewModelScope.launch(Dispatchers.IO) {
            preloadCues.collect { upcomingCue ->
                if (_uiState.value.webCaptionEnabled) {
                    webCaptionTranslator.preloadToCache(upcomingCue)
                }
            }
        }

        // Active cue display pipeline
        viewModelScope.launch(Dispatchers.IO) {
            incomingWebCues.collectLatest { rawCue ->
                if (!_uiState.value.webCaptionEnabled) return@collectLatest

                if (rawCue.isBlank()) {
                    _webSubtitleState.update {
                        it.copy(arabicText = "", originalEnglishText = "")
                    }
                    return@collectLatest
                }

                _uiState.update { it.copy(hasReceivedWebCaption = true) }
                val arabic = webCaptionTranslator.translateToArabic(rawCue)
                if (arabic.isNotBlank() && _uiState.value.webCaptionEnabled) {
                    _webSubtitleState.update {
                        it.copy(
                            isLiveEnabled = true,
                            sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                            originalEnglishText = rawCue,
                            arabicText = arabic,
                            status = PipelineStatus.Listening
                        )
                    }
                }
            }
        }
    }

    fun loadSavedSettings(context: Context) {
        TranslationSettingsStore.init(context)
        _uiState.update {
            it.copy(
                aiConfig = TranslationSettingsStore.currentConfig,
                adBlockerEnabled = TranslationSettingsStore.isAdBlockerEnabled
            )
        }
    }

    fun updateTranslationEngine(context: Context, engine: TranslationEngine) {
        val updated = _uiState.value.aiConfig.copy(engine = engine)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated) }
    }

    fun updateGeminiApiKey(context: Context, key: String) {
        val updated = _uiState.value.aiConfig.copy(geminiApiKey = key)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated) }
    }

    fun updateGroqApiKey(context: Context, key: String) {
        val updated = _uiState.value.aiConfig.copy(groqApiKey = key)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated) }
    }

    fun toggleAdBlocker(context: Context) {
        val next = !_uiState.value.adBlockerEnabled
        TranslationSettingsStore.setAdBlockerEnabled(context, next)
        _uiState.update { it.copy(adBlockerEnabled = next) }
    }

    fun setAdBlockerEnabled(context: Context, enabled: Boolean) {
        TranslationSettingsStore.setAdBlockerEnabled(context, enabled)
        _uiState.update { it.copy(adBlockerEnabled = enabled) }
    }

    fun onWebCaptionReceived(rawCue: String) {
        if (!_uiState.value.webCaptionEnabled) return
        incomingWebCues.tryEmit(rawCue)
    }

    fun onPreloadCaptionReceived(upcomingCue: String) {
        if (!_uiState.value.webCaptionEnabled) return
        preloadCues.tryEmit(upcomingCue)
    }

    fun setWebCaptionEnabled(enabled: Boolean) {
        _uiState.update {
            it.copy(
                webCaptionEnabled = enabled,
                hasReceivedWebCaption = if (enabled) false else it.hasReceivedWebCaption
            )
        }
        if (enabled) {
            _webSubtitleState.update {
                SubtitleState(
                    isLiveEnabled = true,
                    sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                    arabicText = "",
                    status = PipelineStatus.Listening
                )
            }
        } else {
            _webSubtitleState.update { SubtitleState() }
        }
    }

    fun resolveInputToUrl(rawInput: String): String {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return "https://www.google.com"
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            return trimmed
        }
        val looksLikeDomain = !trimmed.contains(" ") &&
            trimmed.contains(".") &&
            Patterns.WEB_URL.matcher("https://$trimmed").matches()

        return if (looksLikeDomain) {
            "https://$trimmed"
        } else {
            val encoded = URLEncoder.encode(trimmed, "UTF-8")
            "https://www.google.com/search?q=$encoded"
        }
    }

    fun onAddressBarChanged(text: String) {
        _uiState.update { it.copy(addressBarText = text) }
    }

    fun onNavigateTo(url: String) {
        _uiState.update {
            it.copy(
                currentUrl = url,
                addressBarText = url,
                isHomeVisible = false,
                blockedAdsCount = 0,
                hasReceivedWebCaption = false
            )
        }
    }

    fun goHome() {
        _uiState.update {
            it.copy(isHomeVisible = true, addressBarText = "")
        }
    }

    fun onPageStarted(url: String) {
        _uiState.update {
            it.copy(
                currentUrl = url,
                addressBarText = url,
                isLoading = true,
                hasReceivedWebCaption = false
            )
        }
    }

    fun onPageFinished(url: String, canGoBack: Boolean, canGoForward: Boolean) {
        _uiState.update {
            it.copy(
                currentUrl = url,
                addressBarText = url,
                isLoading = false,
                canGoBack = canGoBack,
                canGoForward = canGoForward
            )
        }
    }

    fun onProgressChanged(progress: Int) {
        _uiState.update { it.copy(loadingProgress = progress, isLoading = progress < 100) }
    }

    fun incrementBlockedAds() {
        _uiState.update { it.copy(blockedAdsCount = it.blockedAdsCount + 1) }
    }

    fun onFullscreenChanged(isFullscreen: Boolean) {
        _uiState.update { state ->
            val shouldPrompt = isFullscreen && !subtitleState.value.isLiveEnabled
            state.copy(
                isFullscreenVideo = isFullscreen,
                showFullscreenPrompt = shouldPrompt
            )
        }
    }

    fun dismissFullscreenPrompt() {
        _uiState.update { it.copy(showFullscreenPrompt = false) }
    }

    fun addBookmark(title: String, url: String) {
        if (url.isBlank()) return
        _uiState.update { state ->
            if (state.bookmarks.any { it.url == url }) state
            else state.copy(bookmarks = state.bookmarks + Bookmark(title.ifBlank { url }, url))
        }
    }

    fun removeBookmark(url: String) {
        _uiState.update { state ->
            state.copy(bookmarks = state.bookmarks.filterNot { it.url == url })
        }
    }

    fun updateFontSize(size: SubtitleFontSize) {
        _uiState.update { it.copy(subtitleStyle = it.subtitleStyle.copy(fontSize = size)) }
    }

    fun updateTextColor(color: SubtitleTextColor) {
        _uiState.update { it.copy(subtitleStyle = it.subtitleStyle.copy(textColor = color)) }
    }

    fun updateBgOpacity(bg: SubtitleBgOpacity) {
        _uiState.update { it.copy(subtitleStyle = it.subtitleStyle.copy(bgOpacity = bg)) }
    }

    fun updateVerticalBias(bias: Float) {
        _uiState.update {
            it.copy(subtitleStyle = it.subtitleStyle.copy(verticalBias = bias.coerceIn(0.08f, 0.92f)))
        }
    }

    override fun onCleared() {
        webCaptionTranslator.close()
        super.onCleared()
    }
}
