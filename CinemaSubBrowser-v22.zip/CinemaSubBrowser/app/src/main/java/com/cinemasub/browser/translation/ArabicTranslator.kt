package com.cinemasub.browser.translation

import com.cinemasub.browser.model.AiTranslationConfig
import com.cinemasub.browser.model.SubtitleDialect
import com.cinemasub.browser.model.TranslationEngine
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Collections
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class ArabicTranslator {

    private val options = TranslatorOptions.Builder()
        .setSourceLanguage(TranslateLanguage.ENGLISH)
        .setTargetLanguage(TranslateLanguage.ARABIC)
        .build()

    private val mlKitTranslator: Translator = Translation.getClient(options)
    private val isOfflineReady = AtomicBoolean(false)

    @Volatile
    private var cachedGeminiModel: String? = null

    @Volatile
    private var cachedGroqModel: String? = null

    @Volatile
    private var cachedOpenRouterModel: String? = null

    private val roundRobinCounter = AtomicInteger(0)

    private val cache: MutableMap<String, String> = Collections.synchronizedMap(
        object : LinkedHashMap<String, String>(800, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
                return size > 750
            }
        }
    )

    private fun systemPromptFor(dialect: SubtitleDialect, isBatch: Boolean): String {
        val styleDesc = when (dialect) {
            SubtitleDialect.CINEMA_MSA ->
                "professional Netflix/MBC2 Arabic movie subtitle translator using natural, concise Modern Standard Arabic"
            SubtitleDialect.EGYPTIAN_LIGHT ->
                "professional Arabic subtitle translator using natural, light, clear Egyptian Arabic suitable for movies and YouTube"
        }
        val pageTitle = TranslationSettingsStore.currentPageTitle
            .replace(Regex("[\\r\\n\"']+"), " ")
            .trim()
            .take(80)
        val titleContext = if (pageTitle.length >= 3) {
            " Video/Movie title context: \"$pageTitle\" (keep character names and movie terms accurate)."
        } else ""

        return if (isBatch) {
            "You are a $styleDesc.$titleContext " +
                "Translate all numbered dialogue lines together as one coherent movie scene, keeping consistent gender, pronouns, and flow. " +
                "Translate idioms and slang by meaning, not literally. " +
                "Return ONLY the translated Arabic lines keeping the EXACT same numbering format '1|translation', '2|translation', etc. " +
                "No markdown, no asterisks, no quotes, no extra commentary."
        } else {
            "You are a $styleDesc.$titleContext " +
                "Translate ONLY the current dialogue line into natural, idiomatic, concise Arabic suitable for cinema subtitles. " +
                "Translate idioms and slang by meaning, not literally. " +
                "Output ONLY the Arabic translation text (no markdown, no asterisks, no quotes, no notes)."
        }
    }

    suspend fun ensureModelDownloaded() {
        if (isOfflineReady.get()) return
        runCatching {
            val conditions = DownloadConditions.Builder().build()
            mlKitTranslator.downloadModelIfNeeded(conditions).await()
            isOfflineReady.set(true)
        }
    }

    // Ultra-accurate Groq Whisper transcription for videos without embedded captions
    suspend fun transcribeAudioViaGroqWhisper(pcm16Mono16k: ByteArray, apiKey: String, contextPrompt: String = ""): String? =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank() || pcm16Mono16k.size < 3200) return@withContext null
            runCatching {
                val wavBytes = pcmToWav(pcm16Mono16k, 16000, 1, 16)
                val boundary = "----CinemaSubBoundary${System.currentTimeMillis()}"
                val url = URL("https://api.groq.com/openai/v1/audio/transcriptions")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 3000
                    readTimeout = 4500
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
                    setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                    setRequestProperty("Connection", "keep-alive")
                }

                DataOutputStream(conn.outputStream).use { out ->
                    // model field
                    out.writeBytes("--$boundary\r\n")
                    out.writeBytes("Content-Disposition: form-data; name=\"model\"\r\n\r\n")
                    out.writeBytes("whisper-large-v3-turbo\r\n")

                    // response_format field
                    out.writeBytes("--$boundary\r\n")
                    out.writeBytes("Content-Disposition: form-data; name=\"response_format\"\r\n\r\n")
                    out.writeBytes("json\r\n")

                    // temperature field (0.0 reduces hallucinations)
                    out.writeBytes("--$boundary\r\n")
                    out.writeBytes("Content-Disposition: form-data; name=\"temperature\"\r\n\r\n")
                    out.writeBytes("0\r\n")

                    // prompt field: feeds previous sentence + title to Whisper for accurate accents & character names
                    val combinedPrompt = buildString {
                        val title = TranslationSettingsStore.currentPageTitle.trim().take(60)
                        if (title.isNotEmpty()) append(title).append(". ")
                        if (contextPrompt.isNotBlank()) append(contextPrompt.trim().takeLast(180))
                    }.trim()
                    if (combinedPrompt.isNotEmpty()) {
                        out.writeBytes("--$boundary\r\n")
                        out.writeBytes("Content-Disposition: form-data; name=\"prompt\"\r\n\r\n")
                        out.write(combinedPrompt.toByteArray(Charsets.UTF_8))
                        out.writeBytes("\r\n")
                    }

                    // file field
                    out.writeBytes("--$boundary\r\n")
                    out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"clip.wav\"\r\n")
                    out.writeBytes("Content-Type: audio/wav\r\n\r\n")
                    out.write(wavBytes)
                    out.writeBytes("\r\n--$boundary--\r\n")
                    out.flush()
                }

                if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                    conn.disconnect()
                    return@runCatching null
                }

                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val text = JSONObject(body).optString("text", "").trim()
                // Filter common Whisper silence hallucinations
                val lower = text.lowercase()
                if (text.length < 2 ||
                    lower == "null" ||
                    lower == "thank you." ||
                    lower == "thanks for watching." ||
                    lower == "you" ||
                    lower.startsWith("subtitles by")
                ) {
                    null
                } else {
                    text
                }
            }.getOrNull()
        }

    private fun pcmToWav(pcmData: ByteArray, sampleRate: Int, channels: Int, bitsPerSample: Int): ByteArray {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val dataSize = pcmData.size
        val chunkSize = 36 + dataSize
        val baos = ByteArrayOutputStream(44 + dataSize)
        fun writeLEInt(v: Int) {
            baos.write(v and 0xFF)
            baos.write((v shr 8) and 0xFF)
            baos.write((v shr 16) and 0xFF)
            baos.write((v shr 24) and 0xFF)
        }
        fun writeLEShort(v: Int) {
            baos.write(v and 0xFF)
            baos.write((v shr 8) and 0xFF)
        }
        baos.write("RIFF".toByteArray())
        writeLEInt(chunkSize)
        baos.write("WAVE".toByteArray())
        baos.write("fmt ".toByteArray())
        writeLEInt(16)
        writeLEShort(1)
        writeLEShort(channels)
        writeLEInt(sampleRate)
        writeLEInt(byteRate)
        writeLEShort(channels * bitsPerSample / 8)
        writeLEShort(bitsPerSample)
        baos.write("data".toByteArray())
        writeLEInt(dataSize)
        baos.write(pcmData)
        return baos.toByteArray()
    }

    // Batch translate 8-10 upcoming cues in ONE coherent scene request!
    suspend fun preloadBatchToCache(cues: List<String>, recentContext: List<String> = emptyList()) {
        val config = TranslationSettingsStore.currentConfig
        val uncached = cues
            .map { it.trim() }
            .filter { it.isNotEmpty() && !isAlreadyArabic(it) }
            .distinct()
            .filter { !cache.containsKey(cacheKeyFor(config, it)) }

        if (uncached.isEmpty()) return
        if (config.engine == TranslationEngine.GOOGLE_FREE) {
            for (line in uncached.take(4)) {
                translateToArabic(line)
            }
            return
        }

        val sb = StringBuilder()
        if (recentContext.isNotEmpty()) {
            sb.append("Recent scene context (do not translate):\n")
            recentContext.takeLast(2).forEach { sb.append("- ").append(it).append("\n") }
            sb.append("\n")
        }
        sb.append("Translate these numbered lines:\n")
        uncached.forEachIndexed { index, line ->
            sb.append("${index + 1}|$line\n")
        }

        val sysPrompt = systemPromptFor(config.dialect, isBatch = true)
        val rawBatch = callActiveAiRaw(
            sysPrompt = sysPrompt,
            userPrompt = sb.toString(),
            config = config,
            maxTokens = (uncached.size * 55).coerceIn(180, 900)
        ) ?: return

        val parsed = parseNumberedBatch(rawBatch, uncached.size)
        for ((idx, arabic) in parsed) {
            if (idx in uncached.indices && arabic.isNotBlank()) {
                val formatted = formatCinemaSubtitle(arabic)
                cache[cacheKeyFor(config, uncached[idx])] = formatted
            }
        }
    }


    // Translate a batch of subtitle cues for Network VTT/SRT interception (returns index -> Arabic text)
    suspend fun translateBatchForSubtitleFile(cues: List<String>): Map<Int, String> {
        if (cues.isEmpty()) return emptyMap()
        val config = TranslationSettingsStore.currentConfig
        val result = mutableMapOf<Int, String>()
        val toTranslateIdx = mutableListOf<Int>()
        val toTranslateText = mutableListOf<String>()

        cues.forEachIndexed { idx, raw ->
            val cleaned = raw.trim()
            if (cleaned.isEmpty() || isAlreadyArabic(cleaned)) {
                result[idx] = cleaned
            } else {
                val cached = cache[cacheKeyFor(config, cleaned)]
                if (cached != null) {
                    result[idx] = cached
                } else {
                    toTranslateIdx.add(idx)
                    toTranslateText.add(cleaned)
                }
            }
        }

        if (toTranslateText.isEmpty()) return result

        if (config.engine == TranslationEngine.GOOGLE_FREE) {
            toTranslateText.forEachIndexed { i, line ->
                val trLine = translateViaGoogleFree(line)?.let { formatCinemaSubtitle(it) } ?: line
                val origIdx = toTranslateIdx[i]
                result[origIdx] = trLine
                cache[cacheKeyFor(config, line)] = trLine
            }
            return result
        }

        val sb = StringBuilder("Translate these numbered movie subtitle lines:\n")
        toTranslateText.forEachIndexed { i, line ->
            sb.append("${i + 1}|${line.replace("\n", " ")}\n")
        }

        val sysPrompt = systemPromptFor(config.dialect, isBatch = true)
        val rawBatch = callActiveAiRaw(
            sysPrompt = sysPrompt,
            userPrompt = sb.toString(),
            config = config,
            maxTokens = (toTranslateText.size * 55).coerceIn(220, 1400)
        )

        if (rawBatch != null) {
            val parsed = parseNumberedBatch(rawBatch, toTranslateText.size)
            for ((localIdx, arabic) in parsed) {
                if (localIdx in toTranslateIdx.indices && arabic.isNotBlank()) {
                    val origIdx = toTranslateIdx[localIdx]
                    val formatted = formatCinemaSubtitle(arabic)
                    result[origIdx] = formatted
                    cache[cacheKeyFor(config, toTranslateText[localIdx])] = formatted
                }
            }
        }

        // Fill any missed lines with Google Free fallback so no line stays untranslated
        for (i in toTranslateIdx.indices) {
            val origIdx = toTranslateIdx[i]
            if (!result.containsKey(origIdx)) {
                val fallback = translateViaGoogleFree(toTranslateText[i])?.let { formatCinemaSubtitle(it) }
                    ?: toTranslateText[i]
                result[origIdx] = fallback
            }
        }
        return result
    }

    private fun parseNumberedBatch(raw: String, expectedCount: Int): Map<Int, String> {
        val cleaned = raw.replace(Regex("<think>[\\s\\S]*?</think>"), "").replace("*", "")
        val result = mutableMapOf<Int, String>()
        val lineRegex = Regex("^\\s*(\\d+)\\s*[|\\).:-]\\s*(.+)$")
        for (line in cleaned.lines()) {
            val m = lineRegex.find(line.trim()) ?: continue
            val num = m.groupValues[1].toIntOrNull() ?: continue
            val text = m.groupValues[2].trim().trim('"', '\'', '«', '»', ' ')
            if (num in 1..expectedCount && text.isNotEmpty()) {
                result[num - 1] = text
            }
        }
        return result
    }

    private fun cacheKeyFor(config: AiTranslationConfig, text: String): String =
        "${config.engine.name}|${config.dialect.name}|$text"

    suspend fun testAllConfiguredKeys(config: AiTranslationConfig): Pair<Boolean, String> =
        withContext(Dispatchers.IO) {
            when (config.engine) {
                TranslationEngine.GEMINI_AI -> testGeminiKey(config.geminiApiKey.trim(), config.dialect)
                TranslationEngine.GROQ_AI -> testGroqKey(config.groqApiKey.trim(), config.dialect)
                TranslationEngine.OPENROUTER_AI -> testOpenRouterKey(config.openRouterApiKey.trim(), config.dialect)
                TranslationEngine.GOOGLE_FREE -> Pair(true, "ترجمة جوجل المجانية تعمل بدون مفتاح.")
                TranslationEngine.AUTO_HYBRID -> {
                    val lines = mutableListOf<String>()
                    var anySuccess = false
                    if (config.groqApiKey.isNotBlank()) {
                        val (ok, msg) = testGroqKey(config.groqApiKey.trim(), config.dialect)
                        if (ok) anySuccess = true
                        lines.add((if (ok) "✅ Groq (+Whisper): " else "❌ Groq: ") + msg.substringBefore("\n"))
                    }
                    if (config.geminiApiKey.isNotBlank()) {
                        val (ok, msg) = testGeminiKey(config.geminiApiKey.trim(), config.dialect)
                        if (ok) anySuccess = true
                        lines.add((if (ok) "✅ Gemini: " else "❌ Gemini: ") + msg.substringBefore("\n"))
                    }
                    if (config.openRouterApiKey.isNotBlank()) {
                        val (ok, msg) = testOpenRouterKey(config.openRouterApiKey.trim(), config.dialect)
                        if (ok) anySuccess = true
                        lines.add((if (ok) "✅ OpenRouter: " else "❌ OpenRouter: ") + msg.substringBefore("\n"))
                    }
                    if (lines.isEmpty()) {
                        Pair(false, "أدخل مفتاح واحد على الأقل (Groq أو Gemini أو OpenRouter) للاختبار.")
                    } else {
                        Pair(anySuccess, lines.joinToString("\n"))
                    }
                }
            }
        }

    private fun discoverGeminiModels(apiKey: String): List<String> {
        val discovered = mutableListOf<String>()
        runCatching {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models?key=$apiKey")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
            }
            if (conn.responseCode == HttpURLConnection.HTTP_OK) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val arr = JSONObject(body).optJSONArray("models")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val name = obj.optString("name", "").removePrefix("models/")
                        val methods = obj.optJSONArray("supportedGenerationMethods")?.toString().orEmpty()
                        val lower = name.lowercase()
                        if (name.isNotBlank() &&
                            methods.contains("generateContent") &&
                            lower.contains("gemini") &&
                            !lower.contains("embedding") &&
                            !lower.contains("vision") &&
                            !lower.contains("tts") &&
                            !lower.contains("image") &&
                            !lower.contains("robotics")
                        ) {
                            discovered.add(name)
                        }
                    }
                }
            } else {
                conn.disconnect()
            }
        }
        val flashFirst = discovered.filter { it.contains("flash", ignoreCase = true) }
        val others = discovered.filter { !it.contains("flash", ignoreCase = true) }
        val combined = (flashFirst + others).distinct()
        return combined.ifEmpty {
            listOf("gemini-2.0-flash", "gemini-2.0-flash-lite", "gemini-flash-latest", "gemini-2.5-flash")
        }
    }

    private fun testGeminiKey(apiKey: String, dialect: SubtitleDialect): Pair<Boolean, String> {
        if (apiKey.isEmpty()) return Pair(false, "أدخل مفتاح Gemini أولاً.")
        cachedGeminiModel = null
        val sys = systemPromptFor(dialect, isBatch = false)
        val models = discoverGeminiModels(apiKey).take(6)
        var lastError = "فشل الاتصال بسيرفر Gemini"
        for (model in models) {
            val (ok, textOrErr) = callGeminiDetailed(model, sys, "It's a piece of cake, don't worry about it!", apiKey, disableThinking = true)
            if (ok) {
                cachedGeminiModel = model
                return Pair(true, "شغال بنجاح ($model)!\nتجربة: $textOrErr")
            }
            if (textOrErr.contains("400")) {
                val (ok2, textOrErr2) = callGeminiDetailed(model, sys, "It's a piece of cake, don't worry about it!", apiKey, disableThinking = false)
                if (ok2) {
                    cachedGeminiModel = model
                    return Pair(true, "شغال بنجاح ($model)!\nتجربة: $textOrErr2")
                }
                lastError = textOrErr2
            } else {
                lastError = textOrErr
            }
        }
        return Pair(false, lastError)
    }

    private fun callGeminiDetailed(
        model: String,
        sysPrompt: String,
        userText: String,
        apiKey: String,
        disableThinking: Boolean
    ): Pair<Boolean, String> {
        return try {
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            )
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12000
                readTimeout = 15000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            }

            val payload = buildGeminiPayload(sysPrompt, userText, 160, disableThinking)
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }

            val code = conn.responseCode
            if (code == HttpURLConnection.HTTP_OK) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val text = formatCinemaSubtitle(extractGeminiRawText(body))
                if (text.isNotBlank()) Pair(true, text) else Pair(false, "رد فارغ من $model")
            } else {
                val errBody = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                conn.disconnect()
                val errMsg = runCatching {
                    JSONObject(errBody).optJSONObject("error")?.optString("message", "")
                }.getOrNull().orEmpty()
                val friendly = when (code) {
                    400 -> "خطأ (400): $errMsg"
                    403 -> "المفتاح مرفوض (403): $errMsg"
                    404 -> "الموديل $model غير متاح (404)"
                    429 -> "تم استهلاك الحصة مؤقتاً (429)"
                    else -> "خطأ ($code): $errMsg"
                }
                Pair(false, friendly)
            }
        } catch (e: Exception) {
            Pair(false, "خطأ اتصال: ${e.localizedMessage ?: "تأكد من الإنترنت"}")
        }
    }

    private fun discoverGroqModels(apiKey: String): List<String> {
        val discovered = mutableListOf<String>()
        runCatching {
            val url = URL("https://api.groq.com/openai/v1/models")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4000
                readTimeout = 4000
                setRequestProperty("Authorization", "Bearer $apiKey")
            }
            if (conn.responseCode == HttpURLConnection.HTTP_OK) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val data = JSONObject(body).optJSONArray("data")
                if (data != null) {
                    for (i in 0 until data.length()) {
                        val id = data.optJSONObject(i)?.optString("id", "").orEmpty()
                        val lower = id.lowercase()
                        if (id.isNotBlank() &&
                            !lower.contains("whisper") &&
                            !lower.contains("tts") &&
                            !lower.contains("guard") &&
                            !lower.contains("safeguard")
                        ) {
                            discovered.add(id)
                        }
                    }
                }
            } else {
                conn.disconnect()
            }
        }

        val preferredOrder = listOf(
            "llama-3.3-70b-versatile",
            "meta-llama/llama-4-scout-17b-16e-instruct",
            "llama-3.1-8b-instant",
            "qwen/qwen3-32b",
            "gemma2-9b-it"
        )
        val sorted = mutableListOf<String>()
        for (pref in preferredOrder) if (pref in discovered) sorted.add(pref)
        for (m in discovered) if (m !in sorted) sorted.add(m)
        if (sorted.isEmpty()) sorted.addAll(preferredOrder)
        return sorted
    }

    private fun testGroqKey(apiKey: String, dialect: SubtitleDialect): Pair<Boolean, String> {
        if (apiKey.isEmpty()) return Pair(false, "أدخل مفتاح Groq أولاً.")
        cachedGroqModel = null
        val sys = systemPromptFor(dialect, isBatch = false)
        val candidates = discoverGroqModels(apiKey).take(5)
        var lastError = "فشل الاتصال بسيرفر Groq"

        for (model in candidates) {
            try {
                val url = URL("https://api.groq.com/openai/v1/chat/completions")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 5000
                    readTimeout = 6000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Authorization", "Bearer $apiKey")
                }

                val payload = buildOpenAiPayload(model, sys, "It's a piece of cake, don't worry about it!", 160)
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }

                val code = conn.responseCode
                if (code == HttpURLConnection.HTTP_OK) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    val text = formatCinemaSubtitle(extractOpenAiRawText(body))
                    if (text.isNotBlank()) {
                        cachedGroqModel = model
                        return Pair(true, "شغال بنجاح ($model)!\nتجربة: $text")
                    }
                } else {
                    val errBody = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    conn.disconnect()
                    val errMsg = runCatching {
                        JSONObject(errBody).optJSONObject("error")?.optString("message", "")
                    }.getOrNull().orEmpty()
                    if (code == 401) return Pair(false, "مفتاح Groq غير صحيح (401)")
                    lastError = if (code == 429) "تم تجاوز الحد مؤقتاً (429)" else "خطأ ($code): $errMsg"
                }
            } catch (e: Exception) {
                lastError = "خطأ اتصال: ${e.localizedMessage ?: "تأكد من الإنترنت"}"
            }
        }
        return Pair(false, lastError)
    }

    private fun discoverOpenRouterFreeModels(): List<String> {
        val discovered = mutableListOf<String>()
        runCatching {
            val url = URL("https://openrouter.ai/api/v1/models")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 6000
                readTimeout = 6000
            }
            if (conn.responseCode == HttpURLConnection.HTTP_OK) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val data = JSONObject(body).optJSONArray("data")
                if (data != null) {
                    for (i in 0 until data.length()) {
                        val obj = data.optJSONObject(i) ?: continue
                        val id = obj.optString("id", "")
                        if (id.endsWith(":free")) {
                            discovered.add(id)
                        }
                    }
                }
            } else {
                conn.disconnect()
            }
        }
        val preferred = listOf("openrouter/free") +
            discovered.filter { it.contains("llama", true) || it.contains("gemma", true) || it.contains("qwen", true) || it.contains("mistral", true) } +
            discovered
        return preferred.distinct().take(6)
    }

    private fun testOpenRouterKey(apiKey: String, dialect: SubtitleDialect): Pair<Boolean, String> {
        if (apiKey.isEmpty()) return Pair(false, "أدخل مفتاح OpenRouter أولاً.")
        cachedOpenRouterModel = null
        val sys = systemPromptFor(dialect, isBatch = false)
        val freeModels = discoverOpenRouterFreeModels()
        var lastError = "فشل الاتصال بسيرفر OpenRouter"

        for (model in freeModels) {
            try {
                val url = URL("https://openrouter.ai/api/v1/chat/completions")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 5000
                    readTimeout = 7000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Authorization", "Bearer $apiKey")
                    setRequestProperty("HTTP-Referer", "https://cinemasub.app")
                    setRequestProperty("X-Title", "CinemaSub Browser")
                }

                val payload = buildOpenAiPayload(model, sys, "It's a piece of cake, don't worry about it!", 160)
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }

                val code = conn.responseCode
                if (code == HttpURLConnection.HTTP_OK) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    val text = formatCinemaSubtitle(extractOpenAiRawText(body))
                    if (text.isNotBlank()) {
                        cachedOpenRouterModel = model
                        return Pair(true, "شغال بنجاح ($model)!\nتجربة: $text")
                    }
                } else {
                    val errBody = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    conn.disconnect()
                    val errMsg = runCatching {
                        JSONObject(errBody).optJSONObject("error")?.optString("message", "")
                    }.getOrNull().orEmpty()
                    if (code == 401) return Pair(false, "مفتاح OpenRouter غير صحيح (401)")
                    lastError = if (code == 429) "الموديل مشغول مؤقتاً (429)" else "خطأ ($code): $errMsg"
                }
            } catch (e: Exception) {
                lastError = "خطأ اتصال: ${e.localizedMessage ?: "تأكد من الإنترنت"}"
            }
        }
        return Pair(false, lastError)
    }

    suspend fun translateToArabic(sourceText: String, previousContext: String = ""): String {
        val cleaned = sourceText.trim()
        if (cleaned.isEmpty()) return ""
        if (isAlreadyArabic(cleaned)) return formatCinemaSubtitle(cleaned)

        val config = TranslationSettingsStore.currentConfig
        val key = cacheKeyFor(config, cleaned)
        cache[key]?.let { return it }

        val userPrompt = if (previousContext.isNotBlank()) {
            "Previous line (context only): \"$previousContext\"\nTranslate ONLY this line:\n$cleaned"
        } else {
            cleaned
        }

        val sysPrompt = systemPromptFor(config.dialect, isBatch = false)
        val rawAi = callActiveAiRaw(sysPrompt, userPrompt, config, maxTokens = 160)
        val aiResult = rawAi?.let { formatCinemaSubtitle(it) }

        if (!aiResult.isNullOrBlank()) {
            cache[key] = aiResult
            return aiResult
        }

        val onlineResult = translateViaGoogleFree(cleaned)?.let { formatCinemaSubtitle(it) }
        if (!onlineResult.isNullOrBlank()) {
            cache[key] = onlineResult
            return onlineResult
        }

        if (!isOfflineReady.get()) ensureModelDownloaded()
        val offlineResult = runCatching {
            mlKitTranslator.translate(cleaned).await()
        }.getOrDefault("")

        val formattedOffline = formatCinemaSubtitle(offlineResult)
        if (formattedOffline.isNotBlank()) {
            cache[key] = formattedOffline
        }
        return formattedOffline
    }

    private suspend fun callActiveAiRaw(
        sysPrompt: String,
        userPrompt: String,
        config: AiTranslationConfig,
        maxTokens: Int
    ): String? = when (config.engine) {
        TranslationEngine.AUTO_HYBRID -> callAutoHybridRaw(sysPrompt, userPrompt, config, maxTokens)
        TranslationEngine.GEMINI_AI ->
            if (config.geminiApiKey.isNotBlank()) callGeminiFast(sysPrompt, userPrompt, config.geminiApiKey.trim(), maxTokens) else null
        TranslationEngine.GROQ_AI ->
            if (config.groqApiKey.isNotBlank()) callGroqFast(sysPrompt, userPrompt, config.groqApiKey.trim(), maxTokens) else null
        TranslationEngine.OPENROUTER_AI ->
            if (config.openRouterApiKey.isNotBlank()) callOpenRouterFast(sysPrompt, userPrompt, config.openRouterApiKey.trim(), maxTokens) else null
        TranslationEngine.GOOGLE_FREE -> null
    }

    private suspend fun callAutoHybridRaw(
        sysPrompt: String,
        userPrompt: String,
        config: AiTranslationConfig,
        maxTokens: Int
    ): String? {
        val activeEngines = buildList {
            if (config.groqApiKey.isNotBlank()) add(TranslationEngine.GROQ_AI)
            if (config.geminiApiKey.isNotBlank()) add(TranslationEngine.GEMINI_AI)
            if (config.openRouterApiKey.isNotBlank()) add(TranslationEngine.OPENROUTER_AI)
        }
        if (activeEngines.isEmpty()) return null

        val startIdx = Math.abs(roundRobinCounter.getAndIncrement()) % activeEngines.size
        for (i in activeEngines.indices) {
            val engine = activeEngines[(startIdx + i) % activeEngines.size]
            val result = when (engine) {
                TranslationEngine.GROQ_AI -> callGroqFast(sysPrompt, userPrompt, config.groqApiKey.trim(), maxTokens)
                TranslationEngine.GEMINI_AI -> callGeminiFast(sysPrompt, userPrompt, config.geminiApiKey.trim(), maxTokens)
                TranslationEngine.OPENROUTER_AI -> callOpenRouterFast(sysPrompt, userPrompt, config.openRouterApiKey.trim(), maxTokens)
                else -> null
            }
            if (!result.isNullOrBlank()) return result
        }
        return null
    }

    private suspend fun callGeminiFast(sysPrompt: String, userPrompt: String, apiKey: String, maxTokens: Int): String? =
        withContext(Dispatchers.IO) {
            val cached = cachedGeminiModel
            if (cached != null) {
                callGeminiModel(cached, sysPrompt, userPrompt, apiKey, maxTokens)?.let { return@withContext it }
            }
            val models = discoverGeminiModels(apiKey).take(4)
            for (model in models) {
                if (model == cached) continue
                val res = callGeminiModel(model, sysPrompt, userPrompt, apiKey, maxTokens)
                if (!res.isNullOrBlank()) {
                    cachedGeminiModel = model
                    return@withContext res
                }
            }
            null
        }

    private fun buildGeminiPayload(sysPrompt: String, text: String, maxTokens: Int, disableThinking: Boolean): JSONObject =
        JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sysPrompt)))
            )
            put(
                "contents",
                JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text))))
            )
            val genCfg = JSONObject()
                .put("temperature", 0.2)
                .put("maxOutputTokens", maxTokens)
            if (disableThinking) {
                genCfg.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
            }
            put("generationConfig", genCfg)
        }

    private fun extractGeminiRawText(body: String): String = runCatching {
        JSONObject(body)
            .optJSONArray("candidates")
            ?.optJSONObject(0)
            ?.optJSONObject("content")
            ?.optJSONArray("parts")
            ?.optJSONObject(0)
            ?.optString("text", "")
            .orEmpty()
    }.getOrDefault("")

    private fun callGeminiModel(model: String, sysPrompt: String, text: String, apiKey: String, maxTokens: Int): String? {
        return callGeminiOnce(model, sysPrompt, text, apiKey, maxTokens, disableThinking = true)
            ?: callGeminiOnce(model, sysPrompt, text, apiKey, maxTokens, disableThinking = false)
    }

    private fun callGeminiOnce(
        model: String,
        sysPrompt: String,
        text: String,
        apiKey: String,
        maxTokens: Int,
        disableThinking: Boolean
    ): String? = runCatching {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 5000
            readTimeout = 8000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            setRequestProperty("Connection", "keep-alive")
        }
        val payload = buildGeminiPayload(sysPrompt, text, maxTokens, disableThinking)
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }
        if (conn.responseCode != HttpURLConnection.HTTP_OK) {
            conn.disconnect()
            return@runCatching null
        }
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        conn.disconnect()
        extractGeminiRawText(body).takeIf { it.isNotBlank() }
    }.getOrNull()

    private fun buildOpenAiPayload(model: String, sysPrompt: String, text: String, maxTokens: Int): JSONObject {
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", sysPrompt))
            .put(JSONObject().put("role", "user").put("content", text))
        return JSONObject()
            .put("model", model)
            .put("temperature", 0.2)
            .put("max_tokens", maxTokens)
            .put("messages", messages)
    }

    private fun extractOpenAiRawText(body: String): String = runCatching {
        JSONObject(body)
            .optJSONArray("choices")
            ?.optJSONObject(0)
            ?.optJSONObject("message")
            ?.optString("content", "")
            .orEmpty()
    }.getOrDefault("")

    private suspend fun callGroqFast(sysPrompt: String, text: String, apiKey: String, maxTokens: Int): String? =
        withContext(Dispatchers.IO) {
            val model = cachedGroqModel ?: discoverGroqModels(apiKey).firstOrNull()?.also {
                cachedGroqModel = it
            } ?: return@withContext null

            runCatching {
                val url = URL("https://api.groq.com/openai/v1/chat/completions")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 2000
                    readTimeout = 4000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Authorization", "Bearer $apiKey")
                    setRequestProperty("Connection", "keep-alive")
                }
                val payload = buildOpenAiPayload(model, sysPrompt, text, maxTokens)
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }
                if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                    conn.disconnect()
                    return@runCatching null
                }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                extractOpenAiRawText(body).takeIf { it.isNotBlank() }
            }.getOrNull()
        }

    private suspend fun callOpenRouterFast(sysPrompt: String, text: String, apiKey: String, maxTokens: Int): String? =
        withContext(Dispatchers.IO) {
            val models = buildList {
                cachedOpenRouterModel?.let { add(it) }
                addAll(discoverOpenRouterFreeModels())
            }.distinct().take(5)

            for (model in models) {
                val result = runCatching {
                    val url = URL("https://openrouter.ai/api/v1/chat/completions")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 2200
                        readTimeout = 4500
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                        setRequestProperty("Authorization", "Bearer $apiKey")
                        setRequestProperty("HTTP-Referer", "https://cinemasub.app")
                        setRequestProperty("X-Title", "CinemaSub Browser")
                        setRequestProperty("Connection", "keep-alive")
                    }
                    val payload = buildOpenAiPayload(model, sysPrompt, text, maxTokens)
                    OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }
                    if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                        conn.disconnect()
                        return@runCatching null
                    }
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    extractOpenAiRawText(body).takeIf { it.isNotBlank() }
                }.getOrNull()

                if (!result.isNullOrBlank()) {
                    cachedOpenRouterModel = model
                    return@withContext result
                }
            }
            null
        }

    // Netflix-style balanced two-line formatter (prevents awkward 1-word bottom lines)
    private fun formatCinemaSubtitle(raw: String): String {
        val noThink = raw.replace(Regex("<think>[\\s\\S]*?</think>"), "")
        val singleLine = noThink
            .replace("*", "")
            .replace("\r", "")
            .replace("\n", " ")
            .replace(Regex("\\s+"), " ")
            .trim('"', '\'', '«', '»', ' ')

        if (singleLine.isBlank() || singleLine.equals("null", ignoreCase = true)) return ""
        if (singleLine.length <= 42) return singleLine

        val words = singleLine.split(" ")
        if (words.size <= 3) return singleLine

        val mid = singleLine.length / 2
        var bestSplitIdx = words.size / 2
        var bestDiff = Int.MAX_VALUE
        var runningLen = 0
        for (i in 0 until words.size - 1) {
            runningLen += words[i].length + (if (i > 0) 1 else 0)
            val diff = Math.abs(runningLen - mid)
            if (diff < bestDiff) {
                bestDiff = diff
                bestSplitIdx = i + 1
            }
        }
        val line1 = words.subList(0, bestSplitIdx).joinToString(" ")
        val line2 = words.subList(bestSplitIdx, words.size).joinToString(" ")
        return "$line1\n$line2"
    }

    private fun isAlreadyArabic(text: String): Boolean {
        var arabicCount = 0
        var letterCount = 0
        for (ch in text) {
            if (ch.isLetter()) {
                letterCount++
                if (ch in '\u0600'..'\u06FF') arabicCount++
            }
        }
        return letterCount > 0 && (arabicCount * 2 > letterCount)
    }

    private suspend fun translateViaGoogleFree(text: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            val encoded = URLEncoder.encode(text, "UTF-8")
            val urlStr =
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ar&dt=t&q=$encoded"
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 1500
                readTimeout = 1500
                setRequestProperty("User-Agent", "Mozilla/5.0")
            }
            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                conn.disconnect()
                return@runCatching null
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val root = JSONArray(body)
            val sentences = root.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                val part = sentences.getJSONArray(i).optString(0, "")
                sb.append(part)
            }
            sb.toString().trim()
        }.getOrNull()
    }

    fun close() {
        mlKitTranslator.close()
    }
}
