package com.cinemasub.browser.browser

import android.content.Context
import android.media.MediaDataSource
import android.media.MediaExtractor
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import com.cinemasub.browser.translation.ArabicTranslator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URI
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

object ProactiveMediaSubtitleEngine {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val speakerPrefixRegex = Regex("""^\s*\[?S\d+]?\s*[:：\-]?\s*""", RegexOption.IGNORE_CASE)

    private data class TimedLine(
        val startSec: Double,
        val endSec: Double,
        val text: String,
        val speaker: Int?
    )

    private data class HlsSegment(
        val url: String,
        val durationSec: Double,
        val offsetSec: Double
    )

    fun isMediaStreamUrl(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val lower = url.lowercase()
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) return false
        val path = lower.substringBefore('?').substringBefore('#')
        if (path.endsWith(".m3u8") || lower.contains(".m3u8?")) return true
        if (path.endsWith(".mp4") || path.endsWith(".m4a") || path.endsWith(".webm") || path.endsWith(".mkv")) {
            // Skip obvious ad / preview / tracking clips
            if (
                lower.contains("doubleclick") ||
                lower.contains("googlesyndication") ||
                lower.contains("adservice") ||
                lower.contains("/thumb") ||
                lower.contains("sprite")
            ) {
                return false
            }
            return true
        }
        return false
    }

    suspend fun generateProgressively(
        context: Context,
        mediaUrl: String,
        headers: Map<String, String>,
        deepgramApiKey: String,
        languageCode: String,
        translator: ArabicTranslator,
        getCurrentPlaybackSec: () -> Double = { 0.0 },
        onProgress: (json: String?, cueCount: Int, percent: Int, statusMsg: String) -> Unit
    ): Pair<String, Int>? = withContext(Dispatchers.IO) {
        val dgKey = deepgramApiKey.trim()
        if (dgKey.isEmpty()) {
            throw IllegalStateException("أدخل مفتاح Deepgram أولاً في الإعدادات لتشغيل الترجمة الاستباقية.")
        }

        // 1. Check Disk Cache first (instant 0ms load if already generated for this movie!)
        val cacheFile = cacheFileFor(context, mediaUrl)
        if (cacheFile.exists() && cacheFile.length() > 20) {
            val cachedJson = runCatching { cacheFile.readText(Charsets.UTF_8) }.getOrNull()
            if (!cachedJson.isNullOrBlank()) {
                val count = runCatching { JSONArray(cachedJson).length() }.getOrDefault(0)
                if (count > 0) {
                    onProgress(cachedJson, count, 100, "تم تحميل الترجمة المحفوظة فوراً ($count جملة) ✅")
                    return@withContext Pair(cachedJson, count)
                }
            }
        }

        val cleanHeaders = sanitizeHeaders(headers)
        val lowerPath = mediaUrl.lowercase().substringBefore('?').substringBefore('#')
        val allCues = mutableListOf<ExternalCue>()

        val isHlsByUrl = lowerPath.endsWith(".m3u8") || mediaUrl.lowercase().contains(".m3u8?")
        val probe = if (!isHlsByUrl) probeStream(mediaUrl, cleanHeaders) else null
        val isHls = isHlsByUrl || (probe?.isHls == true)

        if (isHls) {
            processHlsStream(
                context = context,
                mediaUrl = mediaUrl,
                headers = cleanHeaders,
                deepgramApiKey = dgKey,
                languageCode = languageCode,
                translator = translator,
                allCues = allCues,
                cacheFile = cacheFile,
                getCurrentPlaybackSec = getCurrentPlaybackSec,
                onProgress = onProgress
            )
        } else {
            processDirectMediaStream(
                context = context,
                mediaUrl = mediaUrl,
                headers = cleanHeaders,
                probedSize = probe?.totalSize ?: -1L,
                supportsRange = probe?.supportsRange ?: false,
                deepgramApiKey = dgKey,
                languageCode = languageCode,
                translator = translator,
                allCues = allCues,
                cacheFile = cacheFile,
                getCurrentPlaybackSec = getCurrentPlaybackSec,
                onProgress = onProgress
            )
        }

        if (allCues.isEmpty()) return@withContext null
        val finalJson = cuesToJson(allCues)
        runCatching { cacheFile.writeText(finalJson, Charsets.UTF_8) }
        onProgress(finalJson, allCues.size, 100, "اكتملت الترجمة الاستباقية (${allCues.size} جملة) — توقيت 100% ✅")
        Pair(finalJson, allCues.size)
    }

    private suspend fun processHlsStream(
        context: Context,
        mediaUrl: String,
        headers: Map<String, String>,
        deepgramApiKey: String,
        languageCode: String,
        translator: ArabicTranslator,
        allCues: MutableList<ExternalCue>,
        cacheFile: File,
        getCurrentPlaybackSec: () -> Double,
        onProgress: (json: String?, cueCount: Int, percent: Int, statusMsg: String) -> Unit
    ) {
        onProgress(null, 0, 2, "جاري تحليل بث الفيديو (.m3u8)...")
        val playlistText = fetchText(mediaUrl, headers)
            ?: throw IllegalStateException("تعذر قراءة رابط البث (قد يكون محمياً بـ DRM).")

        var targetUrl = mediaUrl
        var mediaPlaylist = playlistText

        // If Master Playlist -> prefer audio-only track (10x faster!), else lowest-bandwidth variant
        if (playlistText.contains("#EXT-X-STREAM-INF")) {
            val resolved = pickBestSubPlaylistUrl(mediaUrl, playlistText)
            if (resolved != null) {
                targetUrl = resolved
                mediaPlaylist = fetchText(resolved, headers)
                    ?: throw IllegalStateException("تعذر تحميل قائمة مقاطع البث.")
            }
        }

        if (mediaPlaylist.contains("#EXT-X-KEY:METHOD=SAMPLE-AES") ||
            mediaPlaylist.contains("#EXT-X-KEY:METHOD=AES-128") ||
            mediaPlaylist.contains("urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed")
        ) {
            throw IllegalStateException("هذا الفيديو مشفّر (DRM/AES) ولا يمكن سحب صوته مسبقاً — استخدم وضع الصوت المباشر.")
        }

        val initMapUrl = extractInitMapUrl(targetUrl, mediaPlaylist)
        val initBytes = initMapUrl?.let { fetchBytes(it, headers) }
        val segments = parseHlsSegments(targetUrl, mediaPlaylist)
        if (segments.isEmpty()) {
            throw IllegalStateException("لم يتم العثور على مقاطع صوتية قابلة للمعالجة في هذا البث.")
        }

        // Zero-gap dynamic chunking + Seek-Aware priority:
        // Never skips any segment when size limit is reached, and immediately jumps to user's seek position!
        val totalSegs = segments.size
        val processed = BooleanArray(totalSegs)
        var processedCount = 0
        var chunkNum = 0

        fun findSegmentIndexForTime(sec: Double): Int {
            if (sec <= 0.0) return 0
            var best = 0
            for (i in segments.indices) {
                if (segments[i].offsetSec <= sec) best = i else break
            }
            return best
        }

        fun findNextUnprocessed(fromIdx: Int): Int {
            for (i in fromIdx until totalSegs) {
                if (!processed[i]) return i
            }
            for (i in 0 until fromIdx.coerceAtMost(totalSegs)) {
                if (!processed[i]) return i
            }
            return -1
        }

        var cursor = findSegmentIndexForTime(getCurrentPlaybackSec())

        while (processedCount < totalSegs) {
            coroutineContext.ensureActive()

            // Seek-Aware check: if user scrubbed to an untranslated part of the movie, jump there immediately!
            val playSec = getCurrentPlaybackSec()
            val seekIdx = findSegmentIndexForTime(playSec)
            if (!processed[seekIdx]) {
                cursor = seekIdx
            } else if (cursor >= totalSegs || processed[cursor]) {
                val next = findNextUnprocessed(cursor.coerceIn(0, totalSegs - 1))
                if (next < 0) break
                cursor = next
            }

            val isFirstChunk = (chunkNum == 0)
            val maxBytes = if (isFirstChunk) (1.5 * 1024 * 1024).toInt() else (2.5 * 1024 * 1024).toInt()
            val maxDurSec = if (isFirstChunk) 15.0 else 30.0

            val out = ByteArrayOutputStream()
            if (initBytes != null && initBytes.isNotEmpty()) {
                out.write(initBytes)
            }

            val chunkStartIdx = cursor
            var chunkDur = 0.0
            var downloadedSegs = 0

            while (cursor < totalSegs && !processed[cursor]) {
                coroutineContext.ensureActive()
                val seg = segments[cursor]
                if (isFirstChunk) {
                    onProgress(
                        null,
                        0,
                        (4 + downloadedSegs * 2).coerceAtMost(14),
                        "جاري سحب مقاطع البداية (${downloadedSegs + 1})..."
                    )
                }
                val segBytes = fetchBytes(seg.url, headers)
                processed[cursor] = true
                processedCount++
                cursor++

                if (segBytes != null && segBytes.isNotEmpty()) {
                    out.write(segBytes)
                    downloadedSegs++
                    chunkDur += seg.durationSec
                }

                // Stop this chunk cleanly; next chunk continues from `cursor` with ZERO skipped seconds!
                if (out.size() >= maxBytes || chunkDur >= maxDurSec) {
                    break
                }
            }

            val mediaBytes = out.toByteArray()
            if (mediaBytes.size < 4096) {
                if (isFirstChunk && downloadedSegs == 0) {
                    throw IllegalStateException("الموقع منع تحميل مقاطع الفيديو — استخدم وضع الصوت المباشر.")
                }
                chunkNum++
                continue
            }

            val isMp4Chunk = (initBytes != null)
            val extracted = extractAudioOnlyFromMediaBytes(context, mediaBytes, isMp4Chunk)
            val uploadBytes = extracted?.first ?: mediaBytes
            val uploadMime = extracted?.second ?: if (isMp4Chunk) "video/mp4" else "video/mp2t"

            if (isFirstChunk) {
                val sizeLabel = if (uploadBytes.size < 1024 * 1024) {
                    "${(uploadBytes.size / 1024).coerceAtLeast(1)} KB"
                } else {
                    String.format("%.1f MB", uploadBytes.size / (1024.0 * 1024.0))
                }
                onProgress(null, 0, 16, "جاري تفريغ الصوت الصافي عبر Deepgram ($sizeLabel)...")
            }

            val chunkOffset = segments[chunkStartIdx].offsetSec
            val rawMime = if (isMp4Chunk) "video/mp4" else "video/mp2t"
            val timedLines = if (extracted != null) {
                transcribeWithDeepgramPreRecorded(
                    audioBytes = uploadBytes,
                    contentType = uploadMime,
                    apiKey = deepgramApiKey,
                    languageCode = languageCode,
                    offsetSec = chunkOffset,
                    throwOnError = false
                ) ?: transcribeWithDeepgramPreRecorded(
                    audioBytes = mediaBytes,
                    contentType = rawMime,
                    apiKey = deepgramApiKey,
                    languageCode = languageCode,
                    offsetSec = chunkOffset,
                    throwOnError = isFirstChunk
                )
            } else {
                transcribeWithDeepgramPreRecorded(
                    audioBytes = mediaBytes,
                    contentType = rawMime,
                    apiKey = deepgramApiKey,
                    languageCode = languageCode,
                    offsetSec = chunkOffset,
                    throwOnError = isFirstChunk
                )
            }.orEmpty()

            val pct = ((processedCount * 100) / totalSegs).coerceIn(5, 99)
            if (timedLines.isNotEmpty()) {
                if (allCues.isEmpty()) {
                    onProgress(null, 0, pct.coerceAtLeast(20), "جاري ترجمة ${timedLines.size} جملة للبدء السريع...")
                }
                val translated = translateTimedLines(timedLines, translator)
                allCues.addAll(translated)
                allCues.sortBy { it.startSec }
                val jsonNow = cuesToJson(allCues)
                runCatching { cacheFile.writeText(jsonNow, Charsets.UTF_8) }
                val readyMsg = if (allCues.size == translated.size) {
                    "تم تجهيز البداية (${allCues.size} جملة) — شغّل الفيلم الآن! ($pct%)"
                } else {
                    "يمكنك المشاهدة الآن! تم ترجمة ${allCues.size} جملة ($pct%)..."
                }
                onProgress(jsonNow, allCues.size, pct, readyMsg)
            } else {
                val silentMsg = if (allCues.isEmpty()) {
                    "جاري تجاوز المقدمة/الموسيقى والبحث عن أول حوار ($pct%)..."
                } else {
                    "يمكنك المشاهدة الآن! تم ترجمة ${allCues.size} جملة ($pct%)..."
                }
                onProgress(null, allCues.size, pct, silentMsg)
            }
            chunkNum++
        }
    }

    private data class StreamProbeResult(
        val isHls: Boolean,
        val totalSize: Long,
        val supportsRange: Boolean,
        val contentType: String
    )

    private fun probeStream(url: String, headers: Map<String, String>): StreamProbeResult {
        return runCatching {
            val req = buildRequest(url, headers)
                .header("Range", "bytes=0-4095")
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val ct = resp.header("Content-Type").orEmpty().lowercase()
                val contentRange = resp.header("Content-Range").orEmpty()
                val supportsRange = resp.code == 206 || contentRange.contains("/")
                val totalFromRange = contentRange.substringAfter('/', "").trim().toLongOrNull() ?: -1L
                val totalSize = if (totalFromRange > 0L) {
                    totalFromRange
                } else if (resp.code == 200) {
                    resp.header("Content-Length")?.toLongOrNull() ?: -1L
                } else {
                    -1L
                }
                val headBytes = resp.body?.byteStream()?.use { stream ->
                    val buf = ByteArray(512)
                    val n = stream.read(buf)
                    if (n > 0) String(buf, 0, n, Charsets.UTF_8) else ""
                }.orEmpty()
                val isHls = ct.contains("mpegurl") || headBytes.trimStart().startsWith("#EXTM3U")
                StreamProbeResult(
                    isHls = isHls,
                    totalSize = totalSize,
                    supportsRange = supportsRange,
                    contentType = ct
                )
            }
        }.getOrElse {
            StreamProbeResult(isHls = false, totalSize = -1L, supportsRange = false, contentType = "")
        }
    }

    // Custom MediaDataSource backed by OkHttp (handles HTTP/2, redirects, Cookies, Referer & Range caching)
    private class OkHttpMediaDataSource(
        private val url: String,
        private val headers: Map<String, String>,
        private val totalSize: Long
    ) : MediaDataSource() {

        private val chunkSize = 1024 * 1024 // 1 MB sliding cache pages (fewer HTTP round-trips)
        private val pageCache = object : LinkedHashMap<Long, ByteArray>(6, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, ByteArray>?): Boolean = size > 4
        }

        override fun getSize(): Long = totalSize

        override fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int {
            if (size <= 0) return 0
            if (totalSize > 0 && position >= totalSize) return -1

            val pageIdx = position / chunkSize
            val pageStart = pageIdx * chunkSize
            val pageBytes = getOrFetchPage(pageStart) ?: return -1
            val inPageOffset = (position - pageStart).toInt()
            if (inPageOffset >= pageBytes.size) return -1

            val toCopy = minOf(size, pageBytes.size - inPageOffset)
            System.arraycopy(pageBytes, inPageOffset, buffer, offset, toCopy)
            return toCopy
        }

        @Synchronized
        private fun getOrFetchPage(pageStart: Long): ByteArray? {
            pageCache[pageStart]?.let { return it }
            val pageEnd = if (totalSize > 0) {
                minOf(pageStart + chunkSize - 1, totalSize - 1)
            } else {
                pageStart + chunkSize - 1
            }
            if (pageEnd < pageStart) return null

            val req = buildRequest(url, headers)
                .header("Range", "bytes=$pageStart-$pageEnd")
                .get()
                .build()

            val bytes = runCatching {
                httpClient.newCall(req).execute().use { resp ->
                    // CRITICAL: Reject 200 OK full-file responses so we never hang downloading a 1GB movie into RAM!
                    if (resp.code != 206) return@runCatching null
                    val expectedMax = (pageEnd - pageStart + 1).toInt()
                    val stream = resp.body?.byteStream() ?: return@runCatching null
                    val out = ByteArrayOutputStream(expectedMax.coerceAtMost(chunkSize))
                    val buf = ByteArray(32 * 1024)
                    var total = 0
                    while (total < expectedMax) {
                        val n = stream.read(buf, 0, minOf(buf.size, expectedMax - total))
                        if (n <= 0) break
                        out.write(buf, 0, n)
                        total += n
                    }
                    out.toByteArray()
                }
            }.getOrNull() ?: return null

            if (bytes.isEmpty()) return null
            pageCache[pageStart] = bytes
            return bytes
        }

        override fun close() {
            pageCache.clear()
        }
    }

    private suspend fun processDirectMediaStream(
        context: Context,
        mediaUrl: String,
        headers: Map<String, String>,
        probedSize: Long,
        supportsRange: Boolean,
        deepgramApiKey: String,
        languageCode: String,
        translator: ArabicTranslator,
        allCues: MutableList<ExternalCue>,
        cacheFile: File,
        getCurrentPlaybackSec: () -> Double,
        onProgress: (json: String?, cueCount: Int, percent: Int, statusMsg: String) -> Unit
    ) {
        onProgress(null, 0, 5, "جاري فحص ملف الفيديو لاستخراج الصوت...")
        val contentLength = if (probedSize > 0L) probedSize else fetchContentLength(mediaUrl, headers)

        // Small direct video/audio (<= 16 MB): download once and send cleanly
        if (contentLength in 1..(16L * 1024L * 1024L)) {
            onProgress(null, 0, 20, "جاري سحب الصوت وتفريغه بتوقيت دقيق...")
            val bytes = fetchBytes(mediaUrl, headers)
                ?: throw IllegalStateException("تعذر تحميل ملف الفيديو من الموقع — استخدم وضع الصوت المباشر.")
            val extracted = extractAudioOnlyFromMediaBytes(context, bytes, isMp4 = true)
            val sendBytes = extracted?.first ?: bytes
            val sendMime = extracted?.second ?: when {
                mediaUrl.lowercase().contains(".webm") -> "video/webm"
                mediaUrl.lowercase().contains(".m4a") -> "audio/mp4"
                else -> "video/mp4"
            }
            val lines = transcribeWithDeepgramPreRecorded(sendBytes, sendMime, deepgramApiKey, languageCode, 0.0, throwOnError = true).orEmpty()
            if (lines.isNotEmpty()) {
                onProgress(null, 0, 65, "جاري ترجمة ${lines.size} جملة بسياق الفيلم...")
                allCues.addAll(translateTimedLines(lines, translator))
                allCues.sortBy { it.startSec }
                val jsonNow = cuesToJson(allCues)
                runCatching { cacheFile.writeText(jsonNow, Charsets.UTF_8) }
                onProgress(jsonNow, allCues.size, 98, "تمت الترجمة (${allCues.size} جملة)")
            }
            return
        }

        // Large MP4/MKV/WebM movie: use OkHttpMediaDataSource first (fixes "Failed to instantiate extractor.")
        val extractor = MediaExtractor()
        var okDataSource: OkHttpMediaDataSource? = null
        var fallbackTempFile: File? = null
        try {
            var sourceReady = false
            if (supportsRange && contentLength > 0L) {
                val ds = OkHttpMediaDataSource(mediaUrl, headers, contentLength)
                sourceReady = runCatching {
                    extractor.setDataSource(ds)
                    okDataSource = ds
                    true
                }.getOrDefault(false)
                if (!sourceReady) runCatching { ds.close() }
            }

            if (!sourceReady) {
                sourceReady = runCatching {
                    extractor.setDataSource(mediaUrl, headers)
                    true
                }.getOrDefault(false)
            }

            if (!sourceReady) {
                // Final fallback: stream first 6 MB via OkHttp into a temp file to test/extract beginning
                onProgress(null, 0, 10, "جاري سحب بداية الفيديو عبر اتصال بديل...")
                val partialBytes = fetchPartialBytes(mediaUrl, headers, 6 * 1024 * 1024)
                if (partialBytes != null && partialBytes.size >= 65536) {
                    val tmp = File.createTempFile("direct_partial_", ".mp4", context.cacheDir)
                    tmp.writeBytes(partialBytes)
                    fallbackTempFile = tmp
                    sourceReady = runCatching {
                        extractor.setDataSource(tmp.absolutePath)
                        true
                    }.getOrDefault(false)
                }
            }

            if (!sourceReady) {
                throw IllegalStateException("الموقع يمنع قراءة ملف الفيديو مسبقاً (حماية سيرفر) — استخدم وضع الصوت المباشر (العلامة الخضراء).")
            }

            var audioTrackIdx = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    audioTrackIdx = i
                    audioFormat = fmt
                    break
                }
            }

            if (audioTrackIdx < 0 || audioFormat == null) {
                throw IllegalStateException("تعذر العثور على مسار الصوت داخل الفيديو — استخدم وضع الصوت المباشر.")
            }

            extractor.selectTrack(audioTrackIdx)
            val trackMime = audioFormat.getString(MediaFormat.KEY_MIME).orEmpty()
            val sampleRate = if (audioFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            } else 44100
            val channelCount = if (audioFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            } else 2
            val durationUs = if (audioFormat.containsKey(MediaFormat.KEY_DURATION)) {
                audioFormat.getLong(MediaFormat.KEY_DURATION)
            } else 0L
            val isAac = trackMime.contains("mp4a", ignoreCase = true) || trackMime.contains("aac", ignoreCase = true)

            // Seek-Aware initial position
            val initialPlayUs = (getCurrentPlaybackSec() * 1_000_000.0).toLong()
            if (initialPlayUs > 5_000_000L && (durationUs <= 0L || initialPlayUs < durationUs)) {
                runCatching { extractor.seekTo(initialPlayUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC) }
            }

            val sampleBuf = ByteBuffer.allocate(256 * 1024)
            var chunkIndex = 0
            val coveredRanges = mutableListOf<Pair<Long, Long>>()

            fun isTimeCovered(tUs: Long): Boolean =
                coveredRanges.any { (s, e) -> tUs in s..e }

            while (true) {
                coroutineContext.ensureActive()

                // Seek-Aware check between chunks
                val playUs = (getCurrentPlaybackSec() * 1_000_000.0).toLong()
                if (playUs > 5_000_000L && !isTimeCovered(playUs) && (durationUs <= 0L || playUs < durationUs)) {
                    val curTime = extractor.sampleTime
                    if (curTime < 0L || kotlin.math.abs(curTime - playUs) > 20_000_000L) {
                        runCatching { extractor.seekTo(playUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC) }
                    }
                }

                val chunkStartUs = extractor.sampleTime
                if (chunkStartUs < 0L) break

                val targetDurUs = if (chunkIndex == 0) 18_000_000L else 45_000_000L
                val maxChunkBytes = 3 * 1024 * 1024

                if (chunkIndex == 0) {
                    onProgress(null, 0, 12, "جاري استخراج الصوت الصافي للبداية السريعة...")
                }

                // Mux chunk cleanly into .m4a (audio/mp4) with fallback to raw ADTS/MPEG
                val muxFile = runCatching { File.createTempFile("mp4_aud_", ".m4a", context.cacheDir) }.getOrNull()
                var muxer: MediaMuxer? = null
                var muxTrackIdx = -1
                var muxerStarted = false
                if (muxFile != null) {
                    runCatching {
                        val m = MediaMuxer(muxFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                        muxTrackIdx = m.addTrack(audioFormat)
                        m.start()
                        muxer = m
                        muxerStarted = true
                    }
                }

                val rawFallbackOut = ByteArrayOutputStream()
                val bufferInfo = MediaCodec.BufferInfo()
                var lastPtsUs = -1L
                var chunkEndUs = chunkStartUs
                var bytesCollected = 0
                var reachedEof = false

                while (true) {
                    coroutineContext.ensureActive()
                    val tUs = extractor.sampleTime
                    if (tUs < 0L) {
                        reachedEof = true
                        break
                    }
                    sampleBuf.clear()
                    val readSize = extractor.readSampleData(sampleBuf, 0)
                    if (readSize <= 0) {
                        if (!extractor.advance()) {
                            reachedEof = true
                            break
                        }
                        continue
                    }

                    chunkEndUs = tUs
                    bytesCollected += readSize

                    if (muxerStarted && muxer != null && muxTrackIdx >= 0) {
                        val relPts = (tUs - chunkStartUs).coerceAtLeast(0L)
                        val safePts = if (relPts < lastPtsUs) lastPtsUs else relPts
                        lastPtsUs = safePts
                        bufferInfo.offset = 0
                        bufferInfo.size = readSize
                        bufferInfo.presentationTimeUs = safePts
                        bufferInfo.flags = if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
                            MediaCodec.BUFFER_FLAG_KEY_FRAME
                        } else 0
                        runCatching { muxer?.writeSampleData(muxTrackIdx, sampleBuf, bufferInfo) }
                    } else {
                        val frameBytes = ByteArray(readSize)
                        sampleBuf.get(frameBytes, 0, readSize)
                        if (isAac) {
                            rawFallbackOut.write(createAdtsHeader(readSize, sampleRate, channelCount))
                        }
                        rawFallbackOut.write(frameBytes)
                    }

                    val advanced = extractor.advance()
                    if (!advanced) {
                        reachedEof = true
                        break
                    }
                    if ((tUs - chunkStartUs) >= targetDurUs || bytesCollected >= maxChunkBytes) {
                        break
                    }
                }

                var uploadBytes: ByteArray? = null
                var uploadMime = "audio/mp4"
                if (muxerStarted && muxer != null && muxFile != null) {
                    runCatching { muxer?.stop() }
                    runCatching { muxer?.release() }
                    val muxBytes = runCatching { muxFile.readBytes() }.getOrNull()
                    runCatching { muxFile.delete() }
                    if (muxBytes != null && muxBytes.size >= 1024) {
                        uploadBytes = muxBytes
                        uploadMime = "audio/mp4"
                    }
                } else {
                    runCatching { muxer?.release() }
                    runCatching { muxFile?.delete() }
                }

                if (uploadBytes == null) {
                    val raw = rawFallbackOut.toByteArray()
                    if (raw.size >= 1024) {
                        uploadBytes = raw
                        uploadMime = if (isAac) "audio/aac" else "audio/mpeg"
                    }
                }

                coveredRanges.add(Pair(chunkStartUs, chunkEndUs))

                if (uploadBytes != null) {
                    if (chunkIndex == 0) {
                        val kb = (uploadBytes.size / 1024).coerceAtLeast(1)
                        onProgress(null, 0, 18, "جاري تفريغ الصوت الصافي عبر Deepgram ($kb KB)...")
                    }
                    val lines = transcribeWithDeepgramPreRecorded(
                        audioBytes = uploadBytes,
                        contentType = uploadMime,
                        apiKey = deepgramApiKey,
                        languageCode = languageCode,
                        offsetSec = chunkStartUs / 1_000_000.0,
                        throwOnError = (chunkIndex == 0)
                    ).orEmpty()
                    val pct = if (durationUs > 0L) {
                        ((chunkEndUs * 95L) / durationUs).toInt().coerceIn(8, 98)
                    } else {
                        (15 + chunkIndex * 10).coerceAtMost(95)
                    }
                    if (lines.isNotEmpty()) {
                        if (allCues.isEmpty()) {
                            onProgress(null, 0, pct.coerceAtLeast(24), "جاري ترجمة ${lines.size} جملة للبدء السريع...")
                        }
                        val translated = translateTimedLines(lines, translator)
                        allCues.addAll(translated)
                        allCues.sortBy { it.startSec }
                        val jsonNow = cuesToJson(allCues)
                        runCatching { cacheFile.writeText(jsonNow, Charsets.UTF_8) }
                        val msg = if (allCues.size == translated.size) {
                            "تم تجهيز البداية (${allCues.size} جملة) — شغّل الفيلم الآن! ($pct%)"
                        } else {
                            "يمكنك المشاهدة الآن! تم ترجمة ${allCues.size} جملة ($pct%)..."
                        }
                        onProgress(jsonNow, allCues.size, pct, msg)
                    } else {
                        val silentMsg = if (allCues.isEmpty()) {
                            "جاري تجاوز المقدمة/الموسيقى والبحث عن أول حوار ($pct%)..."
                        } else {
                            "يمكنك المشاهدة الآن! تم ترجمة ${allCues.size} جملة ($pct%)..."
                        }
                        onProgress(null, allCues.size, pct, silentMsg)
                    }
                }

                chunkIndex++
                if (reachedEof) break
            }
        } finally {
            runCatching { extractor.release() }
            runCatching { okDataSource?.close() }
            runCatching { fallbackTempFile?.delete() }
        }
    }

    // Returns null on HTTP/format error (allowing fallback), or emptyList() on valid 200 OK silence/music
    private fun transcribeWithDeepgramPreRecorded(
        audioBytes: ByteArray,
        contentType: String,
        apiKey: String,
        languageCode: String,
        offsetSec: Double,
        throwOnError: Boolean = false
    ): List<TimedLine>? {
        val url = "https://api.deepgram.com/v1/listen" +
            "?model=nova-2" +
            "&language=$languageCode" +
            "&smart_format=true" +
            "&punctuate=true" +
            "&diarize=true" +
            "&utterances=true"

        val req = Request.Builder()
            .url(url)
            .header("Authorization", "Token $apiKey")
            .post(audioBytes.toRequestBody(contentType.toMediaType()))
            .build()

        var errorMsg: String? = null
        val body = runCatching {
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    errorMsg = when (resp.code) {
                        401, 403 -> "مفتاح Deepgram غير صالح أو انتهى الرصيد (${resp.code})"
                        400, 415 -> "صيغة فيديو هذا الموقع غير مدعومة مسبقاً — استخدم وضع الصوت المباشر."
                        413 -> "حجم المقطع أكبر من المسموح."
                        else -> "خطأ من Deepgram (${resp.code})"
                    }
                    return@runCatching null
                }
                resp.body?.string()
            }
        }.onFailure { e ->
            errorMsg = "انتهى وقت الاتصال أو انقطع النت: ${e.localizedMessage ?: "حاول مرة أخرى"}"
        }.getOrNull()

        if (body == null) {
            if (throwOnError && errorMsg != null) {
                throw IllegalStateException(errorMsg)
            }
            return null
        }

        return parseDeepgramTimedLines(body, offsetSec)
    }

    // Builds clean cinema-length subtitle cues (1-6 sec, max ~78 chars / 2 lines) from Deepgram word timestamps
    private fun parseDeepgramTimedLines(jsonBody: String, offsetSec: Double): List<TimedLine> {
        val result = mutableListOf<TimedLine>()
        runCatching {
            val root = JSONObject(jsonBody)
            val resultsObj = root.optJSONObject("results") ?: return result

            // Prefer utterances with speaker diarization & word-level timestamps
            val utterances = resultsObj.optJSONArray("utterances")
            if (utterances != null && utterances.length() > 0) {
                for (i in 0 until utterances.length()) {
                    val utt = utterances.optJSONObject(i) ?: continue
                    val words = utt.optJSONArray("words")
                    val speaker = if (utt.has("speaker")) utt.optInt("speaker") else null
                    if (words != null && words.length() > 0) {
                        splitWordsIntoCinemaLines(words, offsetSec, speaker, result)
                    } else {
                        val txt = utt.optString("transcript", "").trim()
                        if (txt.isNotEmpty()) {
                            val s = utt.optDouble("start", 0.0) + offsetSec
                            val e = (utt.optDouble("end", s + 2.0) + offsetSec).coerceIn(s + 1.0, s + 6.0)
                            result.add(TimedLine(s, e, txt, speaker))
                        }
                    }
                }
                if (result.isNotEmpty()) return result
            }

            // Fallback to channels[0].alternatives[0].words
            val channels = resultsObj.optJSONArray("channels") ?: return result
            val alts = channels.optJSONObject(0)?.optJSONArray("alternatives") ?: return result
            val words = alts.optJSONObject(0)?.optJSONArray("words") ?: return result
            splitWordsIntoCinemaLines(words, offsetSec, null, result)
        }
        return result
    }

    private fun splitWordsIntoCinemaLines(
        words: JSONArray,
        offsetSec: Double,
        defaultSpeaker: Int?,
        out: MutableList<TimedLine>
    ) {
        val sb = StringBuilder()
        var lineStart = -1.0
        var lineEnd = -1.0
        var lineSpeaker: Int? = defaultSpeaker

        fun flush() {
            val text = sb.toString().trim()
            if (text.isNotEmpty() && lineStart >= 0.0) {
                val safeEnd = lineEnd.coerceIn(lineStart + 1.0, lineStart + 6.0)
                out.add(TimedLine(lineStart, safeEnd, text, lineSpeaker))
            }
            sb.setLength(0)
            lineStart = -1.0
            lineEnd = -1.0
        }

        for (i in 0 until words.length()) {
            val w = words.optJSONObject(i) ?: continue
            val token = w.optString("punctuated_word", "").ifBlank { w.optString("word", "") }.trim()
            if (token.isEmpty()) continue
            val wStart = w.optDouble("start", 0.0) + offsetSec
            val wEnd = w.optDouble("end", wStart + 0.3) + offsetSec
            val wSpeaker = if (w.has("speaker")) w.optInt("speaker") else defaultSpeaker

            val gap = if (lineEnd >= 0.0) wStart - lineEnd else 0.0
            val speakerChanged = lineSpeaker != null && wSpeaker != null && lineSpeaker != wSpeaker

            if (sb.isNotEmpty() && (gap >= 0.75 || speakerChanged || sb.length + token.length > 76 || (wEnd - lineStart) >= 5.4)) {
                flush()
            }

            if (lineStart < 0.0) {
                lineStart = wStart
                lineSpeaker = wSpeaker
            }
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(token)
            lineEnd = wEnd

            val endsSentence = token.endsWith(".") || token.endsWith("?") || token.endsWith("!")
            if (endsSentence && sb.length >= 24) {
                flush()
            }
        }
        flush()
    }

    // Translates in 45-line scene batches with speaker hints so Arabic pronouns/gender stay accurate
    private suspend fun translateTimedLines(
        lines: List<TimedLine>,
        translator: ArabicTranslator
    ): List<ExternalCue> {
        val output = mutableListOf<ExternalCue>()
        val chunks = lines.chunked(45)
        for (chunk in chunks) {
            coroutineContext.ensureActive()
            val textsForAi = chunk.map { line ->
                if (line.speaker != null) "[S${line.speaker + 1}] ${line.text}" else line.text
            }
            val translatedMap = translator.translateBatchForSubtitleFile(textsForAi)
            chunk.forEachIndexed { idx, line ->
                val rawAr = translatedMap[idx] ?: line.text
                val cleanAr = rawAr.replace(speakerPrefixRegex, "").trim()
                if (cleanAr.isNotEmpty()) {
                    output.add(
                        ExternalCue(
                            startSec = line.startSec,
                            endSec = line.endSec,
                            originalText = line.text,
                            arabicText = cleanAr
                        )
                    )
                }
            }
        }
        return output
    }

    private fun cuesToJson(cues: List<ExternalCue>): String {
        val arr = JSONArray()
        for (cue in cues) {
            arr.put(
                JSONObject().apply {
                    put("s", cue.startSec)
                    put("e", cue.endSec)
                    put("ar", cue.arabicText)
                    put("en", cue.originalText)
                }
            )
        }
        return arr.toString()
    }

    private fun pickBestSubPlaylistUrl(masterUrl: String, masterText: String): String? {
        val lines = masterText.lines().map { it.trim() }
        // 1. Check for dedicated AUDIO-only playlist first (fastest & smallest!)
        val audioUriRegex = Regex("""URI="([^"]+)"""")
        for (line in lines) {
            if (line.startsWith("#EXT-X-MEDIA:") && line.contains("TYPE=AUDIO")) {
                val m = audioUriRegex.find(line)
                if (m != null) {
                    return resolveUrl(masterUrl, m.groupValues[1])
                }
            }
        }
        // 2. Otherwise pick lowest-bandwidth video+audio variant
        var lowestBw = Long.MAX_VALUE
        var bestUrl: String? = null
        val bwRegex = Regex("""BANDWIDTH=(\d+)""")
        for (i in lines.indices) {
            val line = lines[i]
            if (line.startsWith("#EXT-X-STREAM-INF")) {
                val bw = bwRegex.find(line)?.groupValues?.get(1)?.toLongOrNull() ?: Long.MAX_VALUE
                val nextUri = lines.drop(i + 1).firstOrNull { it.isNotEmpty() && !it.startsWith("#") }
                if (nextUri != null && bw < lowestBw) {
                    lowestBw = bw
                    bestUrl = resolveUrl(masterUrl, nextUri)
                }
            }
        }
        return bestUrl
    }

    private fun extractInitMapUrl(baseUrl: String, playlistText: String): String? {
        val uriRegex = Regex("""URI="([^"]+)"""")
        for (raw in playlistText.lines()) {
            val line = raw.trim()
            if (line.startsWith("#EXT-X-MAP:")) {
                val m = uriRegex.find(line)
                if (m != null) return resolveUrl(baseUrl, m.groupValues[1])
            }
        }
        return null
    }

    private fun parseHlsSegments(baseUrl: String, playlistText: String): List<HlsSegment> {
        val list = mutableListOf<HlsSegment>()
        var pendingDuration: Double? = null
        var elapsed = 0.0
        for (raw in playlistText.lines()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTINF:")) {
                val durStr = line.removePrefix("#EXTINF:").substringBefore(',').trim()
                pendingDuration = durStr.toDoubleOrNull() ?: 4.0
            } else if (!line.startsWith("#") && pendingDuration != null) {
                val segUrl = resolveUrl(baseUrl, line)
                list.add(HlsSegment(segUrl, pendingDuration, elapsed))
                elapsed += pendingDuration
                pendingDuration = null
            }
        }
        return list
    }

    private fun resolveUrl(baseUrl: String, relative: String): String {
        if (relative.startsWith("http://") || relative.startsWith("https://")) return relative
        return runCatching { URI(baseUrl).resolve(relative).toString() }.getOrDefault(relative)
    }

    private fun fetchText(url: String, headers: Map<String, String>): String? = runCatching {
        val req = buildRequest(url, headers).get().build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return@runCatching null
            resp.body?.string()
        }
    }.getOrNull()

    private fun fetchBytes(url: String, headers: Map<String, String>): ByteArray? = runCatching {
        val req = buildRequest(url, headers).get().build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return@runCatching null
            resp.body?.bytes()
        }
    }.getOrNull()

    private fun fetchContentLength(url: String, headers: Map<String, String>): Long = runCatching {
        val req = buildRequest(url, headers).head().build()
        httpClient.newCall(req).execute().use { resp ->
            resp.header("Content-Length")?.toLongOrNull() ?: -1L
        }
    }.getOrDefault(-1L)

    private fun sanitizeHeaders(headers: Map<String, String>): Map<String, String> = buildMap {
        for ((k, v) in headers) {
            if (
                k.equals("Range", true) ||
                k.equals("Host", true) ||
                k.equals("Content-Length", true) ||
                k.equals("Accept-Encoding", true)
            ) continue
            if (v.isNotBlank()) put(k, v)
        }
    }

    private fun fetchPartialBytes(url: String, headers: Map<String, String>, maxBytes: Int): ByteArray? = runCatching {
        val req = buildRequest(url, headers)
            .header("Range", "bytes=0-${maxBytes - 1}")
            .get()
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return@runCatching null
            val stream = resp.body?.byteStream() ?: return@runCatching null
            val out = ByteArrayOutputStream()
            val buf = ByteArray(32 * 1024)
            var total = 0
            while (total < maxBytes) {
                val n = stream.read(buf, 0, minOf(buf.size, maxBytes - total))
                if (n <= 0) break
                out.write(buf, 0, n)
                total += n
            }
            out.toByteArray()
        }
    }.getOrNull()

    private fun buildRequest(url: String, headers: Map<String, String>): Request.Builder {
        val b = Request.Builder().url(url)
        for ((k, v) in headers) {
            if (
                k.equals("Range", true) ||
                k.equals("Host", true) ||
                k.equals("Content-Length", true) ||
                k.equals("Accept-Encoding", true)
            ) continue
            if (v.isNotBlank()) b.header(k, v)
        }
        return b
    }

    // Remuxes AUDIO-ONLY track from an HLS (.ts / .mp4) chunk into a clean .m4a (audio/mp4) container (~85% smaller!)
    private fun extractAudioOnlyFromMediaBytes(
        context: Context,
        mediaBytes: ByteArray,
        isMp4: Boolean
    ): Pair<ByteArray, String>? {
        val ext = if (isMp4) ".mp4" else ".ts"
        val tmpIn = runCatching { File.createTempFile("hls_in_", ext, context.cacheDir) }.getOrNull() ?: return null
        val tmpOut = runCatching { File.createTempFile("hls_out_", ".m4a", context.cacheDir) }.getOrNull() ?: run {
            runCatching { tmpIn.delete() }
            return null
        }

        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        return try {
            tmpIn.writeBytes(mediaBytes)
            extractor.setDataSource(tmpIn.absolutePath)

            var audioTrackIdx = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    audioTrackIdx = i
                    audioFormat = fmt
                    break
                }
            }
            if (audioTrackIdx < 0 || audioFormat == null) return null

            extractor.selectTrack(audioTrackIdx)
            muxer = MediaMuxer(tmpOut.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxTrackIdx = muxer.addTrack(audioFormat)
            muxer.start()
            muxerStarted = true

            val sampleBuf = ByteBuffer.allocate(256 * 1024)
            val bufferInfo = MediaCodec.BufferInfo()
            var firstPtsUs = -1L
            var lastPtsUs = -1L

            while (true) {
                sampleBuf.clear()
                val readSize = extractor.readSampleData(sampleBuf, 0)
                if (readSize < 0) break
                val sampleTimeUs = extractor.sampleTime
                if (sampleTimeUs < 0) break
                if (firstPtsUs < 0L) firstPtsUs = sampleTimeUs

                val relPts = (sampleTimeUs - firstPtsUs).coerceAtLeast(0L)
                val safePts = if (relPts < lastPtsUs) lastPtsUs else relPts
                lastPtsUs = safePts

                bufferInfo.offset = 0
                bufferInfo.size = readSize
                bufferInfo.presentationTimeUs = safePts
                bufferInfo.flags = if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
                    MediaCodec.BUFFER_FLAG_KEY_FRAME
                } else 0

                muxer.writeSampleData(muxTrackIdx, sampleBuf, bufferInfo)
                if (!extractor.advance()) break
            }

            muxer.stop()
            muxerStarted = false
            muxer.release()
            muxer = null

            val resultBytes = tmpOut.readBytes()
            if (resultBytes.size >= 1024 && resultBytes.size < mediaBytes.size) {
                Pair(resultBytes, "audio/mp4")
            } else {
                null
            }
        } catch (_: Exception) {
            null
        } finally {
            if (muxerStarted) runCatching { muxer?.stop() }
            runCatching { muxer?.release() }
            runCatching { extractor.release() }
            runCatching { tmpIn.delete() }
            runCatching { tmpOut.delete() }
        }
    }

    // Standard 7-byte ADTS header for raw AAC frames extracted by MediaExtractor
    private fun createAdtsHeader(frameLength: Int, sampleRate: Int, channels: Int): ByteArray {
        val packetLen = frameLength + 7
        val freqIdx = when (sampleRate) {
            96000 -> 0
            88200 -> 1
            64000 -> 2
            48000 -> 3
            44100 -> 4
            32000 -> 5
            24000 -> 6
            22050 -> 7
            16000 -> 8
            12000 -> 9
            11025 -> 10
            8000 -> 11
            else -> 4
        }
        val profile = 2 // AAC LC
        val chanCfg = channels.coerceIn(1, 7)
        val header = ByteArray(7)
        header[0] = 0xFF.toByte()
        header[1] = 0xF9.toByte()
        header[2] = (((profile - 1) shl 6) + (freqIdx shl 2) + (chanCfg shr 2)).toByte()
        header[3] = (((chanCfg and 3) shl 6) + (packetLen shr 11)).toByte()
        header[4] = ((packetLen and 0x7FF) shr 3).toByte()
        header[5] = (((packetLen and 7) shl 5) + 0x1F).toByte()
        header[6] = 0xFC.toByte()
        return header
    }

    private fun cacheFileFor(context: Context, mediaUrl: String): File {
        val dir = File(context.cacheDir, "proactive_subs").apply { mkdirs() }
        val cleanUrl = mediaUrl.substringBefore('?')
        val digest = MessageDigest.getInstance("SHA-256").digest(cleanUrl.toByteArray(Charsets.UTF_8))
        val hex = digest.joinToString("") { "%02x".format(it) }.take(24)
        return File(dir, "$hex.json")
    }
}
