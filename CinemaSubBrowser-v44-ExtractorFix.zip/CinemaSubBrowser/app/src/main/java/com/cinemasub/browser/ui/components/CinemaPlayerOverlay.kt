package com.cinemasub.browser.ui.components

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.cinemasub.browser.browser.ExternalCue
import com.cinemasub.browser.model.PipelineStatus
import com.cinemasub.browser.model.SubtitleSourceMode
import com.cinemasub.browser.model.SubtitleState
import com.cinemasub.browser.model.SubtitleStyleConfig
import kotlinx.coroutines.delay
import okhttp3.OkHttpClient
import org.json.JSONArray
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
@Composable
fun CinemaPlayerOverlay(
    mediaUrl: String,
    headers: Map<String, String>,
    externalSubtitlesJson: String?,
    styleConfig: SubtitleStyleConfig,
    playbackSpeed: Float,
    isGeneratingProactive: Boolean,
    proactiveProgressPercent: Int,
    onStartProactiveSubtitles: () -> Unit,
    onPlaybackPositionChanged: (Double) -> Unit,
    onNudgeSyncOffset: (Float) -> Unit,
    onResetSyncOffset: () -> Unit,
    onVerticalBiasChanged: (Float) -> Unit,
    onOpenSettings: () -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    BackHandler(enabled = true) {
        onClose()
    }

    val parsedCues = remember(externalSubtitlesJson) {
        parseCuesJson(externalSubtitlesJson)
    }

    var playerError by remember { mutableStateOf<String?>(null) }
    var controlsVisible by remember { mutableStateOf(true) }
    var lastInteractionMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var gestureHudText by remember { mutableStateOf<String?>(null) }
    var gestureHudStamp by remember { mutableLongStateOf(0L) }
    var playerViewRef by remember { mutableStateOf<PlayerView?>(null) }

    var currentSubtitleState by remember {
        mutableStateOf(
            SubtitleState(
                isLiveEnabled = true,
                sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                status = PipelineStatus.Listening
            )
        )
    }

    val exoPlayer = remember(mediaUrl) {
        val okClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()

        val cleanHeaders = buildMap {
            for ((k, v) in headers) {
                if (k.equals("Range", true) || k.equals("Host", true) || k.equals("Content-Length", true) || k.equals("Accept-Encoding", true)) {
                    continue
                }
                if (v.isNotBlank()) put(k, v)
            }
        }

        val dataSourceFactory = OkHttpDataSource.Factory(okClient)
            .setDefaultRequestProperties(cleanHeaders)

        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)

        ExoPlayer.Builder(context)
            .setMediaSourceFactory(mediaSourceFactory)
            .build()
            .apply {
                val isHls = mediaUrl.lowercase().substringBefore('?').endsWith(".m3u8")
                val itemBuilder = MediaItem.Builder().setUri(mediaUrl)
                if (isHls) {
                    itemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
                }
                setMediaItem(itemBuilder.build())
                setPlaybackSpeed(playbackSpeed)
                addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        playerError = "تعذر تشغيل البث مباشرة (${error.errorCodeName}) — جرّب سيرفر آخر أو المتصفح."
                    }
                })
                prepare()
                playWhenReady = true
            }
    }

    LaunchedEffect(playbackSpeed) {
        exoPlayer.setPlaybackSpeed(playbackSpeed)
    }

    // Auto-hide top & floating controls after 4 seconds for a clean Netflix-like screen
    LaunchedEffect(controlsVisible, lastInteractionMs) {
        if (controlsVisible) {
            delay(4000L)
            controlsVisible = false
            playerViewRef?.hideController()
        }
    }

    // Auto-hide gesture HUD (seek / brightness / volume) after 900ms
    LaunchedEffect(gestureHudStamp) {
        if (gestureHudText != null) {
            delay(900L)
            gestureHudText = null
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose {
            exoPlayer.release()
        }
    }

    // 60ms high-precision subtitle sync loop bound directly to ExoPlayer.currentPosition
    LaunchedEffect(exoPlayer, parsedCues, styleConfig.syncOffsetSec) {
        var lastKey = ""
        var lastReportedSec = -10.0
        while (true) {
            val posSec = exoPlayer.currentPosition / 1000.0
            if (kotlin.math.abs(posSec - lastReportedSec) >= 1.5) {
                lastReportedSec = posSec
                onPlaybackPositionChanged(posSec)
            }
            if (parsedCues.isNotEmpty()) {
                val tSec = posSec - styleConfig.syncOffsetSec.toDouble()
                val matched = findCueAtTime(parsedCues, tSec)
                val key = if (matched != null) "${matched.startSec}|${matched.arabicText}" else ""
                if (key != lastKey) {
                    lastKey = key
                    currentSubtitleState = SubtitleState(
                        isLiveEnabled = true,
                        sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                        status = PipelineStatus.Listening,
                        arabicText = matched?.arabicText.orEmpty(),
                        originalEnglishText = matched?.originalText.orEmpty()
                    )
                }
            } else if (lastKey.isNotEmpty()) {
                lastKey = ""
                currentSubtitleState = SubtitleState(
                    isLiveEnabled = true,
                    sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                    status = PipelineStatus.Listening,
                    arabicText = "",
                    originalEnglishText = ""
                )
            }
            delay(60L)
        }
    }

    var brightnessDragAccum by remember { mutableFloatStateOf(0f) }
    var volumeDragAccum by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    player = exoPlayer
                    useController = true
                    controllerAutoShow = false
                    controllerShowTimeoutMs = 4000
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                    playerViewRef = this
                }
            },
            update = { view ->
                playerViewRef = view
                if (view.player !== exoPlayer) {
                    view.player = exoPlayer
                }
            }
        )

        // VLC / MX Player style Touch Gestures layer (Tap to toggle UI, Double-Tap +-10s, Vertical Drag Brightness/Volume)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 64.dp, bottom = 92.dp)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            val next = !controlsVisible
                            controlsVisible = next
                            lastInteractionMs = System.currentTimeMillis()
                            if (next) playerViewRef?.showController() else playerViewRef?.hideController()
                        },
                        onDoubleTap = { offset ->
                            val isRightHalf = offset.x > size.width / 2f
                            val deltaMs = if (isRightHalf) 10_000L else -10_000L
                            val duration = exoPlayer.duration.takeIf { it > 0 } ?: Long.MAX_VALUE
                            val target = (exoPlayer.currentPosition + deltaMs).coerceIn(0L, duration)
                            exoPlayer.seekTo(target)
                            gestureHudText = if (isRightHalf) "+10 ثواني ⏩" else "⏪ -10 ثواني"
                            gestureHudStamp = System.currentTimeMillis()
                        }
                    )
                }
                .pointerInput(Unit) {
                    var dragOnLeft = true
                    detectVerticalDragGestures(
                        onDragStart = { startOffset ->
                            dragOnLeft = startOffset.x < size.width / 2f
                            brightnessDragAccum = 0f
                            volumeDragAccum = 0f
                        },
                        onVerticalDrag = { change, dragAmount ->
                            change.consume()
                            val deltaRatio = -dragAmount / (size.height.coerceAtLeast(300).toFloat() * 0.65f)
                            if (dragOnLeft) {
                                // Left side: Screen Brightness
                                activity?.window?.let { win ->
                                    val lp = win.attributes
                                    val currentB = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                                    val newB = (currentB + deltaRatio).coerceIn(0.05f, 1.0f)
                                    lp.screenBrightness = newB
                                    win.attributes = lp
                                    val pct = (newB * 100f).roundToInt()
                                    gestureHudText = "☀️ الإضاءة $pct%"
                                    gestureHudStamp = System.currentTimeMillis()
                                }
                            } else {
                                // Right side: Media Volume
                                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                volumeDragAccum += deltaRatio * maxVol
                                val step = volumeDragAccum.toInt()
                                if (step != 0) {
                                    volumeDragAccum -= step
                                    val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                    val newVol = (curVol + step).coerceIn(0, maxVol)
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVol, 0)
                                    val pct = (newVol * 100) / maxVol
                                    gestureHudText = "🔊 الصوت $pct%"
                                    gestureHudStamp = System.currentTimeMillis()
                                }
                            }
                        }
                    )
                }
        )

        // 100% Synced Netflix-style Subtitle Overlay
        NetflixSubtitleOverlay(
            subtitleState = currentSubtitleState,
            styleConfig = styleConfig,
            onVerticalBiasChanged = onVerticalBiasChanged,
            modifier = Modifier.fillMaxSize()
        )

        // Gesture Feedback HUD (center pill for +-10s / Brightness / Volume)
        AnimatedVisibility(
            visible = gestureHudText != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Surface(
                color = Color(0xCC000000),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = gestureHudText.orEmpty(),
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
                )
            }
        }

        // Error banner if stream rejects direct playback
        playerError?.let { msg ->
            Surface(
                color = Color(0xDD991B1B),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
            ) {
                Text(
                    text = msg,
                    color = Color.White,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }

        // Auto-hiding Top Bar: Close + Proactive Subtitle Trigger + Settings
        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(38.dp)
                        .background(Color(0x99000000), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق المشغّل",
                        tint = Color.White
                    )
                }

                // Center: Proactive Generate / Status Pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = when {
                        parsedCues.isNotEmpty() && !isGeneratingProactive -> Color(0xBB166534)
                        isGeneratingProactive -> Color(0xCC1E3A8A)
                        else -> Color(0xDDE50914)
                    },
                    modifier = Modifier.clickable(enabled = !isGeneratingProactive) {
                        lastInteractionMs = System.currentTimeMillis()
                        onStartProactiveSubtitles()
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (isGeneratingProactive) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                            Text(
                                text = "جاري الترجمة ($proactiveProgressPercent%)...",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else if (parsedCues.isNotEmpty()) {
                            Icon(
                                imageVector = Icons.Default.Subtitles,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "ترجمة 100% (${parsedCues.size} جملة)",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Subtitles,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "توليد ترجمة 100%",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                IconButton(
                    onClick = {
                        lastInteractionMs = System.currentTimeMillis()
                        onOpenSettings()
                    },
                    modifier = Modifier
                        .size(38.dp)
                        .background(Color(0x99000000), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "إعدادات الترجمة",
                        tint = Color.White
                    )
                }
            }
        }

        // Auto-hiding Compact floating Sync & Position pill bar (top-end below settings)
        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 60.dp, end = 12.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    PlayerMiniChip("-0.2") {
                        lastInteractionMs = System.currentTimeMillis()
                        onNudgeSyncOffset(-0.2f)
                    }
                    PlayerMiniChip("+0.2") {
                        lastInteractionMs = System.currentTimeMillis()
                        onNudgeSyncOffset(0.2f)
                    }
                    PlayerMiniChip("▲") {
                        lastInteractionMs = System.currentTimeMillis()
                        onVerticalBiasChanged(styleConfig.verticalBias - 0.04f)
                    }
                    PlayerMiniChip("▼") {
                        lastInteractionMs = System.currentTimeMillis()
                        onVerticalBiasChanged(styleConfig.verticalBias + 0.04f)
                    }
                }
                if (kotlin.math.abs(styleConfig.syncOffsetSec) >= 0.05f) {
                    val sign = if (styleConfig.syncOffsetSec > 0) "+" else ""
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xCC000000),
                        modifier = Modifier.clickable {
                            lastInteractionMs = System.currentTimeMillis()
                            onResetSyncOffset()
                        }
                    ) {
                        Text(
                            text = "${sign}${String.format("%.1f", styleConfig.syncOffsetSec)}s ↺",
                            color = Color(0xFFF5C518),
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerMiniChip(label: String, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xAA18181B),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
        )
    }
}

private fun parseCuesJson(json: String?): List<ExternalCue> {
    if (json.isNullOrBlank()) return emptyList()
    return runCatching {
        val arr = JSONArray(json)
        val list = ArrayList<ExternalCue>(arr.length())
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val s = obj.optDouble("s", -1.0)
            val e = obj.optDouble("e", -1.0)
            val ar = obj.optString("ar", "")
            val en = obj.optString("en", "")
            if (s >= 0.0 && e > s && ar.isNotBlank()) {
                list.add(ExternalCue(s, e, en, ar))
            }
        }
        list.sortBy { it.startSec }
        list
    }.getOrDefault(emptyList())
}

private fun findCueAtTime(cues: List<ExternalCue>, tSec: Double): ExternalCue? {
    var lo = 0
    var hi = cues.size - 1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        val c = cues[mid]
        when {
            tSec < c.startSec -> hi = mid - 1
            tSec > c.endSec -> lo = mid + 1
            else -> return c
        }
    }
    return null
}
