package com.cinemasub.browser.translation

import android.content.Context
import com.cinemasub.browser.model.AiTranslationConfig
import com.cinemasub.browser.model.DeepgramLanguage
import com.cinemasub.browser.model.SubtitleDialect
import com.cinemasub.browser.model.TranslationEngine

object TranslationSettingsStore {

    private const val PREFS_NAME = "cinemasub_ai_prefs"
    private const val KEY_ENGINE = "translation_engine"
    private const val KEY_DIALECT = "subtitle_dialect"
    private const val KEY_GEMINI = "gemini_api_key"
    private const val KEY_GROQ = "groq_api_key"
    private const val KEY_OPENROUTER = "openrouter_api_key"
    private const val KEY_DEEPGRAM = "deepgram_api_key"
    private const val KEY_DEEPGRAM_LANG = "deepgram_language"
    private const val KEY_ADBLOCK = "adblock_enabled"
    private const val KEY_SYNC_OFFSET = "sync_offset_sec"
    private const val KEY_DUAL_SUB = "dual_subtitles_enabled"
    private const val KEY_FORCE_DARK = "force_dark_mode"

    @Volatile
    var currentConfig: AiTranslationConfig = AiTranslationConfig()
        private set

    @Volatile
    var isAdBlockerEnabled: Boolean = true
        private set

    @Volatile
    var syncOffsetSec: Float = 0f
        private set

    @Volatile
    var dualSubtitlesEnabled: Boolean = false
        private set

    @Volatile
    var forceDarkMode: Boolean = false
        private set

    @Volatile
    var currentPageTitle: String = ""

    fun init(context: Context) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val engineName = prefs.getString(KEY_ENGINE, TranslationEngine.AUTO_HYBRID.name)
        val engine = runCatching { TranslationEngine.valueOf(engineName ?: "") }
            .getOrDefault(TranslationEngine.AUTO_HYBRID)
        val dialectName = prefs.getString(KEY_DIALECT, SubtitleDialect.CINEMA_MSA.name)
        val dialect = runCatching { SubtitleDialect.valueOf(dialectName ?: "") }
            .getOrDefault(SubtitleDialect.CINEMA_MSA)
        val geminiKey = prefs.getString(KEY_GEMINI, "") ?: ""
        val groqKey = prefs.getString(KEY_GROQ, "") ?: ""
        val openRouterKey = prefs.getString(KEY_OPENROUTER, "") ?: ""
        val deepgramKey = prefs.getString(KEY_DEEPGRAM, "") ?: ""
        val dgLangName = prefs.getString(KEY_DEEPGRAM_LANG, DeepgramLanguage.ENGLISH.name)
        val dgLang = runCatching { DeepgramLanguage.valueOf(dgLangName ?: "") }
            .getOrDefault(DeepgramLanguage.ENGLISH)
        isAdBlockerEnabled = prefs.getBoolean(KEY_ADBLOCK, true)
        syncOffsetSec = prefs.getFloat(KEY_SYNC_OFFSET, 0f)
        dualSubtitlesEnabled = prefs.getBoolean(KEY_DUAL_SUB, false)
        forceDarkMode = prefs.getBoolean(KEY_FORCE_DARK, false)
        currentConfig = AiTranslationConfig(
            engine = engine,
            dialect = dialect,
            geminiApiKey = geminiKey,
            groqApiKey = groqKey,
            openRouterApiKey = openRouterKey,
            deepgramApiKey = deepgramKey,
            deepgramLanguage = dgLang
        )
    }

    fun update(context: Context, config: AiTranslationConfig) {
        currentConfig = config
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_ENGINE, config.engine.name)
            .putString(KEY_DIALECT, config.dialect.name)
            .putString(KEY_GEMINI, config.geminiApiKey.trim())
            .putString(KEY_GROQ, config.groqApiKey.trim())
            .putString(KEY_OPENROUTER, config.openRouterApiKey.trim())
            .putString(KEY_DEEPGRAM, config.deepgramApiKey.trim())
            .putString(KEY_DEEPGRAM_LANG, config.deepgramLanguage.name)
            .apply()
    }

    fun setAdBlockerEnabled(context: Context, enabled: Boolean) {
        isAdBlockerEnabled = enabled
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_ADBLOCK, enabled).apply()
    }

    fun setSyncOffsetSec(context: Context, offsetSec: Float) {
        syncOffsetSec = offsetSec
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putFloat(KEY_SYNC_OFFSET, offsetSec).apply()
    }

    fun setDualSubtitlesEnabled(context: Context, enabled: Boolean) {
        dualSubtitlesEnabled = enabled
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_DUAL_SUB, enabled).apply()
    }

    fun setForceDarkMode(context: Context, enabled: Boolean) {
        forceDarkMode = enabled
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_FORCE_DARK, enabled).apply()
    }
}
