package com.cinemasub.browser.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinemasub.browser.model.AiTranslationConfig
import com.cinemasub.browser.model.DeepgramLanguage
import com.cinemasub.browser.model.SubtitleBgOpacity
import com.cinemasub.browser.model.SubtitleDialect
import com.cinemasub.browser.model.SubtitleFontSize
import com.cinemasub.browser.model.SubtitleStyleConfig
import com.cinemasub.browser.model.SubtitleTextColor
import com.cinemasub.browser.model.TranslationEngine

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SubtitleSettingsSheet(
    styleConfig: SubtitleStyleConfig,
    aiConfig: AiTranslationConfig,
    adBlockerEnabled: Boolean,
    blockedAdsCount: Int,
    forceDarkMode: Boolean,
    playbackSpeed: Float,
    externalSubtitleFileName: String?,
    isLoadingExternalSubtitle: Boolean,
    isTestingApiKey: Boolean,
    apiKeyTestResult: Pair<Boolean, String>?,
    isTestingDeepgramKey: Boolean,
    deepgramTestResult: Pair<Boolean, String>?,
    onAdBlockerChange: (Boolean) -> Unit,
    onForceDarkModeChange: (Boolean) -> Unit,
    onDualSubtitlesChange: (Boolean) -> Unit,
    onPlaybackSpeedChange: (Float) -> Unit,
    onImportExternalSubtitle: () -> Unit,
    onClearExternalSubtitle: () -> Unit,
    onEngineChange: (TranslationEngine) -> Unit,
    onDialectChange: (SubtitleDialect) -> Unit,
    onGeminiKeyChange: (String) -> Unit,
    onGroqKeyChange: (String) -> Unit,
    onOpenRouterKeyChange: (String) -> Unit,
    onDeepgramKeyChange: (String) -> Unit,
    onDeepgramLanguageChange: (DeepgramLanguage) -> Unit,
    onSyncOffsetChange: (Float) -> Unit,
    onTestApiKey: () -> Unit,
    onTestDeepgramKey: () -> Unit,
    onFontSizeChange: (SubtitleFontSize) -> Unit,
    onTextColorChange: (SubtitleTextColor) -> Unit,
    onBgOpacityChange: (SubtitleBgOpacity) -> Unit,
    onVerticalBiasChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "إعدادات المتصفح والترجمة",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                // Ad-Blocker & Pop-up Blocker Switch
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "مانع الإعلانات والنوافذ المنبثقة (Pop-ups)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = if (adBlockerEnabled) {
                                "مفعّل • تم حظر $blockedAdsCount إعلان/نافذة في هذه الصفحة"
                            } else {
                                "متوقف • يمكنك تشغيله لمنع الإعلانات والبوب أب"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (adBlockerEnabled) Color(0xFF4ADE80) else Color.Gray
                        )
                    }
                    Switch(
                        checked = adBlockerEnabled,
                        onCheckedChange = onAdBlockerChange
                    )
                }

                // Force Dark Mode Switch
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("الوضع الليلي الإجباري للمواقع", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = "يحول المواقع ذات الخلفية البيضاء للون داكن مريح للعين",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = forceDarkMode, onCheckedChange = onForceDarkModeChange)
                }

                // Dual Subtitles Switch (English + Arabic)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("الترجمة المزدوجة (إنجليزي + عربي)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = "إظهار السطر الإنجليزي فوق العربي لتقوية الاستماع واللغة",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = styleConfig.dualSubtitlesEnabled, onCheckedChange = onDualSubtitlesChange)
                }

                // External .srt / .vtt Subtitle File Import Card
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "ملف ترجمة خارجي (.srt / .vtt) من الموبايل",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = externalSubtitleFileName
                            ?: "للفيديوهات الخام: اختر ملف ترجمة وسيركّبه التطبيق بتوقيت مثالي ويترجمه تلقائياً",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (externalSubtitleFileName != null) Color(0xFF4ADE80) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onImportExternalSubtitle,
                            enabled = !isLoadingExternalSubtitle,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(if (isLoadingExternalSubtitle) "جاري التحميل والترجمة..." else "اختيار ملف ترجمة")
                        }
                        if (externalSubtitleFileName != null) {
                            OutlinedButton(
                                onClick = onClearExternalSubtitle,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("مسح")
                            }
                        }
                    }
                }

                // Video Playback Speed
                Text("سرعة تشغيل الفيديو", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                        FilterChip(
                            selected = kotlin.math.abs(playbackSpeed - spd) < 0.05f,
                            onClick = { onPlaybackSpeedChange(spd) },
                            label = { Text("${spd}x", fontSize = 12.sp) }
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                // Dialect Selector
                Text("أسلوب الترجمة", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SubtitleDialect.entries.forEach { dialect ->
                        FilterChip(
                            selected = aiConfig.dialect == dialect,
                            onClick = { onDialectChange(dialect) },
                            label = { Text(dialect.labelAr, fontSize = 13.sp) }
                        )
                    }
                }

                // AI Engine Selector
                Text("محرك الترجمة", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    TranslationEngine.entries.forEach { engine ->
                        FilterChip(
                            selected = aiConfig.engine == engine,
                            onClick = { onEngineChange(engine) },
                            label = { Text(engine.labelAr, fontSize = 12.sp) }
                        )
                    }
                }

                if (aiConfig.engine == TranslationEngine.AUTO_HYBRID) {
                    Text(
                        text = "يدمج كل المفاتيح اللي تحطها مع بعض لترجمة أفلام فورية بدون توقف أو تأخير:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF4ADE80)
                    )
                }

                if (aiConfig.engine == TranslationEngine.GROQ_AI || aiConfig.engine == TranslationEngine.AUTO_HYBRID) {
                    OutlinedTextField(
                        value = aiConfig.groqApiKey,
                        onValueChange = onGroqKeyChange,
                        label = { Text("مفتاح Groq API (مجاني بدون فيزا)") },
                        placeholder = { Text("gsk_...") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (aiConfig.engine == TranslationEngine.GEMINI_AI || aiConfig.engine == TranslationEngine.AUTO_HYBRID) {
                    OutlinedTextField(
                        value = aiConfig.geminiApiKey,
                        onValueChange = onGeminiKeyChange,
                        label = { Text("مفتاح Gemini API (مجاني بدون فيزا)") },
                        placeholder = { Text("AIzaSy...") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (aiConfig.engine == TranslationEngine.OPENROUTER_AI || aiConfig.engine == TranslationEngine.AUTO_HYBRID) {
                    OutlinedTextField(
                        value = aiConfig.openRouterApiKey,
                        onValueChange = onOpenRouterKeyChange,
                        label = { Text("مفتاح OpenRouter المجاني (openrouter.ai/keys)") },
                        placeholder = { Text("sk-or-v1-...") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Test API Key Button + Live Status Result
                if (aiConfig.engine != TranslationEngine.GOOGLE_FREE) {
                    Button(
                        onClick = onTestApiKey,
                        enabled = !isTestingApiKey,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isTestingApiKey) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جاري اختبار المفتاح...")
                        } else {
                            Text(if (aiConfig.engine == TranslationEngine.AUTO_HYBRID) "اختبار جميع المفاتيح الآن" else "اختبار المفتاح الآن")
                        }
                    }

                    apiKeyTestResult?.let { (success, message) ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (success) Color(0xFF14532D) else Color(0xFF7F1D1D)
                                )
                                .padding(12.dp)
                        ) {
                            Text(
                                text = (if (success) "✅ " else "❌ ") + message,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                // Live Preview Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1F2937)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .background(styleConfig.bgOpacity.color, RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "معاينة الترجمة العربية بأسلوب سينمائي",
                            style = TextStyle(
                                color = styleConfig.textColor.color,
                                fontSize = styleConfig.fontSize.sp.sp,
                                fontWeight = FontWeight.Bold,
                                shadow = Shadow(Color.Black, Offset(2f, 2f), 5f)
                            )
                        )
                    }
                }

                // Deepgram Real-time WebSocket Key (WatchTranslate-grade live audio sync)
                OutlinedTextField(
                    value = aiConfig.deepgramApiKey,
                    onValueChange = onDeepgramKeyChange,
                    label = { Text("مفتاح Deepgram للبث اللحظي (مجاني $200 بدون فيزا)") },
                    placeholder = { Text("console.deepgram.com") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = onTestDeepgramKey,
                    enabled = !isTestingDeepgramKey,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    if (isTestingDeepgramKey) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = Color.White
                        )
                    } else {
                        Text("اختبار مفتاح Deepgram الآن")
                    }
                }

                deepgramTestResult?.let { (ok, msg) ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (ok) Color(0xFF14532D) else Color(0xFF7F1D1D))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = msg,
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    }
                }

                Text("لغة الصوت في البث اللحظي (Deepgram)", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DeepgramLanguage.entries.forEach { lang ->
                        FilterChip(
                            selected = aiConfig.deepgramLanguage == lang,
                            onClick = { onDeepgramLanguageChange(lang) },
                            label = { Text(lang.labelAr, fontSize = 12.sp) }
                        )
                    }
                }

                Text("حجم الخط", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SubtitleFontSize.entries.forEach { size ->
                        FilterChip(
                            selected = styleConfig.fontSize == size,
                            onClick = { onFontSizeChange(size) },
                            label = { Text(size.labelAr) }
                        )
                    }
                }

                Text("لون النص", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    SubtitleTextColor.entries.forEach { option ->
                        val selected = styleConfig.textColor == option
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .border(
                                    width = if (selected) 2.dp else 1.dp,
                                    color = if (selected) MaterialTheme.colorScheme.primary else Color.Gray,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { onTextColorChange(option) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(18.dp)
                                    .clip(CircleShape)
                                    .background(option.color)
                            )
                            Text(option.labelAr)
                        }
                    }
                }

                Text("خلفية الترجمة", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SubtitleBgOpacity.entries.forEach { bg ->
                        FilterChip(
                            selected = styleConfig.bgOpacity == bg,
                            onClick = { onBgOpacityChange(bg) },
                            label = { Text(bg.labelAr) }
                        )
                    }
                }

                val syncLabel = when {
                    styleConfig.syncOffsetSec < 0f -> "تقديم الترجمة ${String.format("%.1f", -styleConfig.syncOffsetSec)} ثانية"
                    styleConfig.syncOffsetSec > 0f -> "تأخير الترجمة ${String.format("%.1f", styleConfig.syncOffsetSec)} ثانية"
                    else -> "متزامن افتراضياً (0.0 ثانية)"
                }
                Text(
                    text = "ضبط توقيت الترجمة: $syncLabel",
                    style = MaterialTheme.typography.labelLarge
                )
                Slider(
                    value = styleConfig.syncOffsetSec,
                    onValueChange = onSyncOffsetChange,
                    valueRange = -3f..3f
                )

                Text(
                    text = "الموضع العمودي (${(styleConfig.verticalBias * 100).toInt()}%)",
                    style = MaterialTheme.typography.labelLarge
                )
                Slider(
                    value = styleConfig.verticalBias,
                    onValueChange = onVerticalBiasChange,
                    valueRange = 0.1f..0.9f
                )

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
