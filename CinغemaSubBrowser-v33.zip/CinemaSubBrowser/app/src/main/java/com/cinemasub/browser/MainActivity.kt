package com.cinemasub.browser

import android.Manifest
import android.app.Activity
import android.app.PictureInPictureParams
import android.util.Rational
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.cinemasub.browser.audio.AudioCaptureService
import com.cinemasub.browser.ui.BrowserScreen
import com.cinemasub.browser.ui.BrowserViewModel
import com.cinemasub.browser.ui.components.PermissionRationaleDialog
import com.cinemasub.browser.ui.theme.CinemaSubTheme

class MainActivity : ComponentActivity() {

    private val viewModel: BrowserViewModel by viewModels()
    private var showPermissionDialog by mutableStateOf(false)

    private val audioPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val recordGranted = grants[Manifest.permission.RECORD_AUDIO] == true
        if (recordGranted) {
            requestMediaProjection()
        } else {
            Toast.makeText(
                this,
                "الترجمة الصوتية تحتاج إذن الميكروفون لالتقاط صوت الفيديو",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            viewModel.setWebCaptionEnabled(false)
            val serviceIntent = Intent(this, AudioCaptureService::class.java).apply {
                action = AudioCaptureService.ACTION_START
                putExtra(AudioCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(AudioCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        viewModel.loadSavedSettings(applicationContext)

        setContent {
            CinemaSubTheme {
                BrowserScreen(
                    viewModel = viewModel,
                    onToggleSmartTranslation = ::handleSmartTranslationToggle,
                    onToggleLiveAudioFallback = ::handleLiveAudioFallbackToggle,
                    onSystemFullscreenChanged = ::toggleSystemBars,
                    onEnterPipMode = ::enterPipCompat
                )

                if (showPermissionDialog) {
                    PermissionRationaleDialog(
                        onConfirm = {
                            showPermissionDialog = false
                            requestRequiredPermissions()
                        },
                        onDismiss = { showPermissionDialog = false }
                    )
                }
            }
        }
    }

    private fun handleSmartTranslationToggle() {
        val isAudioActive = AudioCaptureService.subtitleState.value.isLiveEnabled
        val isWebActive = viewModel.uiState.value.webCaptionEnabled

        if (isAudioActive || isWebActive) {
            viewModel.setWebCaptionEnabled(false)
            if (isAudioActive) {
                startService(
                    Intent(this, AudioCaptureService::class.java).apply {
                        action = AudioCaptureService.ACTION_STOP
                    }
                )
            }
        } else {
            viewModel.setWebCaptionEnabled(true)
        }
    }

    private fun handleLiveAudioFallbackToggle() {
        if (AudioCaptureService.subtitleState.value.isLiveEnabled) {
            startService(
                Intent(this, AudioCaptureService::class.java).apply {
                    action = AudioCaptureService.ACTION_STOP
                }
            )
            return
        }

        val hasAudioPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasAudioPermission) {
            requestMediaProjection()
        } else {
            showPermissionDialog = true
        }
    }

    private fun requestRequiredPermissions() {
        val perms = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        audioPermissionsLauncher.launch(perms.toTypedArray())
    }

    private fun requestMediaProjection() {
        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(projectionManager.createScreenCaptureIntent())
    }


    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (viewModel.uiState.value.isFullscreenVideo) {
            enterPipCompat()
        }
    }

    private fun enterPipCompat() {
        runCatching {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    private fun toggleSystemBars(fullscreen: Boolean) {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        if (fullscreen) {
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }
}
