package com.cinemasub.browser.browser

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

object AdBlocker {

    private val emptyResponseBytes = ByteArray(0)

    private val blockedHosts: Set<String> = hashSetOf(
        // In-Page Push & Aggressive Streaming Ad Networks
        "push.house",
        "rollerads.com",
        "richads.com",
        "evadav.com",
        "pushground.com",
        "megapush.com",
        "daopush.com",
        "froggyads.com",
        "vdo.ai",
        "bidglass.com",
        "adnium.com",
        "a-mo.net",
        "bidgear.com",
        "betterbanners.org",
        "propu.sh",
        "dolohen.com",
        "glizauvo.net",
        "choupsee.com",
        "waisheph.com",
        "onmarshtompor.com",
        "upskittyan.com",
        "jads.co",
        "mostbet.com",
        "linebet.com",
        "parimatch.com",
        "betwinner.com",
        // Google / YouTube / Big Tech Ads & Trackers
        "doubleclick.net",
        "googleadservices.com",
        "googlesyndication.com",
        "adservice.google.com",
        "pagead2.googlesyndication.com",
        "tpc.googlesyndication.com",
        "google-analytics.com",
        "googletagmanager.com",
        "googletagservices.com",
        "ads.youtube.com",
        "imasdk.googleapis.com",
        "amazon-adsystem.com",
        "ads.facebook.com",
        "an.facebook.com",
        "pixel.facebook.com",
        "ads.twitter.com",
        "ads-api.twitter.com",
        "analytics.tiktok.com",
        "ads.tiktok.com",
        "bat.bing.com",
        "ads.yahoo.com",
        "gemini.yahoo.com",
        // Pop-up / Pop-under / Redirect Networks
        "popads.net",
        "popcash.net",
        "propellerads.com",
        "propellerclick.com",
        "onclickalgo.com",
        "onclickmax.com",
        "onclickperformance.com",
        "onclkds.com",
        "monetag.com",
        "alwingulla.com",
        "o4ux.com",
        "adsterra.com",
        "highperformanceformat.com",
        "profitabledisplaynetwork.com",
        "profitablecpmrate.com",
        "topcreativeformat.com",
        "hilltopads.net",
        "hilltopads.com",
        "exoclick.com",
        "exosrv.com",
        "realsrv.com",
        "juicyads.com",
        "trafficjunky.net",
        "trafficjunky.com",
        "trafficstars.com",
        "tsyndicate.com",
        "clickadu.com",
        "clickadilla.com",
        "galaksion.com",
        "admaven.com",
        "ad-maven.com",
        "pushame.com",
        "pushwelcome.com",
        "pushnotifications.click",
        "notifpush.com",
        "acscdn.com",
        "adtng.com",
        "adspyglass.com",
        "adskeeper.com",
        "adskeeper.co.uk",
        "bidvertiser.com",
        "yllix.com",
        "a-ads.com",
        "adcash.com",
        "ufpcdn.com",
        "zeroredirect1.com",
        "zeroredirect2.com",
        "bet365.com",
        "1xbet.com",
        "melbet.com",
        // Programmatic & Native Ads
        "adnxs.com",
        "adsrvr.org",
        "advertising.com",
        "criteo.com",
        "criteo.net",
        "outbrain.com",
        "taboola.com",
        "pubmatic.com",
        "rubiconproject.com",
        "openx.net",
        "casalemedia.com",
        "indexww.com",
        "smartadserver.com",
        "sharethrough.com",
        "teads.tv",
        "yieldmo.com",
        "triplelift.com",
        "33across.com",
        "lijit.com",
        "sovrn.com",
        "scorecardresearch.com",
        "quantserve.com",
        "moatads.com",
        "doubleverify.com",
        "adsafeprotected.com",
        "adcolony.com",
        "applovin.com",
        "unityads.unity3d.com",
        "vungle.com",
        "inmobi.com",
        "chartboost.com",
        "ironsrc.com",
        "mgid.com",
        "revcontent.com",
        "zedo.com",
        "spotxchange.com",
        "springserve.com",
        "lkqd.net",
        "innovid.com",
        "flashtalking.com",
        "serving-sys.com",
        "mediavine.com",
        "adthrive.com",
        "ezoic.net",
        "ezoic.com",
        "buysellads.com",
        "carbonads.net",
        "hotjar.com",
        "clarity.ms",
        "newrelic.com",
        "nr-data.net",
        "sentry.io",
        "segment.io",
        "mixpanel.com",
        "amplitude.com"
    )

    private val blockedUrlPatterns = listOf(
        "/pagead/",
        "/ptracking",
        "/api/stats/ads",
        "/adserver/",
        "/adsystem/",
        "/ads/vast",
        "/vast.xml",
        "/vpaid",
        "ad_type=",
        "doubleclick",
        "googlesyndication",
        "popunder",
        "pop-under",
        "popads",
        "adsterra",
        "propeller",
        "clicktrack",
        "banner_ad",
        "/banners/ad",
        "/inpage/",
        "/ipp/",
        "inpagepush",
        "push-notification",
        "sw.js?zoneid=",
        "zoneid="
    )

    fun isAd(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
        val host = uri.host?.lowercase() ?: return false

        var currentHost = host
        while (currentHost.contains('.')) {
            if (currentHost in blockedHosts) return true
            currentHost = currentHost.substringAfter('.')
        }

        val lowerUrl = url.lowercase()
        return blockedUrlPatterns.any { lowerUrl.contains(it) }
    }

    fun isBlockedNavigation(url: String?, currentPageUrl: String? = null, hasGesture: Boolean = false): Boolean {
        if (url.isNullOrBlank()) return false
        val lower = url.lowercase()
        if (lower.startsWith("intent://") ||
            lower.startsWith("market://") ||
            lower.startsWith("tg://") ||
            lower.startsWith("whatsapp://") ||
            lower.startsWith("mailto:")
        ) {
            return true
        }
        if (isAd(url)) return true

        // Sneaky automatic ad redirects only. A link the user tapped on is never blocked by these
        // patterns (they used to break legitimate links containing /jump/ or click_id=).
        if (!hasGesture &&
            (lower.contains("/afu.php") || lower.contains("utm_campaign=pop"))
        ) {
            return true
        }
        return false
    }

    fun createEmptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(emptyResponseBytes))

    fun getCosmeticAndPopupShieldScript(enabled: Boolean): String = if (enabled) {
        """
        (function() {
            window.__cinemaAdBlockEnabled = true;

            // 1. Block window.open & push Notification prompts
            if (!window.__origWindowOpen) {
                window.__origWindowOpen = window.open;
            }
            window.open = function() {
                if (window.__cinemaAdBlockEnabled) return null;
                return window.__origWindowOpen.apply(window, arguments);
            };
            try {
                if (window.Notification) {
                    window.Notification.requestPermission = function() {
                        return Promise.resolve("denied");
                    };
                }
            } catch (e) {}

            // 2. Hook Shadow DOM so hidden In-Page Push ads inside shadow roots can be inspected and removed
            if (!window.__cinemaShadowRoots) {
                window.__cinemaShadowRoots = [];
                var origAttachShadow = Element.prototype.attachShadow;
                if (origAttachShadow) {
                    Element.prototype.attachShadow = function(init) {
                        var root = origAttachShadow.call(this, init);
                        try { window.__cinemaShadowRoots.push({ host: this, root: root }); } catch (e) {}
                        return root;
                    };
                }
            }

            // 3. Guard against target="_blank" popup hijacks
            if (!window.__cinemaPopupClickGuard) {
                window.__cinemaPopupClickGuard = true;
                document.addEventListener("click", function(e) {
                    if (!window.__cinemaAdBlockEnabled) return;
                    var el = e.target;
                    while (el && el.tagName !== "A" && el !== document.body) {
                        el = el.parentElement;
                    }
                    if (el && el.tagName === "A") {
                        var href = (el.getAttribute("href") || "").toLowerCase();
                        var crossOrigin = false;
                        try { crossOrigin = new URL(el.href, location.href).host !== location.host; } catch (err) {}
                        if (crossOrigin && el.target === "_blank" && (
                            href.indexOf("popunder") !== -1 ||
                            href.indexOf("popads") !== -1 ||
                            href.indexOf("click") !== -1 ||
                            href.indexOf("redirect") !== -1 ||
                            href.indexOf("afu.php") !== -1
                        )) {
                            e.preventDefault();
                            e.stopPropagation();
                        }
                    }
                }, true);
            }

            // 4. Cosmetic CSS Shield
            var styleId = "cinemasub-adblock-css";
            if (!document.getElementById(styleId)) {
                var style = document.createElement("style");
                style.id = styleId;
                style.textContent = [
                    "ins.adsbygoogle,",
                    "[id*='google_ads'],",
                    "[id^='div-gpt-ad'],",
                    "[class*='adsbygoogle'],",
                    ".ytp-ad-module,",
                    ".ytp-ad-overlay-container,",
                    ".ytp-ad-player-overlay,",
                    "ytd-ad-slot-renderer,",
                    "ytm-promoted-sparkles-web-renderer,",
                    "ytm-companion-ad-renderer,",
                    ".ad-container, .ad-banner, .ads-banner, .ad-wrapper,",
                    ".popup-ad, .popunder, .floating-ad, .sticky-ad,",
                    "[class*='inpage'], [id*='inpage'], [class*='push-ad'], [id*='push-ad'],",
                    "iframe[src*='doubleclick'], iframe[src*='googlesyndication'],",
                    "iframe[src*='adsterra'], iframe[src*='exoclick'], iframe[src*='popads'],",
                    "iframe[src*='monetag'], iframe[src*='propeller'] {",
                    "  display: none !important;",
                    "  visibility: hidden !important;",
                    "  height: 0 !important;",
                    "  pointer-events: none !important;",
                    "}"
                ].join("\n");
                (document.head || document.documentElement).appendChild(style);
            }

            function looksLikeAdCard(el, txt) {
                if (!el) return false;
                if (el.querySelector && el.querySelector("video")) return false;
                var lowerTxt = (txt || "").toLowerCase();
                var cls = (el.className || "").toString().toLowerCase();
                var idStr = (el.id || "").toLowerCase();

                if (lowerTxt.indexOf("play now") !== -1 && lowerTxt.length < 360) return true;
                if (txt.indexOf("خبر فوز") !== -1 || txt.indexOf("دورك الآن") !== -1) return true;
                if (txt.indexOf("بوابات أوليمبوس") !== -1 || (txt.indexOf("سحب") !== -1 && txt.indexOf("دولار") !== -1)) return true;
                if (txt.indexOf("مكافأة") !== -1 && lowerTxt.length < 280) return true;
                if (/\bad\b/i.test(txt) && txt.length < 280 && el.offsetHeight > 40 && el.offsetHeight < 380) return true;
                if (cls.indexOf("inpage") !== -1 || cls.indexOf("push-ad") !== -1 || cls.indexOf("vignette") !== -1) return true;
                if (idStr.indexOf("inpage") !== -1 || idStr.indexOf("push_ad") !== -1) return true;
                return false;
            }

            function sweepContainer(rootDoc) {
                if (!rootDoc) return;
                var all = rootDoc.querySelectorAll("div, section, aside, iframe, a");
                for (var i = 0; i < all.length; i++) {
                    var el = all[i];
                    if (!el || el.id === "cinemasub-adblock-css") continue;
                    var style = window.getComputedStyle(el);
                    var pos = style.position;
                    var z = parseInt(style.zIndex, 10) || 0;

                    if (pos === "fixed" || pos === "sticky" || (pos === "absolute" && z >= 999)) {
                        var txt = (el.innerText || el.textContent || "").trim();
                        if (looksLikeAdCard(el, txt)) {
                            el.remove();
                            continue;
                        }
                        // Kill invisible transparent full-screen click-hijack overlays above video players
                        if (z >= 9999 && txt.length === 0 && !el.querySelector("video, button, input") &&
                            el.offsetWidth > window.innerWidth * 0.6 && el.offsetHeight > window.innerHeight * 0.4) {
                            var bg = style.backgroundColor;
                            if (bg === "transparent" || bg === "rgba(0, 0, 0, 0)" || parseFloat(style.opacity) < 0.05) {
                                el.remove();
                            }
                        }
                    }
                }
            }

            function sweepFloatingAds() {
                if (!window.__cinemaAdBlockEnabled) return;
                try {
                    sweepContainer(document);
                    // Also sweep any Shadow DOM hosts (where In-Page Push cards hide!)
                    if (window.__cinemaShadowRoots) {
                        for (var s = window.__cinemaShadowRoots.length - 1; s >= 0; s--) {
                            var item = window.__cinemaShadowRoots[s];
                            if (!item || !item.host || !item.root) continue;
                            var stxt = (item.root.textContent || "").trim();
                            if (looksLikeAdCard(item.host, stxt)) {
                                item.host.remove();
                                window.__cinemaShadowRoots.splice(s, 1);
                            } else {
                                sweepContainer(item.root);
                            }
                        }
                    }
                } catch (e) {}
            }

            if (!window.__cinemaAdObserver && document.documentElement) {
                window.__cinemaAdObserver = new MutationObserver(function() {
                    if (window.__cinemaAdBlockEnabled) sweepFloatingAds();
                });
                window.__cinemaAdObserver.observe(document.documentElement, { childList: true, subtree: true });
            }

            if (!window.__cinemaYtAdSkipper) {
                window.__cinemaYtAdSkipper = setInterval(function() {
                    if (!window.__cinemaAdBlockEnabled) return;
                    sweepFloatingAds();
                    var skipBtn = document.querySelector(".ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern");
                    if (skipBtn) skipBtn.click();
                    var adShowing = document.querySelector(".ad-showing video");
                    if (adShowing && isFinite(adShowing.duration) && adShowing.duration > 0) {
                        adShowing.currentTime = adShowing.duration;
                    }
                }, 400);
            }
            sweepFloatingAds();
        })();
        """.trimIndent()
    } else {
        """
        (function() {
            window.__cinemaAdBlockEnabled = false;
            var style = document.getElementById("cinemasub-adblock-css");
            if (style) style.remove();
        })();
        """.trimIndent()
    }
}
