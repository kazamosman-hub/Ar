package com.cinemasub.browser.browser

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.cinemasub.browser.translation.ArabicTranslator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.Charset
import java.util.Collections

data class ExternalCue(
    val startSec: Double,
    val endSec: Double,
    val originalText: String,
    val arabicText: String
)

object ExternalSubtitleParser {

    private val tsRegex = Regex(
        """(\d{1,2}:)?(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(\d{1,2}:)?(\d{2}):(\d{2})[.,](\d{3})"""
    )
    private val sdhRegex = Regex("""\[[^\]]*]|\([^)]*\)|♪[^♪]*♪|♪|♫|<[^>]*>""")

    fun resolveDisplayName(context: Context, uri: Uri): String {
        runCatching {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) {
                    val name = cursor.getString(idx)
                    if (!name.isNullOrBlank()) return name
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "subtitle.srt"
    }

    suspend fun loadAndPrepareJson(
        context: Context,
        uri: Uri,
        translator: ArabicTranslator
    ): Pair<String, Int>? = withContext(Dispatchers.IO) {
        val rawBytes = runCatching {
            context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        }.getOrNull() ?: return@withContext null

        if (rawBytes.isEmpty() || rawBytes.size > 8_000_000) return@withContext null

        val utf8Text = rawBytes.toString(Charsets.UTF_8)
        val rawText = if (utf8Text.count { it == '\uFFFD' } >= 3) {
            runCatching { String(rawBytes, Charset.forName("windows-1256")) }.getOrDefault(utf8Text)
        } else {
            utf8Text
        }

        val parsed = parseCues(rawText)
        if (parsed.isEmpty()) return@withContext null

        val alreadyArabic = isMostlyArabic(parsed.take(40).joinToString(" ") { it.originalText })
        val finalCues = if (alreadyArabic) {
            parsed.map { it.copy(arabicText = it.originalText) }
        } else {
            val texts = parsed.map { it.originalText }
            val batchSize = 24
            val semaphore = Semaphore(5)
            val translatedMap = Collections.synchronizedMap(mutableMapOf<Int, String>())

            coroutineScope {
                texts.chunked(batchSize).mapIndexed { batchIdx, chunk ->
                    async(Dispatchers.IO) {
                        semaphore.withPermit {
                            val offset = batchIdx * batchSize
                            val contextBefore = texts.subList(maxOf(0, offset - 3), offset)
                            var res: Map<Int, String>? = null
                            var attempt = 0
                            while (res == null && attempt < 2) {
                                res = withTimeoutOrNull(15_000L) {
                                    translator.translateBatchForSubtitleFile(chunk, contextBefore)
                                }
                                attempt++
                            }
                            res?.forEach { (localI, ar) -> translatedMap[offset + localI] = ar }
                        }
                    }
                }.awaitAll()
            }

            parsed.mapIndexed { idx, cue ->
                cue.copy(arabicText = translatedMap[idx] ?: cue.originalText)
            }
        }

        val jsonArr = JSONArray()
        for (cue in finalCues) {
            jsonArr.put(
                JSONObject()
                    .put("s", cue.startSec)
                    .put("e", cue.endSec)
                    .put("ar", cue.arabicText)
                    .put("en", if (alreadyArabic) "" else cue.originalText)
            )
        }
        Pair(jsonArr.toString(), finalCues.size)
    }

    private fun parseCues(rawText: String): List<ExternalCue> {
        val normalized = rawText.removePrefix("\uFEFF").replace("\r\n", "\n").replace("\r", "\n")
        val blocks = normalized.split(Regex("\n{2,}"))
        val cues = mutableListOf<ExternalCue>()

        for (block in blocks) {
            val lines = block.lines()
            val tsIdx = lines.indexOfFirst { tsRegex.containsMatchIn(it) }
            if (tsIdx == -1 || tsIdx >= lines.lastIndex) continue

            val match = tsRegex.find(lines[tsIdx]) ?: continue
            val startSec = parseTimestamp(match.groupValues[1], match.groupValues[2], match.groupValues[3], match.groupValues[4])
            val endSec = parseTimestamp(match.groupValues[5], match.groupValues[6], match.groupValues[7], match.groupValues[8])
            if (endSec <= startSec) continue

            val body = lines.subList(tsIdx + 1, lines.size)
                .joinToString(" ")
                .replace(sdhRegex, " ")
                .replace(Regex("\\s+"), " ")
                .trim()

            if (body.isNotEmpty()) {
                cues.add(ExternalCue(startSec, endSec, body, ""))
            }
        }
        return cues.sortedBy { it.startSec }
    }

    private fun parseTimestamp(hGroup: String, mStr: String, sStr: String, msStr: String): Double {
        val h = hGroup.removeSuffix(":").toIntOrNull() ?: 0
        val m = mStr.toIntOrNull() ?: 0
        val s = sStr.toIntOrNull() ?: 0
        val ms = msStr.toIntOrNull() ?: 0
        return h * 3600.0 + m * 60.0 + s + ms / 1000.0
    }

    private fun isMostlyArabic(text: String): Boolean {
        var arabic = 0
        var letters = 0
        for (ch in text) {
            if (ch.isLetter()) {
                letters++
                if (ch in '\u0600'..'\u06FF') arabic++
            }
        }
        return letters > 10 && (arabic * 100 / letters) >= 40
    }
}
