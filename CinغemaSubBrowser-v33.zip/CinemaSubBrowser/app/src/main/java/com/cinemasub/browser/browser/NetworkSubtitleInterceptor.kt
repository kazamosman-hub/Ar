package com.cinemasub.browser.browser

import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import com.cinemasub.browser.translation.ArabicTranslator
import com.cinemasub.browser.translation.TranslationSettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

/**
 * Intercepts subtitle files (.vtt / .srt) requested by the page, translates them to Arabic and
 * hands the translated file back to the player, keeping the original timing untouched.
 */
object NetworkSubtitleInterceptor {

    private const val MAX_DISK_CACHE_FILES = 25
    private const val MAX_SUBTITLE_BYTES = 4_000_000

    /** How long the player's request may wait for a full translation before getting a partial one. */
    private const val WAIT_DEADLINE_MS = 20_000L
    private const val BATCH_SIZE = 24
    private const val BATCH_TIMEOUT_MS = 15_000L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private class DocResult(val text: String, val complete: Boolean)

    /** One running translation per subtitle file, shared by repeated requests. */
    private val inFlight = ConcurrentHashMap<String, Deferred<DocResult>>()

    private val translatedFileCache: MutableMap<String, ByteArray> = Collections.synchronizedMap(
        object : LinkedHashMap<String, ByteArray>(20, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ByteArray>?): Boolean {
                return size > 15
            }
        }
    )

    private val timestampLineRegex = Regex(
        """^\s*\d{1,2}:\d{2}(?::\d{2})?[.,]\d{3}\s*-->\s*\d{1,2}:\d{2}(?::\d{2})?[.,]\d{3}.*$"""
    )

    private val sdhBracketRegex = Regex("""\[[^\]]*]|\([^)]*\)|♪[^♪]*♪|♪|♫""")

    // Query parameters that change on every request (signed URLs) and must not split the cache.
    private val volatileParams = setOf(
        "expires", "expire", "exp", "token", "signature", "sig", "policy", "key-pair-id",
        "hdnts", "hdnea", "x-amz-signature", "x-amz-date", "x-amz-expires", "x-amz-credential",
        "x-amz-security-token", "x-amz-algorithm", "x-amz-signedheaders"
    )

    fun isSubtitleUrl(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val lower = url.lowercase()
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) return false
        val path = runCatching { Uri.parse(lower).path.orEmpty() }.getOrDefault(lower)
        if (path.endsWith(".vtt") || path.endsWith(".srt")) return true
        // Support timedtext endpoints explicitly returning VTT or SRT
        if (lower.contains("timedtext") && (lower.contains("fmt=vtt") || lower.contains("fmt=srt"))) {
            return true
        }
        return false
    }

    fun interceptAndTranslate(
        context: Context,
        request: WebResourceRequest,
        translator: ArabicTranslator
    ): WebResourceResponse? {
        val urlStr = request.url?.toString() ?: return null
        val config = TranslationSettingsStore.currentConfig
        val dual = TranslationSettingsStore.dualSubtitlesEnabled
        val cacheKey = "${config.engine.name}|${config.dialect.name}|$dual|${stableUrlKey(urlStr)}"

        // 1. RAM cache
        translatedFileCache[cacheKey]?.let { return buildCorsResponse(mimeFor(it), it) }

        // 2. Disk cache (instant when returning to a movie)
        readDiskCache(context, cacheKey)?.let { diskBytes ->
            translatedFileCache[cacheKey] = diskBytes
            return buildCorsResponse(mimeFor(diskBytes), diskBytes)
        }

        val originalText = fetchOriginalSubtitle(urlStr, request.requestHeaders) ?: return null
        val originalBytes = originalText.toByteArray(Charsets.UTF_8)
        if (originalText.isBlank() || isMostlyArabic(originalText)) {
            return buildCorsResponse(mimeFor(originalBytes), originalBytes)
        }

        // 3. Translate (one shared job per file). The request waits up to WAIT_DEADLINE_MS; if the
        //    translation is not finished by then the player receives what is ready so far and the
        //    job keeps running in the background, so the next load is complete and instant.
        val job = inFlight[cacheKey] ?: run {
            val created = scope.async(start = CoroutineStart.LAZY) {
                try {
                    val result = translateSubtitleDocument(originalText, translator, dual)
                    if (result.complete) {
                        val bytes = result.text.toByteArray(Charsets.UTF_8)
                        translatedFileCache[cacheKey] = bytes
                        writeDiskCache(context, cacheKey, bytes)
                    }
                    result
                } finally {
                    inFlight.remove(cacheKey)
                }
            }
            val prior = inFlight.putIfAbsent(cacheKey, created)
            if (prior != null) {
                created.cancel()
                prior
            } else {
                created.start()
                created
            }
        }

        val finished: DocResult? = runCatching {
            runBlocking { withTimeoutOrNull(WAIT_DEADLINE_MS) { job.await() } }
        }.getOrNull()

        val finalText = finished?.text ?: buildPartialFromCache(originalText, translator, dual)
        val bytes = finalText.toByteArray(Charsets.UTF_8)
        return buildCorsResponse(mimeFor(bytes), bytes)
    }

    private fun mimeFor(bytes: ByteArray): String {
        val head = String(bytes, 0, minOf(bytes.size, 24), Charsets.UTF_8).trimStart('\uFEFF', ' ', '\n', '\r')
        return if (head.startsWith("WEBVTT")) "text/vtt" else "text/plain"
    }

    private fun stableUrlKey(urlStr: String): String = runCatching {
        val uri = Uri.parse(urlStr)
        val kept = uri.queryParameterNames
            .filter { it.lowercase() !in volatileParams }
            .sorted()
            .joinToString("&") { name -> name + "=" + (uri.getQueryParameter(name) ?: "") }
        (uri.scheme ?: "") + "://" + (uri.host ?: "") + (uri.path ?: "") +
            (if (kept.isEmpty()) "" else "?$kept")
    }.getOrDefault(urlStr)

    private fun cleanSdhText(raw: String): String {
        return raw
            .replace(Regex("<[^>]*>"), "")
            .replace(sdhBracketRegex, " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun readLimited(stream: InputStream, max: Int): ByteArray? {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        stream.use { input ->
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                total += n
                if (total > max) return null
                out.write(buf, 0, n)
            }
        }
        return out.toByteArray()
    }

    private fun fetchOriginalSubtitle(urlStr: String, headers: Map<String, String>?): String? =
        runCatching {
            val originHost = Uri.parse(urlStr).host
            var current = urlStr
            var redirects = 0
            while (redirects <= 3) {
                val sameHost = Uri.parse(current).host == originHost
                val conn = (URL(current).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 5000
                    readTimeout = 7000
                    instanceFollowRedirects = false
                    if (sameHost) {
                        headers?.forEach { (k, v) ->
                            if (!k.equals("Accept-Encoding", ignoreCase = true) &&
                                !k.equals("Range", ignoreCase = true)
                            ) {
                                setRequestProperty(k, v)
                            }
                        }
                        val cookie = runCatching { CookieManager.getInstance().getCookie(current) }.getOrNull()
                        if (!cookie.isNullOrBlank() && headers?.keys?.none { it.equals("Cookie", true) } != false) {
                            setRequestProperty("Cookie", cookie)
                        }
                    } else {
                        // Never forward cookies / auth headers to a different host after a redirect.
                        headers?.get("User-Agent")?.let { setRequestProperty("User-Agent", it) }
                    }
                }
                val code = conn.responseCode
                if (code in 300..399) {
                    val location = conn.getHeaderField("Location")
                    conn.disconnect()
                    if (location.isNullOrBlank()) return@runCatching null
                    current = URL(URL(current), location).toString()
                    if (!current.startsWith("http://") && !current.startsWith("https://")) return@runCatching null
                    redirects++
                    continue
                }
                if (code != HttpURLConnection.HTTP_OK) {
                    conn.disconnect()
                    return@runCatching null
                }
                val bytes = readLimited(conn.inputStream, MAX_SUBTITLE_BYTES)
                conn.disconnect()
                return@runCatching bytes?.let { String(it, Charsets.UTF_8) }
            }
            null
        }.getOrNull()

    private class CueBlock(
        val headerLines: List<String>,
        val textLines: List<String>
    )

    private class ParsedDoc(
        val blocks: List<Any>,      // String (raw header/note) or CueBlock
        val cueIndices: List<Int>,  // positions of translatable cues inside [blocks]
        val cueTexts: List<String>  // cleaned text of each translatable cue
    )

    private fun parseDocument(rawContent: String): ParsedDoc {
        val normalized = rawContent.replace("\r\n", "\n").replace("\r", "\n")
        val rawBlocks = normalized.split(Regex("\n{2,}"))
        val parsedBlocks = mutableListOf<Any>()
        val cueIndices = mutableListOf<Int>()
        val cueTexts = mutableListOf<String>()

        for (block in rawBlocks) {
            val lines = block.lines()
            val tsIdx = lines.indexOfFirst { timestampLineRegex.matches(it) }
            if (tsIdx != -1 && tsIdx < lines.lastIndex) {
                val header = lines.subList(0, tsIdx + 1)
                val bodyLines = lines.subList(tsIdx + 1, lines.size)
                val cleanBody = cleanSdhText(bodyLines.joinToString(" "))
                if (cleanBody.isNotEmpty()) {
                    cueIndices.add(parsedBlocks.size)
                    cueTexts.add(cleanBody)
                    parsedBlocks.add(CueBlock(header, bodyLines))
                }
                // Pure SDH sound-effect cues (like [music playing]) are dropped.
            } else {
                parsedBlocks.add(block)
            }
        }
        return ParsedDoc(parsedBlocks, cueIndices, cueTexts)
    }

    private fun assemble(doc: ParsedDoc, translated: Map<Int, String>, dualSubtitles: Boolean): String {
        val out = StringBuilder()
        var cueCounter = 0
        for (i in doc.blocks.indices) {
            if (i > 0) out.append("\n\n")
            val item = doc.blocks[i]
            if (item is String) {
                out.append(item)
            } else if (item is CueBlock) {
                out.append(item.headerLines.joinToString("\n"))
                out.append("\n")
                val isTranslatedSlot = doc.cueIndices.getOrNull(cueCounter) == i
                if (isTranslatedSlot) {
                    val originalClean = doc.cueTexts[cueCounter]
                    val arabic = translated[cueCounter] ?: originalClean
                    if (dualSubtitles && arabic != originalClean) {
                        out.append(originalClean).append("\n").append(arabic)
                    } else {
                        out.append(arabic)
                    }
                    cueCounter++
                } else {
                    out.append(item.textLines.joinToString("\n"))
                }
            }
        }
        return out.toString()
    }

    /** Partial result: translate nothing new, just use lines the translator already holds. */
    private fun buildPartialFromCache(rawContent: String, translator: ArabicTranslator, dual: Boolean): String {
        val doc = parseDocument(rawContent)
        if (doc.cueTexts.isEmpty()) return rawContent
        val map = HashMap<Int, String>()
        doc.cueTexts.forEachIndexed { i, text ->
            translator.peekCached(text)?.let { map[i] = it }
        }
        return assemble(doc, map, dual)
    }

    private suspend fun translateSubtitleDocument(
        rawContent: String,
        translator: ArabicTranslator,
        dualSubtitles: Boolean
    ): DocResult {
        val doc = parseDocument(rawContent)
        if (doc.cueTexts.isEmpty()) return DocResult(rawContent, true)

        val semaphore = Semaphore(5)
        val translatedMap = Collections.synchronizedMap(mutableMapOf<Int, String>())

        coroutineScope {
            val jobs = doc.cueTexts.chunked(BATCH_SIZE).mapIndexed { batchIdx, chunk ->
                async(Dispatchers.IO) {
                    semaphore.withPermit {
                        val offset = batchIdx * BATCH_SIZE
                        // The three lines before this batch give the model the scene context.
                        val contextBefore = doc.cueTexts.subList(maxOf(0, offset - 3), offset)
                        var res: Map<Int, String>? = null
                        var attempt = 0
                        while (res == null && attempt < 2) {
                            res = withTimeoutOrNull(BATCH_TIMEOUT_MS) {
                                translator.translateBatchForSubtitleFile(chunk, contextBefore)
                            }
                            attempt++
                        }
                        res?.forEach { (localI, ar) -> translatedMap[offset + localI] = ar }
                    }
                }
            }
            jobs.awaitAll()
        }

        // The file is only "complete" (and cached for good) if EVERY cue really got translated.
        val complete = doc.cueTexts.indices.all { translatedMap.containsKey(it) }
        return DocResult(assemble(doc, translatedMap, dualSubtitles), complete)
    }

    private fun cacheFileFor(context: Context, key: String): File {
        val dir = File(context.cacheDir, "translated_subs").apply { mkdirs() }
        val hash = MessageDigest.getInstance("SHA-256")
            .digest(key.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
            .take(24)
        return File(dir, "$hash.sub")
    }

    private fun readDiskCache(context: Context, key: String): ByteArray? = runCatching {
        val file = cacheFileFor(context, key)
        if (file.exists() && file.length() > 0L) {
            file.setLastModified(System.currentTimeMillis())
            file.readBytes()
        } else null
    }.getOrNull()

    private fun writeDiskCache(context: Context, key: String, bytes: ByteArray) {
        runCatching {
            val file = cacheFileFor(context, key)
            file.writeBytes(bytes)
            val dir = file.parentFile ?: return
            val all = dir.listFiles()?.sortedByDescending { it.lastModified() } ?: return
            if (all.size > MAX_DISK_CACHE_FILES) {
                all.drop(MAX_DISK_CACHE_FILES).forEach { it.delete() }
            }
        }
    }

    private fun isMostlyArabic(text: String): Boolean {
        var arabic = 0
        var letters = 0
        val sample = text.take(1500)
        for (ch in sample) {
            if (ch.isLetter()) {
                letters++
                if (ch in '\u0600'..'\u06FF') arabic++
            }
        }
        return letters > 20 && (arabic * 100 / letters) >= 40
    }

    private fun buildCorsResponse(mime: String, bytes: ByteArray): WebResourceResponse {
        val headers = mapOf(
            "Access-Control-Allow-Origin" to "*",
            "Access-Control-Allow-Methods" to "GET, OPTIONS",
            "Access-Control-Allow-Headers" to "*",
            "Cache-Control" to "no-cache"
        )
        return WebResourceResponse(
            mime,
            "UTF-8",
            200,
            "OK",
            headers,
            ByteArrayInputStream(bytes)
        )
    }
}
