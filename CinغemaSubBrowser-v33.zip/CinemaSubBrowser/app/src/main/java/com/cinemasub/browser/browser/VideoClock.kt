package com.cinemasub.browser.browser

import android.os.SystemClock
import kotlin.math.abs

/**
 * Keeps track of the page's <video> position (reported from JavaScript every ~250ms) so that
 * subtitles can be tied to MEDIA time instead of wall-clock time.
 * It survives pause / seek / playback-rate changes.
 */
object VideoClock {
    private const val HISTORY_MS = 90_000L
    private const val STALE_MS = 2_500L

    private class Sample(val wallMs: Long, val mediaSec: Double, val paused: Boolean, val rate: Double)

    private val lock = Any()
    private val history = ArrayDeque<Sample>()

    @Volatile
    var seekGeneration: Int = 0
        private set

    @Volatile
    var durationSec: Double = 0.0
        private set

    fun update(mediaSec: Double, paused: Boolean, rate: Double, durationSec: Double, seeking: Boolean) {
        if (mediaSec.isNaN() || mediaSec.isInfinite() || mediaSec < 0.0) return
        val safeRate = if (rate.isNaN() || rate <= 0.0 || rate > 16.0) 1.0 else rate
        val now = SystemClock.elapsedRealtime()
        synchronized(lock) {
            val last = history.lastOrNull()
            if (last != null) {
                val elapsedSec = (now - last.wallMs) / 1000.0
                val delta = mediaSec - last.mediaSec
                val maxForward = elapsedSec * last.rate + 1.0
                if (seeking || delta < -0.5 || delta > maxForward) {
                    seekGeneration++
                }
            }
            history.addLast(Sample(now, mediaSec, paused, safeRate))
            while (history.size > 2 && now - history.first().wallMs > HISTORY_MS) {
                history.removeFirst()
            }
        }
        if (!durationSec.isNaN() && !durationSec.isInfinite()) {
            this.durationSec = durationSec
        }
    }

    /** True when the page reported its video state recently. */
    fun isActive(): Boolean = synchronized(lock) {
        val last = history.lastOrNull() ?: return@synchronized false
        SystemClock.elapsedRealtime() - last.wallMs <= STALE_MS
    }

    /** Estimated media position right now, or null if the page is not reporting. */
    fun mediaNowSec(): Double? = synchronized(lock) {
        val last = history.lastOrNull() ?: return@synchronized null
        val now = SystemClock.elapsedRealtime()
        if (now - last.wallMs > STALE_MS) return@synchronized null
        predict(last, now)
    }

    /** Media position at a given SystemClock.elapsedRealtime() moment in the recent past. */
    fun mediaAtWall(wallMs: Long): Double? = synchronized(lock) {
        if (history.isEmpty()) return@synchronized null
        var found: Sample? = null
        for (i in history.indices.reversed()) {
            val s = history[i]
            if (s.wallMs <= wallMs) {
                found = s
                break
            }
        }
        val s = found ?: return@synchronized null
        if (abs(wallMs - s.wallMs) > STALE_MS * 2 && s === history.last()) return@synchronized null
        predict(s, wallMs)
    }

    private fun predict(s: Sample, atWallMs: Long): Double {
        if (s.paused) return s.mediaSec
        val elapsed = ((atWallMs - s.wallMs) / 1000.0).coerceIn(0.0, 1.5)
        return s.mediaSec + elapsed * s.rate
    }
}
