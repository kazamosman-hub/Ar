package com.cinemasub.browser.audio

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

object VoskModelManager {

    private const val MODEL_NAME = "vosk-model-small-en-us-0.15"
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/$MODEL_NAME.zip"

    fun getModelDir(context: Context): File = File(context.filesDir, MODEL_NAME)

    fun isModelReady(context: Context): Boolean {
        val dir = getModelDir(context)
        return dir.exists() && dir.isDirectory && File(dir, "am/final.mdl").exists()
    }

    suspend fun ensureModelDownloaded(
        context: Context,
        onProgress: (Int) -> Unit
    ): File = withContext(Dispatchers.IO) {
        val targetDir = getModelDir(context)
        if (isModelReady(context)) return@withContext targetDir

        val zipFile = File(context.cacheDir, "$MODEL_NAME.zip")
        try {
            val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 30_000
                requestMethod = "GET"
            }

            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                throw IllegalStateException("HTTP ${connection.responseCode} downloading Vosk model")
            }

            val totalBytes = connection.contentLengthLong
            var downloadedBytes = 0L

            BufferedInputStream(connection.inputStream).use { input ->
                FileOutputStream(zipFile).use { output ->
                    val buffer = ByteArray(16 * 1024)
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        downloadedBytes += bytesRead
                        if (totalBytes > 0) {
                            onProgress(((downloadedBytes * 100) / totalBytes).toInt().coerceIn(0, 99))
                        }
                    }
                }
            }

            if (targetDir.exists()) targetDir.deleteRecursively()

            val destCanonical = context.filesDir.canonicalPath
            var totalBytes = 0L
            val maxUnzippedBytes = 400L * 1024L * 1024L
            ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val outFile = File(context.filesDir, entry.name)
                    if (!outFile.canonicalPath.startsWith(destCanonical + File.separator)) {
                        throw SecurityException("Invalid zip entry: ${entry.name}")
                    }
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        FileOutputStream(outFile).use { fos ->
                            val chunk = ByteArray(16 * 1024)
                            while (true) {
                                val n = zis.read(chunk)
                                if (n < 0) break
                                totalBytes += n
                                if (totalBytes > maxUnzippedBytes) {
                                    throw SecurityException("Model archive is unexpectedly large")
                                }
                                fos.write(chunk, 0, n)
                            }
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            onProgress(100)
            targetDir
        } finally {
            if (zipFile.exists()) zipFile.delete()
        }
    }
}
