package com.cinemasub.browser.model

import androidx.compose.ui.graphics.Color

enum class SubtitleFontSize(val labelAr: String, val sp: Float) {
    SMALL("صغير", 16f),
    MEDIUM("متوسط", 20f),
    LARGE("كبير", 24f),
    EXTRA_LARGE("كبير جداً", 30f)
}

enum class SubtitleTextColor(val labelAr: String, val color: Color) {
    WHITE("أبيض ناصع", Color(0xFFFFFFFF)),
    NETFLIX_YELLOW("أصفر سينمائي", Color(0xFFF5C518))
}

enum class SubtitleBgOpacity(val labelAr: String, val color: Color) {
    NONE("بدون خلفية", Color.Transparent),
    SEMI_TRANSPARENT("شبه شفاف", Color(0x99000000)),
    SOLID("داكن بالكامل", Color(0xE6000000))
}

enum class SubtitleDialect(val labelAr: String) {
    CINEMA_MSA("فصحى سينمائية"),
    EGYPTIAN_LIGHT("عامية مصرية")
}

enum class DeepgramLanguage(val labelAr: String, val code: String) {
    ENGLISH("إنجليزي (أسرع وأدق)", "en"),
    AUTO_MULTI("تلقائي (كل اللغات)", "multi")
}

enum class TranslationEngine(val labelAr: String) {
    AUTO_HYBRID("الكل معاً (ذكي)"),
    GEMINI_AI("Gemini AI"),
    GROQ_AI("Groq AI"),
    OPENROUTER_AI("OpenRouter (مجاني)"),
    GOOGLE_FREE("جوجل (مجاني)")
}

enum class SubtitleSourceMode {
    NONE,
    WEB_CAPTIONS,
    LIVE_AUDIO
}

data class SubtitleStyleConfig(
    val fontSize: SubtitleFontSize = SubtitleFontSize.MEDIUM,
    val textColor: SubtitleTextColor = SubtitleTextColor.WHITE,
    val bgOpacity: SubtitleBgOpacity = SubtitleBgOpacity.SEMI_TRANSPARENT,
    val verticalBias: Float = 0.84f,
    val syncOffsetSec: Float = 0f,
    val dualSubtitlesEnabled: Boolean = false
)

data class AiTranslationConfig(
    val engine: TranslationEngine = TranslationEngine.AUTO_HYBRID,
    val dialect: SubtitleDialect = SubtitleDialect.CINEMA_MSA,
    val geminiApiKey: String = "",
    val groqApiKey: String = "",
    val openRouterApiKey: String = "",
    val deepgramApiKey: String = "",
    val deepgramLanguage: DeepgramLanguage = DeepgramLanguage.ENGLISH
)

data class Bookmark(
    val title: String,
    val url: String
)

data class QuickLink(
    val title: String,
    val url: String,
    val accentColor: Color
)

sealed interface PipelineStatus {
    data object Idle : PipelineStatus
    data class DownloadingModels(val messageAr: String, val progress: Int? = null) : PipelineStatus
    data object Listening : PipelineStatus
    data class Error(val messageAr: String) : PipelineStatus
}

data class SubtitleState(
    val isLiveEnabled: Boolean = false,
    val sourceMode: SubtitleSourceMode = SubtitleSourceMode.NONE,
    val arabicText: String = "",
    val originalEnglishText: String = "",
    val status: PipelineStatus = PipelineStatus.Idle,
    /** Media time (video.currentTime, seconds) at which the current subtitle should disappear. */
    val hideAtMediaSec: Double? = null
)
