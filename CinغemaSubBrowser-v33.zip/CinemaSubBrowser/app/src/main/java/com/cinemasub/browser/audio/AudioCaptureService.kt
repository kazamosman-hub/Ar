package com.cinemasub.browser.audio

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.cinemasub.browser.MainActivity
import com.cinemasub.browser.browser.VideoClock
import com.cinemasub.browser.model.PipelineStatus
import com.cinemasub.browser.model.SubtitleSourceMode
import com.cinemasub.browser.model.SubtitleState
import com.cinemasub.browser.translation.ArabicTranslator
import com.cinemasub.browser.translation.TranslationSettingsStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.ByteArrayOutputStream
import kotlin.math.sqrt

class AudioCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.cinemasub.browser.action.START_CAPTURE"
        const val ACTION_STOP = "com.cinemasub.browser.action.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private const val CHANNEL_ID = "cinemasub_live_translation"
        private const val NOTIFICATION_ID = 1001
        private const val SAMPLE_RATE = 16000

        private const val MAX_WORDS_PER_CUE = 7
        private const val PAUSE_COMMIT_MS = 280L
        private const val SILENCE_CLEAR_MS = 4500L
        private const val MIN_FINAL_DISPLAY_MS = 1500L

        private val _subtitleState = MutableStateFlow(SubtitleState())
        val subtitleState: StateFlow<SubtitleState> = _subtitleState.asStateFlow()
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var captureJob: Job? = null
    private var translationJob: Job? = null
    private var whisperJob: Job? = null
    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var voskModel: Model? = null
    private var recognizer: Recognizer? = null
    private val translator = ArabicTranslator()
    @Volatile private var lastEnglishSentence: String = ""
    @Volatile private var lastArabicDisplayedMs: Long = 0L
    @Volatile private var lastFinalDisplayedMs: Long = 0L
    @Volatile private var displayedSeekGen: Int = 0

    // Finished English sentences waiting to be translated (processed in order, never cancelled
    // by a newer sentence: every sentence must reach the screen).
    private val pendingTranslationFlow = MutableSharedFlow<TranslationRequest>(
        replay = 0,
        extraBufferCapacity = 8,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    private val pendingWhisperAudioFlow = MutableSharedFlow<WhisperClip>(
        replay = 0,
        extraBufferCapacity = 4,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    override fun onCreate() {
        super.onCreate()
        TranslationSettingsStore.init(applicationContext)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopPipeline()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }

                if (resultCode != Activity.RESULT_OK || resultData == null) {
                    _subtitleState.update {
                        it.copy(
                            isLiveEnabled = false,
                            sourceMode = SubtitleSourceMode.NONE,
                            status = PipelineStatus.Error("تم إلغاء إذن التقاط الصوت")
                        )
                    }
                    stopSelf()
                    return START_NOT_STICKY
                }

                startForegroundCompat()
                startPipeline(resultCode, resultData)
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        createNotificationChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @SuppressLint("MissingPermission")
    private fun startPipeline(resultCode: Int, resultData: Intent) {
        captureJob?.cancel()
        translationJob?.cancel()
        whisperJob?.cancel()

        translationJob = serviceScope.launch(Dispatchers.IO) {
            pendingTranslationFlow.collect { req ->
                // The user jumped in the video: this sentence belongs to a moment that is gone.
                if (req.seekGen != VideoClock.seekGeneration) return@collect
                val prev = lastEnglishSentence
                lastEnglishSentence = req.text
                val arabic = withTimeoutOrNull(2800L) {
                    translator.translateToArabic(req.text, prev)
                }?.takeIf { it.isNotBlank() } ?: translator.translateInterimFast(req.text)
                if (req.seekGen != VideoClock.seekGeneration) return@collect
                if (arabic.isNotBlank()) {
                    showSubtitle(req, arabic)
                }
            }
        }

        captureJob = serviceScope.launch(Dispatchers.IO) {
            try {
                val deepgramKey = TranslationSettingsStore.currentConfig.deepgramApiKey.trim()
                val groqKey = TranslationSettingsStore.currentConfig.groqApiKey.trim()
                val useDeepgram = deepgramKey.isNotBlank()
                val useGroqWhisper = !useDeepgram && groqKey.isNotBlank()

                _subtitleState.update {
                    it.copy(
                        isLiveEnabled = true,
                        sourceMode = SubtitleSourceMode.LIVE_AUDIO,
                        status = PipelineStatus.DownloadingModels(
                            when {
                                useDeepgram -> "جاري الاتصال بالبث اللحظي (Deepgram Nova-2)..."
                                useGroqWhisper -> "جاري تشغيل Whisper السريع..."
                                else -> "جاري تجهيز محرك الصوت المباشر..."
                            }
                        )
                    )
                }

                serviceScope.launch { translator.ensureModelDownloaded() }

                val projectionManager =
                    getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
                    ?: throw IllegalStateException("MediaProjection unavailable")

                mediaProjection?.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() {
                        stopPipeline()
                        stopSelf()
                    }
                }, Handler(Looper.getMainLooper()))

                val captureConfig = AudioPlaybackCaptureConfiguration.Builder(mediaProjection!!)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()

                val audioFormat = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build()

                val minBuffer = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(2048)

                audioRecord = AudioRecord.Builder()
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(minBuffer * 2)
                    .setAudioPlaybackCaptureConfig(captureConfig)
                    .build()

                if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                    throw IllegalStateException("فشل تهيئة مسجل الصوت الداخلي")
                }

                when {
                    useDeepgram -> runDeepgramStreamingLoop(deepgramKey)
                    useGroqWhisper -> runGroqWhisperLoop(groqKey)
                    else -> runVoskOfflineLoop()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _subtitleState.update {
                    it.copy(
                        isLiveEnabled = false,
                        sourceMode = SubtitleSourceMode.NONE,
                        status = PipelineStatus.Error(
                            e.localizedMessage ?: "حدث خطأ أثناء تشغيل الترجمة الفورية"
                        )
                    )
                }
                stopSelf()
            }
        }
    }

    // ---------------------------------------------------------------------------------------
    // Shared helpers: timing + display
    // ---------------------------------------------------------------------------------------

    /** Queue a finished English sentence; [endWallMs] is when the speech ended (elapsedRealtime). */
    private fun queueSentence(text: String, endWallMs: Long?) {
        val endMedia = endWallMs?.let { VideoClock.mediaAtWall(it) }
        pendingTranslationFlow.tryEmit(TranslationRequest(text, endMedia, VideoClock.seekGeneration))
    }

    private fun showSubtitle(req: TranslationRequest, arabic: String) {
        val nowMedia = VideoClock.mediaNowSec()
        var hideAt: Double? = null
        if (nowMedia != null) {
            // Visible until the speech has really ended (+ a small tail) but never shorter than the
            // time needed to read it: the subtitle is tied to VIDEO time, so pause / seek / speed
            // changes keep it correct.
            val readSec = (0.9 + arabic.length * 0.045).coerceIn(1.6, 6.0)
            val byEnd = (req.endMediaSec ?: nowMedia) + 0.45
            hideAt = maxOf(byEnd, nowMedia + readSec)
        }
        displayedSeekGen = req.seekGen
        lastArabicDisplayedMs = System.currentTimeMillis()
        _subtitleState.update {
            it.copy(
                originalEnglishText = req.text,
                arabicText = arabic,
                hideAtMediaSec = hideAt,
                status = PipelineStatus.Listening
            )
        }
    }

    private fun clearSubtitle() {
        _subtitleState.update {
            it.copy(arabicText = "", originalEnglishText = "", hideAtMediaSec = null)
        }
    }

    /**
     * Hides the subtitle based on VIDEO time. Returns true when the video clock handled it, false
     * when the page does not report its position (then the old wall-clock rule is used).
     */
    private fun expireSubtitleByMediaClock(): Boolean {
        val st = _subtitleState.value
        if (st.arabicText.isEmpty()) return false
        if (VideoClock.seekGeneration != displayedSeekGen) {
            clearSubtitle()
            return true
        }
        val hideAt = st.hideAtMediaSec ?: return false
        val nowMedia = VideoClock.mediaNowSec() ?: return false
        if (nowMedia > hideAt) clearSubtitle()
        return true
    }

    // Live streaming via Deepgram Nova-2 WebSocket.
    // Finished segments are merged into whole sentences BEFORE translation (translating half
    // sentences was the main cause of wrong translations) and every subtitle gets video-time
    // timing so it appears and disappears together with the speech.
    private suspend fun runDeepgramStreamingLoop(deepgramKey: String) {
        lastArabicDisplayedMs = System.currentTimeMillis()
        lastFinalDisplayedMs = 0L
        val dgLangCode = TranslationSettingsStore.currentConfig.deepgramLanguage.code
        val wallIndex = AudioWallIndex()
        val sentenceEndRegex = Regex("""[.!?…]["')\]]?$""")

        val bufLock = Any()
        val buf = StringBuilder()
        var bufEndSec = 0.0
        var flushJob: Job? = null

        // Must be called while holding bufLock.
        fun flushBuffer() {
            val text = buf.toString().trim()
            val endSec = bufEndSec
            buf.setLength(0)
            if (text.isEmpty()) return
            queueSentence(text, wallIndex.wallAt(endSec))
        }

        val dgClient = DeepgramStreamingClient(
            apiKey = deepgramKey,
            languageCode = dgLangCode,
            scope = serviceScope,
            onTranscript = { rawText, isFinal, speechFinal, startSec, durationSec ->
                if (isFinal && rawText.isNotBlank()) {
                    synchronized(bufLock) {
                        if (buf.isNotEmpty()) buf.append(' ')
                        buf.append(rawText.trim())
                        if (startSec >= 0.0) bufEndSec = startSec + durationSec
                        flushJob?.cancel()

                        val joined = buf.toString().trim()
                        val wordCount = joined.split(Regex("\\s+")).size
                        val endsSentence = sentenceEndRegex.containsMatchIn(joined)
                        if (endsSentence || wordCount >= 16 || (speechFinal && wordCount >= 4)) {
                            flushBuffer()
                        } else {
                            // Probably mid-sentence: wait a little for the rest before translating.
                            flushJob = serviceScope.launch {
                                delay(750L)
                                synchronized(bufLock) { flushBuffer() }
                            }
                        }
                    }
                }
            },
            onStatusChanged = { connected, errorMsg ->
                if (connected) {
                    _subtitleState.update { it.copy(status = PipelineStatus.Listening) }
                } else if (!errorMsg.isNullOrBlank()) {
                    _subtitleState.update { it.copy(status = PipelineStatus.Error(errorMsg)) }
                }
            },
            onUtteranceEnd = {
                synchronized(bufLock) {
                    flushJob?.cancel()
                    flushBuffer()
                }
            }
        )

        try {
            dgClient.connect()
            audioRecord?.startRecording()
            _subtitleState.update { it.copy(status = PipelineStatus.Listening) }

            val buffer = ByteArray(1920) // ~60ms chunks at 16kHz 16-bit mono
            var lastKeepAliveMs = SystemClock.elapsedRealtime()
            var streamBytes = 0L
            var lastEpoch = dgClient.connectionEpoch
            var readErrors = 0

            while (captureJob?.isActive == true && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                val bytesRead = audioRecord?.read(buffer, 0, buffer.size) ?: -1
                if (bytesRead < 0) {
                    if (++readErrors > 50) throw IllegalStateException("تعذر قراءة صوت الفيديو، أعد تشغيل الترجمة")
                    delay(20L)
                    continue
                }
                if (bytesRead == 0) {
                    delay(5L)
                    continue
                }
                readErrors = 0

                val now = SystemClock.elapsedRealtime()

                // Deepgram's clock restarts at 0 on every new socket: restart our index with it.
                val epoch = dgClient.connectionEpoch
                if (epoch != lastEpoch) {
                    lastEpoch = epoch
                    streamBytes = 0L
                    wallIndex.clear()
                }
                if (dgClient.sendPcmAudio(buffer, bytesRead)) {
                    streamBytes += bytesRead
                    // 16 kHz * 2 bytes = 32000 bytes per second of stream time
                    wallIndex.record(streamBytes / 32000.0, now)
                }

                if (now - lastKeepAliveMs >= 8000L) {
                    dgClient.sendKeepAlive()
                    lastKeepAliveMs = now
                }

                if (!expireSubtitleByMediaClock() &&
                    lastArabicDisplayedMs > 0L &&
                    System.currentTimeMillis() - lastArabicDisplayedMs > SILENCE_CLEAR_MS &&
                    _subtitleState.value.arabicText.isNotEmpty()
                ) {
                    clearSubtitle()
                }
            }
        } finally {
            synchronized(bufLock) { flushJob?.cancel() }
            dgClient.close()
        }
    }

    // Live capture using Groq Whisper: speech is cut at natural pauses, transcribed, then handed to
    // the same ordered translation queue as the Deepgram path.
    private suspend fun runGroqWhisperLoop(groqKey: String) {
        val langCode = TranslationSettingsStore.currentConfig.deepgramLanguage.code
        whisperJob = serviceScope.launch(Dispatchers.IO) {
            pendingWhisperAudioFlow.collect { clip ->
                val titleHint = TranslationSettingsStore.currentPageTitle
                    .replace(Regex("[\\r\\n\"']+"), " ")
                    .trim()
                    .take(120)
                val rawEnglish = translator.transcribeAudioViaGroqWhisper(
                    pcm16Mono16k = clip.pcm,
                    apiKey = groqKey,
                    languageCode = langCode,
                    promptHint = titleHint
                )
                if (!rawEnglish.isNullOrBlank()) {
                    val english = deduplicateOverlap(lastEnglishSentence, rawEnglish)
                    if (english.isNotBlank()) {
                        queueSentence(english, clip.endWallMs)
                    }
                }
            }
        }

        audioRecord?.startRecording()
        _subtitleState.update { it.copy(status = PipelineStatus.Listening) }

        val buffer = ByteArray(2048)
        val speechBuffer = ByteArrayOutputStream()
        val overlapBytesSize = 8000 // 250ms at 16kHz, 16-bit mono
        var lastTailOverlap = ByteArray(0)
        var speechStartedMs = 0L
        var lastVoiceMs = SystemClock.elapsedRealtime()
        val rmsThreshold = 300.0
        var readErrors = 0

        while (captureJob?.isActive == true && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
            val bytesRead = audioRecord?.read(buffer, 0, buffer.size) ?: -1
            if (bytesRead < 0) {
                if (++readErrors > 50) throw IllegalStateException("تعذر قراءة صوت الفيديو، أعد تشغيل الترجمة")
                delay(20L)
                continue
            }
            if (bytesRead == 0) {
                delay(5L)
                continue
            }
            readErrors = 0

            val now = SystemClock.elapsedRealtime()
            val rms = computeRms(buffer, bytesRead)

            if (rms >= rmsThreshold) {
                if (speechBuffer.size() == 0) {
                    speechStartedMs = now
                    if (lastTailOverlap.isNotEmpty()) {
                        speechBuffer.write(lastTailOverlap)
                    }
                }
                speechBuffer.write(buffer, 0, bytesRead)
                lastVoiceMs = now
            } else if (speechBuffer.size() > 0) {
                speechBuffer.write(buffer, 0, bytesRead)
            }

            val speechDurationMs = if (speechBuffer.size() > 0) now - speechStartedMs else 0L
            val silenceAfterVoiceMs = now - lastVoiceMs

            // Cut at a real pause when possible; hard limit so a long monologue still flows.
            val shouldFlush =
                (speechBuffer.size() > 0 && speechDurationMs >= 900L && silenceAfterVoiceMs >= 300L) ||
                    (speechBuffer.size() > 0 && speechDurationMs >= 3200L)

            if (shouldFlush) {
                val clip = speechBuffer.toByteArray()
                // Keep last 250ms only if the speaker is still talking (prevents chopped words)
                lastTailOverlap = if (silenceAfterVoiceMs < 180L && clip.size > overlapBytesSize) {
                    clip.copyOfRange(clip.size - overlapBytesSize, clip.size)
                } else {
                    ByteArray(0)
                }
                speechBuffer.reset()
                pendingWhisperAudioFlow.tryEmit(WhisperClip(clip, speechStartedMs, now - silenceAfterVoiceMs))
            } else if (speechBuffer.size() == 0) {
                if (!expireSubtitleByMediaClock() &&
                    System.currentTimeMillis() - lastArabicDisplayedMs > SILENCE_CLEAR_MS &&
                    _subtitleState.value.arabicText.isNotEmpty()
                ) {
                    lastTailOverlap = ByteArray(0)
                    clearSubtitle()
                }
            }
        }
    }

    // Removes repeated words at the boundary caused by the 250ms rolling audio overlap
    private fun deduplicateOverlap(previous: String, current: String): String {
        val prevWords = previous.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val currWords = current.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (prevWords.isEmpty() || currWords.isEmpty()) return current.trim()

        fun norm(w: String): String = w.lowercase().replace(Regex("[^\\p{L}\\p{N}]"), "")

        val maxOverlap = minOf(4, prevWords.size, currWords.size)
        for (len in maxOverlap downTo 1) {
            var allMatch = true
            for (i in 0 until len) {
                val a = norm(prevWords[prevWords.size - len + i])
                val b = norm(currWords[i])
                if (a.isEmpty() || a != b) {
                    allMatch = false
                    break
                }
            }
            if (allMatch) {
                return currWords.drop(len).joinToString(" ").trim()
            }
        }
        return current.trim()
    }

    private fun computeRms(pcm16: ByteArray, length: Int): Double {
        var sumSq = 0.0
        val samples = length / 2
        if (samples <= 0) return 0.0
        for (i in 0 until samples) {
            val lo = pcm16[i * 2].toInt() and 0xFF
            val hi = pcm16[i * 2 + 1].toInt()
            val sample = (hi shl 8) or lo
            sumSq += sample * sample.toDouble()
        }
        return sqrt(sumSq / samples)
    }

    private suspend fun runVoskOfflineLoop() {
        val modelDir = VoskModelManager.ensureModelDownloaded(applicationContext) { progress ->
            _subtitleState.update {
                it.copy(
                    status = PipelineStatus.DownloadingModels(
                        "جاري تحميل نموذج التعرف على الصوت ($progress%)...",
                        progress
                    )
                )
            }
        }

        voskModel?.close()
        voskModel = Model(modelDir.absolutePath)
        recognizer?.close()
        recognizer = Recognizer(voskModel, SAMPLE_RATE.toFloat())

        audioRecord?.startRecording()
        _subtitleState.update { it.copy(status = PipelineStatus.Listening) }

        val buffer = ByteArray(2048)
        var consumedWordsCount = 0
        var lastSeenPartial = ""
        var lastPartialChangeMs = System.currentTimeMillis()
        var lastEmittedSentence = ""
        var lastSubtitleShownMs = System.currentTimeMillis()

        while (captureJob?.isActive == true && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
            val bytesRead = audioRecord?.read(buffer, 0, buffer.size) ?: -1
            if (bytesRead <= 0) {
                delay(10L)
                continue
            }

            val rec = recognizer ?: break
            val isFinal = rec.acceptWaveForm(buffer, bytesRead)
            val now = System.currentTimeMillis()

            if (isFinal) {
                val finalEnglish = parseJsonField(rec.result, "text")
                val words = finalEnglish.split(Regex("\\s+")).filter { it.isNotBlank() }
                val remaining = if (consumedWordsCount < words.size) words.drop(consumedWordsCount) else emptyList()
                consumedWordsCount = 0
                lastSeenPartial = ""

                if (remaining.isNotEmpty()) {
                    val sentence = remaining.takeLast(MAX_WORDS_PER_CUE + 3).joinToString(" ")
                    if (sentence != lastEmittedSentence) {
                        lastEmittedSentence = sentence
                        lastSubtitleShownMs = now
                        queueSentence(sentence, null)
                    }
                }
            } else {
                val partialEnglish = parseJsonField(rec.partialResult, "partial")

                if (partialEnglish.isBlank()) {
                    if (now - lastSubtitleShownMs > SILENCE_CLEAR_MS &&
                        _subtitleState.value.arabicText.isNotEmpty()
                    ) {
                        _subtitleState.update { it.copy(arabicText = "", originalEnglishText = "") }
                    }
                    continue
                }

                if (partialEnglish != lastSeenPartial) {
                    lastSeenPartial = partialEnglish
                    lastPartialChangeMs = now
                }

                val words = partialEnglish.split(Regex("\\s+")).filter { it.isNotBlank() }
                if (words.size < consumedWordsCount) consumedWordsCount = 0
                val remaining = words.drop(consumedWordsCount)

                if (remaining.size >= MAX_WORDS_PER_CUE) {
                    val cueWords = remaining.take(MAX_WORDS_PER_CUE)
                    val sentence = cueWords.joinToString(" ")
                    consumedWordsCount += cueWords.size
                    lastEmittedSentence = sentence
                    lastSubtitleShownMs = now
                    queueSentence(sentence, null)
                } else if (remaining.size >= 3 && (now - lastPartialChangeMs) >= PAUSE_COMMIT_MS) {
                    val sentence = remaining.joinToString(" ")
                    if (sentence != lastEmittedSentence) {
                        consumedWordsCount += remaining.size
                        lastEmittedSentence = sentence
                        lastSubtitleShownMs = now
                        queueSentence(sentence, null)
                    }
                }
            }
        }
    }

    private fun parseJsonField(json: String?, key: String): String {
        if (json.isNullOrBlank()) return ""
        return runCatching { JSONObject(json).optString(key, "").trim() }.getOrDefault("")
    }

    private fun stopPipeline() {
        captureJob?.cancel()
        captureJob = null
        translationJob?.cancel()
        translationJob = null
        whisperJob?.cancel()
        whisperJob = null

        runCatching {
            audioRecord?.stop()
            audioRecord?.release()
        }
        audioRecord = null

        runCatching { mediaProjection?.stop() }
        mediaProjection = null

        runCatching { recognizer?.close() }
        recognizer = null

        runCatching { voskModel?.close() }
        voskModel = null

        _subtitleState.update {
            SubtitleState(
                isLiveEnabled = false,
                sourceMode = SubtitleSourceMode.NONE,
                arabicText = "",
                status = PipelineStatus.Idle
            )
        }
    }

    override fun onDestroy() {
        stopPipeline()
        translator.close()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "الترجمة الفورية للفيديو",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "يعمل في الخلفية لالتقاط صوت الفيديو وترجمته إلى العربية"
        }
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, AudioCaptureService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("CinemaSub - الترجمة الفورية نشطة")
            .setContentText("يتم الآن ترجمة صوت الفيديو إلى العربية")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف", stopIntent)
            .build()
    }
}

/** A finished English sentence waiting for translation. */
internal class TranslationRequest(
    val text: String,
    /** Media time (video seconds) at which the speech ended, if the page reports its position. */
    val endMediaSec: Double?,
    val seekGen: Int
)

/** A chunk of captured speech sent to Whisper (times are SystemClock.elapsedRealtime()). */
internal class WhisperClip(
    val pcm: ByteArray,
    val startWallMs: Long,
    val endWallMs: Long
)

/**
 * Maps "seconds of audio already sent to Deepgram" -> "wall-clock moment it was captured", so
 * Deepgram's own start/duration fields can be converted to video time. Based on counted bytes, so
 * it stays exact even if the capture stream stalls during a pause.
 */
internal class AudioWallIndex {
    private val lock = Any()
    private val streamSecs = ArrayList<Double>()
    private val wallMs = ArrayList<Long>()

    fun clear() {
        synchronized(lock) {
            streamSecs.clear()
            wallMs.clear()
        }
    }

    fun record(streamSecEnd: Double, wall: Long) {
        synchronized(lock) {
            streamSecs.add(streamSecEnd)
            wallMs.add(wall)
            if (streamSecs.size > 1500) {
                for (k in 0 until 500) {
                    streamSecs.removeAt(0)
                    wallMs.removeAt(0)
                }
            }
        }
    }

    fun wallAt(streamSec: Double): Long? {
        synchronized(lock) {
            if (streamSec < 0.0 || streamSecs.isEmpty()) return null
            var i = streamSecs.size - 1
            if (streamSec > streamSecs[i]) {
                return wallMs[i] + ((streamSec - streamSecs[i]) * 1000.0).toLong()
            }
            while (i > 0 && streamSecs[i - 1] >= streamSec) i--
            return wallMs[i] - ((streamSecs[i] - streamSec) * 1000.0).toLong()
        }
    }
}
