package com.floatsub.app.translation

import com.floatsub.app.model.AiTranslationConfig
import com.floatsub.app.model.TranslationEngine
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.ConnectionPool
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.URLEncoder
import java.util.Collections
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class ArabicTranslator {

    private val options = TranslatorOptions.Builder()
        .setSourceLanguage(TranslateLanguage.ENGLISH)
        .setTargetLanguage(TranslateLanguage.ARABIC)
        .build()

    private val mlKitTranslator: Translator = Translation.getClient(options)
    private val isOfflineReady = AtomicBoolean(false)

    // Unified HTTP/2 pooled client: eliminates TLS handshake lag on every subtitle!
    private val httpClient = OkHttpClient.Builder()
        .connectionPool(ConnectionPool(10, 5, TimeUnit.MINUTES))
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .writeTimeout(4, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val fastGoogleClient = httpClient.newBuilder()
        .connectTimeout(1500, TimeUnit.MILLISECONDS)
        .readTimeout(1800, TimeUnit.MILLISECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val wavMediaType = "audio/wav".toMediaType()
    private val browserUserAgent =
        "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    @Volatile private var cachedGeminiModel: String? = null
    @Volatile private var cachedGroqModel: String? = null
    @Volatile private var cachedSambaNovaModel: String? = null

    @Volatile private var groqCooldownUntil: Long = 0L
    @Volatile private var geminiCooldownUntil: Long = 0L
    @Volatile private var sambaNovaCooldownUntil: Long = 0L
    private val cooldownMs = 60_000L

    private val roundRobinCounter = AtomicInteger(0)

    // 3-line rolling scene memory so pronouns & character names stay consistent
    private val sceneHistory = Collections.synchronizedList(mutableListOf<Pair<String, String>>())

    private val cache: MutableMap<String, String> = Collections.synchronizedMap(
        object : LinkedHashMap<String, String>(900, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
                return size > 850
            }
        }
    )

    fun resetCooldowns() {
        groqCooldownUntil = 0L
        geminiCooldownUntil = 0L
        sambaNovaCooldownUntil = 0L
    }

    private fun recordSceneLine(en: String, ar: String) {
        if (en.length < 3 || ar.length < 2) return
        synchronized(sceneHistory) {
            sceneHistory.add(Pair(en.take(120), ar.take(120)))
            while (sceneHistory.size > 3) {
                sceneHistory.removeAt(0)
            }
        }
    }

    private fun buildSceneContextHeader(previousContext: String): String {
        val lines = synchronized(sceneHistory) { sceneHistory.toList() }
        if (lines.isNotEmpty()) {
            val sb = StringBuilder("Recent dialogue (context only):\n")
            for ((en, ar) in lines) {
                sb.append("- ").append(en).append(" => ").append(ar).append("\n")
            }
            return sb.toString()
        }
        return if (previousContext.isNotBlank()) {
            "Previous line (context only): \"${previousContext.take(120)}\"\n"
        } else ""
    }

    private fun systemPromptFor(isBatch: Boolean): String {
        val styleDesc = "professional Netflix/MBC2 Arabic movie subtitle translator using natural, concise Modern Standard Arabic"
        val pageTitle = TranslationSettingsStore.currentPageTitle
            .replace(Regex("[\\r\\n\"']+"), " ")
            .trim()
            .take(80)
        val titleContext = if (pageTitle.length >= 3) {
            " Video/Movie title: \"$pageTitle\" (keep character names accurate)."
        } else ""

        return if (isBatch) {
            "You are a $styleDesc.$titleContext " +
                "Translate all numbered dialogue lines together as one coherent movie scene, keeping consistent gender, pronouns, and flow. " +
                "Translate idioms and slang by meaning, not literally. " +
                "Return ONLY the translated Arabic lines keeping the EXACT same numbering format '1|translation', '2|translation', etc. " +
                "No markdown, no asterisks, no quotes, no extra commentary."
        } else {
            "You are a $styleDesc.$titleContext " +
                "Translate ONLY the current dialogue line into natural, idiomatic, concise Arabic suitable for cinema subtitles. " +
                "Silently fix any obvious speech-to-text mishearings using context. " +
                "Translate idioms and slang by meaning, not literally. " +
                "Output ONLY the Arabic translation text (no markdown, no asterisks, no quotes, no notes)."
        }
    }

    suspend fun ensureModelDownloaded() {
        if (isOfflineReady.get()) return
        runCatching {
            val conditions = DownloadConditions.Builder().build()
            mlKitTranslator.downloadModelIfNeeded(conditions).await()
            isOfflineReady.set(true)
        }
    }

    // Ultra-fast translation (~90-220ms) for in-progress live speech (Deepgram interim results)
    suspend fun translateInterimFast(sourceText: String): String {
        val cleaned = sourceText.trim()
        if (cleaned.isEmpty()) return ""
        if (isAlreadyArabic(cleaned)) return formatCinemaSubtitle(cleaned)

        val config = TranslationSettingsStore.currentConfig
        val key = cacheKeyFor(config, cleaned)
        cache[key]?.let { return it }

        // 1. Try Groq ultra-fast LLM (~200ms) if healthy and configured
        val groqKey = config.groqApiKey.trim()
        if (groqKey.isNotEmpty() &&
            config.engine != TranslationEngine.GOOGLE_FREE &&
            System.currentTimeMillis() >= groqCooldownUntil
        ) {
            val sysPrompt = systemPromptFor(isBatch = false)
            val groqFast = withTimeoutOrNull(650L) {
                callGroqFast(sysPrompt, cleaned, groqKey, maxTokens = 85)
            }?.let { formatCinemaSubtitle(it) }
            if (!groqFast.isNullOrBlank()) return groqFast
        }

        // 2. Pooled HTTP/2 Google Free (~90-140ms) so live captions stay glued to speech
        return translateViaGoogleFree(cleaned)?.let { formatCinemaSubtitle(it) }.orEmpty()
    }

    // Full cinema-grade translation with 3-line scene memory
    suspend fun translateToArabic(sourceText: String, previousContext: String = ""): String {
        val cleaned = sourceText.trim()
        if (cleaned.isEmpty()) return ""
        if (isAlreadyArabic(cleaned)) return formatCinemaSubtitle(cleaned)

        val config = TranslationSettingsStore.currentConfig
        val key = cacheKeyFor(config, cleaned)
        cache[key]?.let { return it }

        val ctxHeader = buildSceneContextHeader(previousContext)
        val userPrompt = if (ctxHeader.isNotEmpty()) {
            "${ctxHeader}Translate ONLY this current line:\n$cleaned"
        } else {
            cleaned
        }

        val sysPrompt = systemPromptFor(isBatch = false)
        val rawAi = callActiveAiRaw(sysPrompt, userPrompt, config, maxTokens = 140)
        val aiResult = rawAi?.let { formatCinemaSubtitle(it) }

        if (!aiResult.isNullOrBlank()) {
            cache[key] = aiResult
            recordSceneLine(cleaned, aiResult)
            return aiResult
        }

        val onlineResult = translateViaGoogleFree(cleaned)?.let { formatCinemaSubtitle(it) }
        if (!onlineResult.isNullOrBlank()) {
            cache[key] = onlineResult
            recordSceneLine(cleaned, onlineResult)
            return onlineResult
        }

        if (!isOfflineReady.get()) ensureModelDownloaded()
        val offline = runCatching {
            mlKitTranslator.translate(cleaned).await()
        }.getOrDefault(cleaned).let { formatCinemaSubtitle(it) }
        cache[key] = offline
        return offline
    }

    // Preload batch of web captions into cache
    suspend fun preloadBatchToCache(lines: List<String>, previousContext: List<String> = emptyList()) {
        val config = TranslationSettingsStore.currentConfig
        val pending = lines.map { it.trim() }
            .filter { it.isNotEmpty() && !isAlreadyArabic(it) && !cache.containsKey(cacheKeyFor(config, it)) }
            .distinct()
        if (pending.isEmpty()) return

        if (config.engine == TranslationEngine.GOOGLE_FREE) {
            for (line in pending) {
                translateViaGoogleFree(line)?.let {
                    cache[cacheKeyFor(config, line)] = formatCinemaSubtitle(it)
                }
            }
            return
        }

        val sb = StringBuilder("Translate these numbered movie subtitle lines:\n")
        pending.forEachIndexed { idx, line -> sb.append("${idx + 1}|$line\n") }
        val sysPrompt = systemPromptFor(isBatch = true)
        val raw = callActiveAiRaw(sysPrompt, sb.toString(), config, maxTokens = (pending.size * 55).coerceIn(220, 1200))
        if (raw != null) {
            val parsed = parseNumberedBatch(raw, pending.size)
            for ((idx, ar) in parsed) {
                if (idx in pending.indices && ar.isNotBlank()) {
                    cache[cacheKeyFor(config, pending[idx])] = formatCinemaSubtitle(ar)
                }
            }
        }
    }

    // Batch translate subtitle file cues (for NetworkSubtitleInterceptor & ExternalSubtitleParser)
    suspend fun translateBatchForSubtitleFile(cues: List<String>): Map<Int, String> {
        if (cues.isEmpty()) return emptyMap()
        val config = TranslationSettingsStore.currentConfig
        val result = mutableMapOf<Int, String>()
        val toTranslateIdx = mutableListOf<Int>()
        val toTranslateText = mutableListOf<String>()

        cues.forEachIndexed { idx, raw ->
            val cleaned = raw.trim()
            if (cleaned.isEmpty() || isAlreadyArabic(cleaned)) {
                result[idx] = cleaned
            } else {
                val cached = cache[cacheKeyFor(config, cleaned)]
                if (cached != null) {
                    result[idx] = cached
                } else {
                    toTranslateIdx.add(idx)
                    toTranslateText.add(cleaned)
                }
            }
        }

        if (toTranslateText.isEmpty()) return result

        if (config.engine == TranslationEngine.GOOGLE_FREE) {
            toTranslateText.forEachIndexed { i, line ->
                val trLine = translateViaGoogleFree(line)?.let { formatCinemaSubtitle(it) } ?: line
                val origIdx = toTranslateIdx[i]
                result[origIdx] = trLine
                cache[cacheKeyFor(config, line)] = trLine
            }
            return result
        }

        val sb = StringBuilder("Translate these numbered movie subtitle lines:\n")
        toTranslateText.forEachIndexed { i, line ->
            sb.append("${i + 1}|${line.replace("\n", " ")}\n")
        }

        val sysPrompt = systemPromptFor(isBatch = true)
        val rawBatch = callActiveAiRaw(
            sysPrompt = sysPrompt,
            userPrompt = sb.toString(),
            config = config,
            maxTokens = (toTranslateText.size * 55).coerceIn(220, 1400)
        )

        if (rawBatch != null) {
            val parsed = parseNumberedBatch(rawBatch, toTranslateText.size)
            for ((localIdx, arabic) in parsed) {
                if (localIdx in toTranslateIdx.indices && arabic.isNotBlank()) {
                    val origIdx = toTranslateIdx[localIdx]
                    val formatted = formatCinemaSubtitle(arabic)
                    result[origIdx] = formatted
                    cache[cacheKeyFor(config, toTranslateText[localIdx])] = formatted
                }
            }
        }

        for (i in toTranslateIdx.indices) {
            val origIdx = toTranslateIdx[i]
            if (!result.containsKey(origIdx)) {
                val fallback = translateViaGoogleFree(toTranslateText[i])?.let { formatCinemaSubtitle(it) }
                    ?: toTranslateText[i]
                result[origIdx] = fallback
            }
        }
        return result
    }

    // Groq Whisper fallback transcription (when Deepgram key is not configured)
    suspend fun transcribeAudioViaGroqWhisper(pcm16Mono16k: ByteArray, apiKey: String): String? =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank() || pcm16Mono16k.size < 3200) return@withContext null
            if (System.currentTimeMillis() < groqCooldownUntil) return@withContext null
            runCatching {
                val wavBytes = pcmToWav(pcm16Mono16k, 16000, 1, 16)
                val body = MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("model", "whisper-large-v3-turbo")
                    .addFormDataPart("response_format", "json")
                    .addFormDataPart("temperature", "0")
                    .addFormDataPart("file", "clip.wav", wavBytes.toRequestBody(wavMediaType))
                    .build()

                val req = Request.Builder()
                    .url("https://api.groq.com/openai/v1/audio/transcriptions")
                    .header("Authorization", "Bearer ${apiKey.trim()}")
                    .header("User-Agent", browserUserAgent)
                    .post(body)
                    .build()

                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        if (resp.code == 403 || resp.code == 401 || resp.code == 429) {
                            groqCooldownUntil = System.currentTimeMillis() + cooldownMs
                        }
                        return@runCatching null
                    }
                    val text = JSONObject(resp.body?.string().orEmpty()).optString("text", "").trim()
                    val lower = text.lowercase()
                    if (text.length < 2 ||
                        lower == "null" ||
                        lower == "thank you." ||
                        lower == "thanks for watching." ||
                        lower == "you" ||
                        lower.startsWith("subtitles by") ||
                        isRepetitiveHallucination(text)
                    ) null else text
                }
            }.getOrNull()
        }

    // Unified key tester (tests selected engine or all configured engines in AUTO_HYBRID)
    suspend fun testAllConfiguredKeys(config: AiTranslationConfig): Pair<Boolean, String> =
        withContext(Dispatchers.IO) {
            resetCooldowns()
            when (config.engine) {
                TranslationEngine.GEMINI_AI -> testGeminiKey(config.geminiApiKey.trim())
                TranslationEngine.GROQ_AI -> testGroqKey(config.groqApiKey.trim())
                TranslationEngine.SAMBANOVA_AI -> testSambaNovaKey(config.sambaNovaApiKey.trim())
                TranslationEngine.GOOGLE_FREE -> {
                    val res = translateViaGoogleFree("Don't worry, I've got your back.")
                    if (!res.isNullOrBlank()) Pair(true, "✅ جوجل المجاني شغال: «$res»")
                    else Pair(false, "❌ فشل الاتصال بجوجل، تأكد من الإنترنت.")
                }
                TranslationEngine.AUTO_HYBRID -> {
                    val lines = mutableListOf<String>()
                    var anyOk = false
                    if (config.groqApiKey.isNotBlank()) {
                        val (ok, msg) = testGroqKey(config.groqApiKey.trim())
                        if (ok) anyOk = true
                        lines.add("Groq: $msg")
                    }
                    if (config.geminiApiKey.isNotBlank()) {
                        val (ok, msg) = testGeminiKey(config.geminiApiKey.trim())
                        if (ok) anyOk = true
                        lines.add("Gemini: $msg")
                    }
                    if (config.sambaNovaApiKey.isNotBlank()) {
                        val (ok, msg) = testSambaNovaKey(config.sambaNovaApiKey.trim())
                        if (ok) anyOk = true
                        lines.add("SambaNova: $msg")
                    }
                    if (lines.isEmpty()) {
                        Pair(false, "أدخل مفتاح واحد على الأقل (Gemini أو Groq أو SambaNova).")
                    } else {
                        Pair(anyOk, lines.joinToString("\n"))
                    }
                }
            }
        }

    private fun testGroqKey(apiKey: String): Pair<Boolean, String> {
        if (apiKey.isEmpty()) return Pair(false, "أدخل مفتاح Groq أولاً.")
        cachedGroqModel = null
        val sys = systemPromptFor(isBatch = false)
        val candidates = discoverGroqModels(apiKey)
        var lastError = "فشل الاتصال بسيرفر Groq"

        for (model in candidates) {
            val req = Request.Builder()
                .url("https://api.groq.com/openai/v1/chat/completions")
                .header("Authorization", "Bearer $apiKey")
                .header("User-Agent", browserUserAgent)
                .header("Accept", "application/json")
                .post(buildOpenAiPayload(model, sys, "Don't worry, I've got your back.", 60).toString().toRequestBody(jsonMediaType))
                .build()

            val res = runCatching {
                httpClient.newCall(req).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        val text = extractOpenAiRawText(body)
                        if (text.isNotBlank()) {
                            cachedGroqModel = model
                            return Pair(true, "✅ شغال ($model): «${formatCinemaSubtitle(text)}»")
                        }
                    }
                    val errMsg = parseApiErrorMessage(body)
                    if (resp.code == 403) {
                        return Pair(false, "❌ خطأ (403): الشبكة أو الـ VPN محظور من Groq.")
                    }
                    lastError = "❌ خطأ (${resp.code}): ${errMsg.ifBlank { "مشكلة في المفتاح" }}"
                }
            }
            res.exceptionOrNull()?.let { lastError = "❌ خطأ شبكة: ${it.localizedMessage}" }
        }
        return Pair(false, lastError)
    }

    private fun testGeminiKey(apiKey: String): Pair<Boolean, String> {
        if (apiKey.isEmpty()) return Pair(false, "أدخل مفتاح Gemini أولاً.")
        cachedGeminiModel = null
        val sys = systemPromptFor(isBatch = false)
        val models = discoverGeminiModels(apiKey).take(5)
        var lastError = "فشل الاتصال بسيرفر Gemini"

        for (model in models) {
            val payload = buildGeminiPayload(sys, "Don't worry, I've got your back.", 60)
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
                .header("User-Agent", browserUserAgent)
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            runCatching {
                httpClient.newCall(req).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        val text = extractGeminiRawText(body)
                        if (text.isNotBlank()) {
                            cachedGeminiModel = model
                            return Pair(true, "✅ شغال ($model): «${formatCinemaSubtitle(text)}»")
                        }
                    }
                    val errMsg = parseApiErrorMessage(body)
                    lastError = "❌ خطأ (${resp.code}): ${errMsg.ifBlank { "الموديل غير متاح" }}"
                }
            }.onFailure { lastError = "❌ خطأ شبكة: ${it.localizedMessage}" }
        }
        return Pair(false, lastError)
    }

    private fun testSambaNovaKey(apiKey: String): Pair<Boolean, String> {
        if (apiKey.isEmpty()) return Pair(false, "أدخل مفتاح SambaNova أولاً.")
        cachedSambaNovaModel = null
        val sys = systemPromptFor(isBatch = false)
        val models = discoverSambaNovaModels(apiKey).take(5)
        var lastError = "فشل الاتصال بسيرفر SambaNova"

        for (model in models) {
            val req = Request.Builder()
                .url("https://api.sambanova.ai/v1/chat/completions")
                .header("Authorization", "Bearer $apiKey")
                .header("User-Agent", browserUserAgent)
                .post(buildOpenAiPayload(model, sys, "Don't worry, I've got your back.", 60).toString().toRequestBody(jsonMediaType))
                .build()

            runCatching {
                httpClient.newCall(req).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        val text = extractOpenAiRawText(body)
                        if (text.isNotBlank()) {
                            cachedSambaNovaModel = model
                            return Pair(true, "✅ شغال ($model): «${formatCinemaSubtitle(text)}»")
                        }
                    }
                    val errMsg = parseApiErrorMessage(body)
                    lastError = "❌ خطأ (${resp.code}): ${errMsg.ifBlank { "الموديل غير متاح" }}"
                }
            }.onFailure { lastError = "❌ خطأ شبكة: ${it.localizedMessage}" }
        }
        return Pair(false, lastError)
    }

    private suspend fun callActiveAiRaw(
        sysPrompt: String,
        userPrompt: String,
        config: AiTranslationConfig,
        maxTokens: Int
    ): String? = when (config.engine) {
        TranslationEngine.AUTO_HYBRID -> callAutoHybridRaw(sysPrompt, userPrompt, config, maxTokens)
        TranslationEngine.GEMINI_AI ->
            if (config.geminiApiKey.isNotBlank()) callGeminiFast(sysPrompt, userPrompt, config.geminiApiKey.trim(), maxTokens) else null
        TranslationEngine.GROQ_AI ->
            if (config.groqApiKey.isNotBlank()) callGroqFast(sysPrompt, userPrompt, config.groqApiKey.trim(), maxTokens) else null
        TranslationEngine.SAMBANOVA_AI ->
            if (config.sambaNovaApiKey.isNotBlank()) callSambaNovaFast(sysPrompt, userPrompt, config.sambaNovaApiKey.trim(), maxTokens) else null
        TranslationEngine.GOOGLE_FREE -> null
    }

    private suspend fun callAutoHybridRaw(
        sysPrompt: String,
        userPrompt: String,
        config: AiTranslationConfig,
        maxTokens: Int
    ): String? {
        val now = System.currentTimeMillis()
        val activeEngines = buildList {
            if (config.groqApiKey.isNotBlank() && now >= groqCooldownUntil) add(TranslationEngine.GROQ_AI)
            if (config.geminiApiKey.isNotBlank() && now >= geminiCooldownUntil) add(TranslationEngine.GEMINI_AI)
            if (config.sambaNovaApiKey.isNotBlank() && now >= sambaNovaCooldownUntil) add(TranslationEngine.SAMBANOVA_AI)
        }
        if (activeEngines.isEmpty()) return null

        val startIdx = Math.abs(roundRobinCounter.getAndIncrement()) % activeEngines.size
        for (i in activeEngines.indices) {
            val engine = activeEngines[(startIdx + i) % activeEngines.size]
            val result = when (engine) {
                TranslationEngine.GROQ_AI -> callGroqFast(sysPrompt, userPrompt, config.groqApiKey.trim(), maxTokens)
                TranslationEngine.GEMINI_AI -> callGeminiFast(sysPrompt, userPrompt, config.geminiApiKey.trim(), maxTokens)
                TranslationEngine.SAMBANOVA_AI -> callSambaNovaFast(sysPrompt, userPrompt, config.sambaNovaApiKey.trim(), maxTokens)
                else -> null
            }
            if (!result.isNullOrBlank()) return result
        }
        return null
    }

    private suspend fun callGroqFast(sysPrompt: String, text: String, apiKey: String, maxTokens: Int): String? =
        withContext(Dispatchers.IO) {
            if (System.currentTimeMillis() < groqCooldownUntil) return@withContext null
            val model = cachedGroqModel ?: discoverGroqModels(apiKey).firstOrNull()?.also {
                cachedGroqModel = it
            } ?: run {
                groqCooldownUntil = System.currentTimeMillis() + cooldownMs
                return@withContext null
            }

            val req = Request.Builder()
                .url("https://api.groq.com/openai/v1/chat/completions")
                .header("Authorization", "Bearer $apiKey")
                .header("User-Agent", browserUserAgent)
                .header("Accept", "application/json")
                .post(buildOpenAiPayload(model, sysPrompt, text, maxTokens).toString().toRequestBody(jsonMediaType))
                .build()

            val res = runCatching {
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@runCatching null
                    extractOpenAiRawText(resp.body?.string().orEmpty()).takeIf { it.isNotBlank() }
                }
            }.getOrNull()

            if (res == null) {
                groqCooldownUntil = System.currentTimeMillis() + cooldownMs
            }
            res
        }

    private suspend fun callGeminiFast(sysPrompt: String, userPrompt: String, apiKey: String, maxTokens: Int): String? =
        withContext(Dispatchers.IO) {
            if (System.currentTimeMillis() < geminiCooldownUntil) return@withContext null
            val cached = cachedGeminiModel
            if (cached != null) {
                callGeminiModel(cached, sysPrompt, userPrompt, apiKey, maxTokens)?.let { return@withContext it }
            }
            val models = discoverGeminiModels(apiKey).take(4)
            for (model in models) {
                if (model == cached) continue
                val res = callGeminiModel(model, sysPrompt, userPrompt, apiKey, maxTokens)
                if (!res.isNullOrBlank()) {
                    cachedGeminiModel = model
                    return@withContext res
                }
            }
            geminiCooldownUntil = System.currentTimeMillis() + cooldownMs
            null
        }

    private fun callGeminiModel(model: String, sysPrompt: String, userPrompt: String, apiKey: String, maxTokens: Int): String? =
        runCatching {
            val payload = buildGeminiPayload(sysPrompt, userPrompt, maxTokens)
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
                .header("User-Agent", browserUserAgent)
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@runCatching null
                extractGeminiRawText(resp.body?.string().orEmpty()).takeIf { it.isNotBlank() }
            }
        }.getOrNull()

    private suspend fun callSambaNovaFast(sysPrompt: String, text: String, apiKey: String, maxTokens: Int): String? =
        withContext(Dispatchers.IO) {
            if (System.currentTimeMillis() < sambaNovaCooldownUntil) return@withContext null
            val models = cachedSambaNovaModel?.let { listOf(it) }
                ?: discoverSambaNovaModels(apiKey).take(4)

            for (model in models) {
                val req = Request.Builder()
                    .url("https://api.sambanova.ai/v1/chat/completions")
                    .header("Authorization", "Bearer $apiKey")
                    .header("User-Agent", browserUserAgent)
                    .post(buildOpenAiPayload(model, sysPrompt, text, maxTokens).toString().toRequestBody(jsonMediaType))
                    .build()

                val res = runCatching {
                    httpClient.newCall(req).execute().use { resp ->
                        if (!resp.isSuccessful) return@runCatching null
                        extractOpenAiRawText(resp.body?.string().orEmpty()).takeIf { it.isNotBlank() }
                    }
                }.getOrNull()

                if (!res.isNullOrBlank()) {
                    cachedSambaNovaModel = model
                    return@withContext res
                }
            }
            cachedSambaNovaModel = null
            sambaNovaCooldownUntil = System.currentTimeMillis() + cooldownMs
            null
        }

    private suspend fun translateViaGoogleFree(text: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            val encoded = URLEncoder.encode(text, "UTF-8")
            val req = Request.Builder()
                .url("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ar&dt=t&q=$encoded")
                .header("User-Agent", browserUserAgent)
                .get()
                .build()

            val body = fastGoogleClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@runCatching null
                resp.body?.string() ?: return@runCatching null
            }

            val root = JSONArray(body)
            val sentences = root.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                val part = sentences.getJSONArray(i).optString(0, "")
                if (part.isNotEmpty()) sb.append(part)
            }
            sb.toString().trim().takeIf { it.isNotEmpty() }
        }.getOrNull()
    }

    private fun discoverGroqModels(apiKey: String): List<String> {
        val discovered = mutableListOf<String>()
        runCatching {
            val req = Request.Builder()
                .url("https://api.groq.com/openai/v1/models")
                .header("Authorization", "Bearer $apiKey")
                .header("User-Agent", browserUserAgent)
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val data = JSONObject(resp.body?.string().orEmpty()).optJSONArray("data")
                    if (data != null) {
                        for (i in 0 until data.length()) {
                            val id = data.optJSONObject(i)?.optString("id", "").orEmpty()
                            val lower = id.lowercase()
                            if (id.isNotBlank() &&
                                !lower.contains("whisper") &&
                                !lower.contains("guard") &&
                                !lower.contains("tts") &&
                                !lower.contains("playai")
                            ) {
                                discovered.add(id)
                            }
                        }
                    }
                }
            }
        }
        val preferred = discovered.filter { it.contains("llama-3.3", true) || it.contains("llama-3.1-8b", true) } + discovered
        return preferred.distinct().ifEmpty {
            listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant")
        }
    }

    private fun discoverGeminiModels(apiKey: String): List<String> {
        val discovered = mutableListOf<String>()
        runCatching {
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models?key=$apiKey")
                .header("User-Agent", browserUserAgent)
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val arr = JSONObject(resp.body?.string().orEmpty()).optJSONArray("models")
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val obj = arr.optJSONObject(i) ?: continue
                            val name = obj.optString("name", "").removePrefix("models/")
                            val methods = obj.optJSONArray("supportedGenerationMethods")?.toString().orEmpty()
                            val lower = name.lowercase()
                            if (name.isNotBlank() &&
                                methods.contains("generateContent") &&
                                lower.contains("gemini") &&
                                !lower.contains("embedding") &&
                                !lower.contains("vision") &&
                                !lower.contains("tts") &&
                                !lower.contains("image") &&
                                !lower.contains("robotics")
                            ) {
                                discovered.add(name)
                            }
                        }
                    }
                }
            }
        }
        val flashFirst = discovered.filter { it.contains("flash", true) } + discovered
        return flashFirst.distinct().ifEmpty {
            listOf("gemini-2.0-flash", "gemini-2.0-flash-lite", "gemini-flash-latest")
        }
    }

    private fun discoverSambaNovaModels(apiKey: String): List<String> {
        val discovered = mutableListOf<String>()
        runCatching {
            val req = Request.Builder()
                .url("https://api.sambanova.ai/v1/models")
                .header("Authorization", "Bearer $apiKey")
                .header("User-Agent", browserUserAgent)
                .get()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val data = JSONObject(resp.body?.string().orEmpty()).optJSONArray("data")
                    if (data != null) {
                        for (i in 0 until data.length()) {
                            val id = data.optJSONObject(i)?.optString("id", "").orEmpty()
                            if (id.isNotBlank() && !id.contains("whisper", true) && !id.contains("embed", true) && !id.contains("guard", true)) {
                                discovered.add(id)
                            }
                        }
                    }
                }
            }
        }
        val priority = listOf(
            "Meta-Llama-3.3-70B-Instruct",
            "gemma-4-31B-it",
            "DeepSeek-V3.1",
            "gpt-oss-120b"
        )
        val matchedPriority = priority.filter { p -> discovered.any { it.equals(p, true) } }
        val others = discovered.filter { id ->
            id.contains("llama", true) || id.contains("gemma", true) || id.contains("deepseek", true) || id.contains("qwen", true)
        }
        return (matchedPriority + others + discovered + priority).distinct().take(6)
    }

    private fun buildOpenAiPayload(model: String, sysPrompt: String, userText: String, maxTokens: Int): JSONObject =
        JSONObject().apply {
            put("model", model)
            put("temperature", 0.2)
            put("max_tokens", maxTokens)
            put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", sysPrompt))
                    .put(JSONObject().put("role", "user").put("content", userText))
            )
        }

    private fun buildGeminiPayload(sysPrompt: String, userText: String, maxTokens: Int): JSONObject =
        JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sysPrompt)))
            )
            put(
                "contents",
                JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", userText))))
            )
            put(
                "generationConfig",
                JSONObject().put("temperature", 0.2).put("maxOutputTokens", maxTokens)
            )
        }

    private fun extractOpenAiRawText(body: String): String = runCatching {
        val choices = JSONObject(body).optJSONArray("choices") ?: return@runCatching ""
        if (choices.length() == 0) return@runCatching ""
        choices.getJSONObject(0).optJSONObject("message")?.optString("content", "")?.trim().orEmpty()
    }.getOrDefault("")

    private fun extractGeminiRawText(body: String): String = runCatching {
        val candidates = JSONObject(body).optJSONArray("candidates") ?: return@runCatching ""
        if (candidates.length() == 0) return@runCatching ""
        val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts") ?: return@runCatching ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            sb.append(parts.getJSONObject(i).optString("text", ""))
        }
        sb.toString().trim()
    }.getOrDefault("")

    private fun parseApiErrorMessage(body: String): String = runCatching {
        val obj = JSONObject(body)
        obj.optJSONObject("error")?.optString("message", "").orEmpty()
            .ifBlank { obj.optString("message", "") }
            .take(120)
    }.getOrDefault("")

    private fun parseNumberedBatch(raw: String, expectedSize: Int): Map<Int, String> {
        val map = mutableMapOf<Int, String>()
        val lineRegex = Regex("""^\s*(\d+)\s*[|:.:\-]\s*(.+)$""")
        for (line in raw.lines()) {
            val m = lineRegex.find(line.trim()) ?: continue
            val idx = (m.groupValues[1].toIntOrNull() ?: continue) - 1
            val text = m.groupValues[2].trim()
            if (idx in 0 until expectedSize && text.isNotEmpty()) {
                map[idx] = text
            }
        }
        return map
    }

    private fun cacheKeyFor(config: AiTranslationConfig, text: String): String {
        val normalized = text.lowercase()
            .replace(Regex("[^\\p{L}\\p{N}\\s']"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        return "${config.engine.name}|$normalized"
    }

    private fun isAlreadyArabic(text: String): Boolean {
        var ar = 0
        var letters = 0
        for (ch in text) {
            if (ch.isLetter()) {
                letters++
                if (ch in '\u0600'..'\u06FF') ar++
            }
        }
        return letters > 0 && (ar * 100 / letters) >= 60
    }

    private fun formatCinemaSubtitle(raw: String): String {
        var cleaned = raw
            .replace(Regex("```[\\s\\S]*?```"), "")
            .replace("*", "")
            .replace("\"", "")
            .replace(Regex("""^(?:الترجمة(?:\s+العربية)?(?:\s+هي)?|ترجمة|ملاحظة|Translation)\s*[:：\-]\s*""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\s+"), " ")
            .trim()
        // Drop pure LLM meta-commentary hallucinations like "في هذا الحوار قمت بترجمة..."
        if (cleaned.startsWith("في هذا الحوار") ||
            cleaned.startsWith("قمت بترجم") ||
            cleaned.startsWith("إليك الترجم") ||
            cleaned.startsWith("هنا الترجم") ||
            cleaned.contains("الترجمة الحرفية")
        ) {
            return ""
        }
        if (cleaned.length <= 42) return cleaned
        val mid = cleaned.length / 2
        var bestSpace = -1
        var bestDist = Int.MAX_VALUE
        for (i in cleaned.indices) {
            if (cleaned[i] == ' ') {
                val dist = kotlin.math.abs(i - mid)
                if (dist < bestDist) {
                    bestDist = dist
                    bestSpace = i
                }
            }
        }
        return if (bestSpace in 10..(cleaned.length - 10)) {
            cleaned.substring(0, bestSpace).trim() + "\n" + cleaned.substring(bestSpace + 1).trim()
        } else {
            cleaned
        }
    }

    private fun isRepetitiveHallucination(text: String): Boolean {
        val words = text.lowercase()
            .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .trim()
            .split(Regex("\\s+"))
            .filter { it.isNotEmpty() }
        if (words.size >= 3) {
            val unique = words.toSet()
            if (unique.size == 1) return true
            if (words.size >= 4 && unique.size * 2 <= words.size) return true
        }
        return false
    }

    fun close() {
        runCatching { mlKitTranslator.close() }
        runCatching { httpClient.connectionPool.evictAll() }
    }

    private fun pcmToWav(pcm: ByteArray, sampleRate: Int, channels: Int, bitsPerSample: Int): ByteArray {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val dataSize = pcm.size
        val chunkSize = 36 + dataSize
        val out = ByteArrayOutputStream(44 + dataSize)
        fun writeIntLE(v: Int) {
            out.write(v and 0xFF)
            out.write((v shr 8) and 0xFF)
            out.write((v shr 16) and 0xFF)
            out.write((v shr 24) and 0xFF)
        }
        fun writeShortLE(v: Int) {
            out.write(v and 0xFF)
            out.write((v shr 8) and 0xFF)
        }
        out.write("RIFF".toByteArray())
        writeIntLE(chunkSize)
        out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray())
        writeIntLE(16)
        writeShortLE(1)
        writeShortLE(channels)
        writeIntLE(sampleRate)
        writeIntLE(byteRate)
        writeShortLE(channels * bitsPerSample / 8)
        writeShortLE(bitsPerSample)
        out.write("data".toByteArray())
        writeIntLE(dataSize)
        out.write(pcm)
        return out.toByteArray()
    }
}
