package com.cinemasub.browser.browser

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import com.cinemasub.browser.translation.ArabicTranslator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URI
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

object ProactiveMediaSubtitleEngine {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val speakerPrefixRegex = Regex("""^\s*\[?S\d+]?\s*[:：\-]?\s*""", RegexOption.IGNORE_CASE)

    private data class TimedLine(
        val startSec: Double,
        val endSec: Double,
        val text: String,
        val speaker: Int?
    )

    private data class HlsSegment(
        val url: String,
        val durationSec: Double,
        val offsetSec: Double
    )

    fun isMediaStreamUrl(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val lower = url.lowercase()
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) return false
        val path = lower.substringBefore('?').substringBefore('#')
        if (path.endsWith(".m3u8")) return true
        if (path.endsWith(".mp4") || path.endsWith(".m4a") || path.endsWith(".webm")) {
            // Skip obvious ad / preview / tracking clips
            if (lower.contains("doubleclick") || lower.contains("googlesyndication") || lower.contains("adservice")) {
                return false
            }
            return true
        }
        return false
    }

    suspend fun generateProgressively(
        context: Context,
        mediaUrl: String,
        headers: Map<String, String>,
        deepgramApiKey: String,
        languageCode: String,
        translator: ArabicTranslator,
        onProgress: (json: String?, cueCount: Int, percent: Int, statusMsg: String) -> Unit
    ): Pair<String, Int>? = withContext(Dispatchers.IO) {
        val dgKey = deepgramApiKey.trim()
        if (dgKey.isEmpty()) {
            throw IllegalStateException("أدخل مفتاح Deepgram أولاً في الإعدادات لتشغيل الترجمة الاستباقية.")
        }

        // 1. Check Disk Cache first (instant 0ms load if already generated for this movie!)
        val cacheFile = cacheFileFor(context, mediaUrl)
        if (cacheFile.exists() && cacheFile.length() > 20) {
            val cachedJson = runCatching { cacheFile.readText(Charsets.UTF_8) }.getOrNull()
            if (!cachedJson.isNullOrBlank()) {
                val count = runCatching { JSONArray(cachedJson).length() }.getOrDefault(0)
                if (count > 0) {
                    onProgress(cachedJson, count, 100, "تم تحميل الترجمة المحفوظة فوراً ($count جملة) ✅")
                    return@withContext Pair(cachedJson, count)
                }
            }
        }

        val lowerPath = mediaUrl.lowercase().substringBefore('?')
        val allCues = mutableListOf<ExternalCue>()

        if (lowerPath.endsWith(".m3u8")) {
            processHlsStream(
                mediaUrl = mediaUrl,
                headers = headers,
                deepgramApiKey = dgKey,
                languageCode = languageCode,
                translator = translator,
                allCues = allCues,
                cacheFile = cacheFile,
                onProgress = onProgress
            )
        } else {
            processDirectMediaStream(
                mediaUrl = mediaUrl,
                headers = headers,
                deepgramApiKey = dgKey,
                languageCode = languageCode,
                translator = translator,
                allCues = allCues,
                cacheFile = cacheFile,
                onProgress = onProgress
            )
        }

        if (allCues.isEmpty()) return@withContext null
        val finalJson = cuesToJson(allCues)
        runCatching { cacheFile.writeText(finalJson, Charsets.UTF_8) }
        onProgress(finalJson, allCues.size, 100, "اكتملت الترجمة الاستباقية (${allCues.size} جملة) — توقيت 100% ✅")
        Pair(finalJson, allCues.size)
    }

    private suspend fun processHlsStream(
        mediaUrl: String,
        headers: Map<String, String>,
        deepgramApiKey: String,
        languageCode: String,
        translator: ArabicTranslator,
        allCues: MutableList<ExternalCue>,
        cacheFile: File,
        onProgress: (json: String?, cueCount: Int, percent: Int, statusMsg: String) -> Unit
    ) {
        onProgress(null, 0, 2, "جاري تحليل بث الفيديو (.m3u8)...")
        val playlistText = fetchText(mediaUrl, headers)
            ?: throw IllegalStateException("تعذر قراءة رابط البث (قد يكون محمياً بـ DRM).")

        var targetUrl = mediaUrl
        var mediaPlaylist = playlistText

        // If Master Playlist -> prefer audio-only track (10x faster!), else lowest-bandwidth variant
        if (playlistText.contains("#EXT-X-STREAM-INF")) {
            val resolved = pickBestSubPlaylistUrl(mediaUrl, playlistText)
            if (resolved != null) {
                targetUrl = resolved
                mediaPlaylist = fetchText(resolved, headers)
                    ?: throw IllegalStateException("تعذر تحميل قائمة مقاطع البث.")
            }
        }

        if (mediaPlaylist.contains("#EXT-X-KEY:METHOD=SAMPLE-AES") ||
            mediaPlaylist.contains("urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed")
        ) {
            throw IllegalStateException("هذا الفيديو محمي بـ DRM ولا يمكن سحب صوته مسبقاً — استخدم وضع الصوت المباشر.")
        }

        val initMapUrl = extractInitMapUrl(targetUrl, mediaPlaylist)
        val initBytes = initMapUrl?.let { fetchBytes(it, headers) }
        val segments = parseHlsSegments(targetUrl, mediaPlaylist)
        if (segments.isEmpty()) {
            throw IllegalStateException("لم يتم العثور على مقاطع صوتية قابلة للمعالجة في هذا البث.")
        }

        // Group segments into ~90s first batch (fast startup), then ~120s batches
        val batches = mutableListOf<List<HlsSegment>>()
        var currentBatch = mutableListOf<HlsSegment>()
        var batchDur = 0.0
        for (seg in segments) {
            currentBatch.add(seg)
            batchDur += seg.durationSec
            val targetDur = if (batches.isEmpty()) 90.0 else 120.0
            if (batchDur >= targetDur) {
                batches.add(currentBatch)
                currentBatch = mutableListOf()
                batchDur = 0.0
            }
        }
        if (currentBatch.isNotEmpty()) batches.add(currentBatch)

        val totalBatches = batches.size
        for ((batchIdx, batch) in batches.withIndex()) {
            coroutineContext.ensureActive()
            val startPercent = ((batchIdx * 100) / totalBatches).coerceIn(3, 98)
            val statusPrefix = if (batchIdx == 0) {
                "جاري تجهيز أول دقيقتين للبدء السريع..."
            } else {
                "يمكنك المشاهدة الآن! جاري استكمال الترجمة (${startPercent}%)..."
            }
            onProgress(if (allCues.isNotEmpty()) cuesToJson(allCues) else null, allCues.size, startPercent, statusPrefix)

            val out = ByteArrayOutputStream()
            if (initBytes != null && initBytes.isNotEmpty()) {
                out.write(initBytes)
            }
            for (seg in batch) {
                coroutineContext.ensureActive()
                val segBytes = fetchBytes(seg.url, headers) ?: continue
                out.write(segBytes)
                if (out.size() > 24 * 1024 * 1024) break
            }

            val mediaBytes = out.toByteArray()
            if (mediaBytes.size < 4096) continue

            val mime = if (initBytes != null) "video/mp4" else "video/mp2t"
            val chunkOffset = batch.first().offsetSec
            val timedLines = transcribeWithDeepgramPreRecorded(
                audioBytes = mediaBytes,
                contentType = mime,
                apiKey = deepgramApiKey,
                languageCode = languageCode,
                offsetSec = chunkOffset
            )

            if (timedLines.isNotEmpty()) {
                val translated = translateTimedLines(timedLines, translator)
                allCues.addAll(translated)
                allCues.sortBy { it.startSec }
                val jsonNow = cuesToJson(allCues)
                runCatching { cacheFile.writeText(jsonNow, Charsets.UTF_8) }
                val pct = (((batchIdx + 1) * 100) / totalBatches).coerceIn(5, 99)
                val readyMsg = if (batchIdx == 0) {
                    "تم تجهيز البداية (${allCues.size} جملة) — شغّل الفيلم الآن! جاري استكمال الباقي ($pct%)..."
                } else {
                    "جاري استكمال الترجمة في الخلفية (${allCues.size} جملة — $pct%)..."
                }
                onProgress(jsonNow, allCues.size, pct, readyMsg)
            }
        }
    }

    private suspend fun processDirectMediaStream(
        mediaUrl: String,
        headers: Map<String, String>,
        deepgramApiKey: String,
        languageCode: String,
        translator: ArabicTranslator,
        allCues: MutableList<ExternalCue>,
        cacheFile: File,
        onProgress: (json: String?, cueCount: Int, percent: Int, statusMsg: String) -> Unit
    ) {
        onProgress(null, 0, 5, "جاري فحص ملف الفيديو لاستخراج الصوت...")
        val contentLength = fetchContentLength(mediaUrl, headers)

        // Small direct video/audio (<= 18 MB): send directly to Deepgram in one fast pass
        if (contentLength in 1..(18L * 1024L * 1024L)) {
            onProgress(null, 0, 20, "جاري سحب الصوت وتفريغه بتوقيت دقيق...")
            val bytes = fetchBytes(mediaUrl, headers)
                ?: throw IllegalStateException("تعذر تحميل ملف الفيديو من الموقع.")
            val mime = when {
                mediaUrl.lowercase().contains(".webm") -> "video/webm"
                mediaUrl.lowercase().contains(".m4a") -> "audio/mp4"
                else -> "video/mp4"
            }
            val lines = transcribeWithDeepgramPreRecorded(bytes, mime, deepgramApiKey, languageCode, 0.0)
            if (lines.isNotEmpty()) {
                onProgress(null, 0, 65, "جاري ترجمة ${lines.size} جملة بسياق الفيلم...")
                allCues.addAll(translateTimedLines(lines, translator))
                allCues.sortBy { it.startSec }
                val jsonNow = cuesToJson(allCues)
                runCatching { cacheFile.writeText(jsonNow, Charsets.UTF_8) }
                onProgress(jsonNow, allCues.size, 98, "تمت الترجمة (${allCues.size} جملة)")
            }
            return
        }

        // Large MP4 movie: extract AUDIO-ONLY track via MediaExtractor (HTTP Range requests!) in 2-min chunks
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(mediaUrl, headers)
            var audioTrackIdx = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    audioTrackIdx = i
                    audioFormat = fmt
                    break
                }
            }

            if (audioTrackIdx < 0 || audioFormat == null) {
                throw IllegalStateException("تعذر استخراج مسار الصوت من الفيديو — استخدم وضع الصوت المباشر.")
            }

            extractor.selectTrack(audioTrackIdx)
            val trackMime = audioFormat.getString(MediaFormat.KEY_MIME).orEmpty()
            val sampleRate = if (audioFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            } else 44100
            val channelCount = if (audioFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            } else 2
            val durationUs = if (audioFormat.containsKey(MediaFormat.KEY_DURATION)) {
                audioFormat.getLong(MediaFormat.KEY_DURATION)
            } else 0L
            val isAac = trackMime.contains("mp4a", ignoreCase = true)
            val sendMime = if (isAac) "audio/aac" else "audio/mpeg"

            val chunkDurationUs = 120_000_000L // 2 minutes per progressive chunk
            var chunkStartUs = 0L
            var chunkIndex = 0
            val sampleBuf = ByteBuffer.allocate(256 * 1024)
            var chunkOut = ByteArrayOutputStream()
            var hasDataInChunk = false

            while (true) {
                coroutineContext.ensureActive()
                val sampleTimeUs = extractor.sampleTime
                if (sampleTimeUs < 0) break

                if (!hasDataInChunk) {
                    chunkStartUs = sampleTimeUs
                    hasDataInChunk = true
                }

                sampleBuf.clear()
                val readSize = extractor.readSampleData(sampleBuf, 0)
                if (readSize > 0) {
                    val frameBytes = ByteArray(readSize)
                    sampleBuf.get(frameBytes, 0, readSize)
                    if (isAac) {
                        chunkOut.write(createAdtsHeader(readSize, sampleRate, channelCount))
                    }
                    chunkOut.write(frameBytes)
                }

                val advanced = extractor.advance()
                val chunkElapsedUs = sampleTimeUs - chunkStartUs
                val shouldFlush = !advanced || chunkElapsedUs >= chunkDurationUs || chunkOut.size() >= 6 * 1024 * 1024

                if (shouldFlush && chunkOut.size() >= 4096) {
                    val pct = if (durationUs > 0L) {
                        ((sampleTimeUs * 95L) / durationUs).toInt().coerceIn(5, 95)
                    } else {
                        (10 + chunkIndex * 10).coerceAtMost(90)
                    }
                    val audioBytes = chunkOut.toByteArray()
                    chunkOut = ByteArrayOutputStream()
                    hasDataInChunk = false

                    val lines = transcribeWithDeepgramPreRecorded(
                        audioBytes = audioBytes,
                        contentType = sendMime,
                        apiKey = deepgramApiKey,
                        languageCode = languageCode,
                        offsetSec = chunkStartUs / 1_000_000.0
                    )
                    if (lines.isNotEmpty()) {
                        allCues.addAll(translateTimedLines(lines, translator))
                        allCues.sortBy { it.startSec }
                        val jsonNow = cuesToJson(allCues)
                        runCatching { cacheFile.writeText(jsonNow, Charsets.UTF_8) }
                        val msg = if (chunkIndex == 0) {
                            "تم تجهيز أول دقيقتين (${allCues.size} جملة) — شغّل الفيلم الآن! ($pct%)"
                        } else {
                            "جاري استكمال ترجمة الفيلم في الخلفية (${allCues.size} جملة — $pct%)..."
                        }
                        onProgress(jsonNow, allCues.size, pct, msg)
                    }
                    chunkIndex++
                }
                if (!advanced) break
            }
        } finally {
            runCatching { extractor.release() }
        }
    }

    private fun transcribeWithDeepgramPreRecorded(
        audioBytes: ByteArray,
        contentType: String,
        apiKey: String,
        languageCode: String,
        offsetSec: Double
    ): List<TimedLine> {
        val url = "https://api.deepgram.com/v1/listen" +
            "?model=nova-2" +
            "&language=$languageCode" +
            "&smart_format=true" +
            "&punctuate=true" +
            "&diarize=true" +
            "&utterances=true"

        val req = Request.Builder()
            .url(url)
            .header("Authorization", "Token $apiKey")
            .post(audioBytes.toRequestBody(contentType.toMediaType()))
            .build()

        val body = runCatching {
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@runCatching null
                resp.body?.string()
            }
        }.getOrNull() ?: return emptyList()

        return parseDeepgramTimedLines(body, offsetSec)
    }

    // Builds clean cinema-length subtitle cues (1-6 sec, max ~78 chars / 2 lines) from Deepgram word timestamps
    private fun parseDeepgramTimedLines(jsonBody: String, offsetSec: Double): List<TimedLine> {
        val result = mutableListOf<TimedLine>()
        runCatching {
            val root = JSONObject(jsonBody)
            val resultsObj = root.optJSONObject("results") ?: return result

            // Prefer utterances with speaker diarization & word-level timestamps
            val utterances = resultsObj.optJSONArray("utterances")
            if (utterances != null && utterances.length() > 0) {
                for (i in 0 until utterances.length()) {
                    val utt = utterances.optJSONObject(i) ?: continue
                    val words = utt.optJSONArray("words")
                    val speaker = if (utt.has("speaker")) utt.optInt("speaker") else null
                    if (words != null && words.length() > 0) {
                        splitWordsIntoCinemaLines(words, offsetSec, speaker, result)
                    } else {
                        val txt = utt.optString("transcript", "").trim()
                        if (txt.isNotEmpty()) {
                            val s = utt.optDouble("start", 0.0) + offsetSec
                            val e = (utt.optDouble("end", s + 2.0) + offsetSec).coerceIn(s + 1.0, s + 6.0)
                            result.add(TimedLine(s, e, txt, speaker))
                        }
                    }
                }
                if (result.isNotEmpty()) return result
            }

            // Fallback to channels[0].alternatives[0].words
            val channels = resultsObj.optJSONArray("channels") ?: return result
            val alts = channels.optJSONObject(0)?.optJSONArray("alternatives") ?: return result
            val words = alts.optJSONObject(0)?.optJSONArray("words") ?: return result
            splitWordsIntoCinemaLines(words, offsetSec, null, result)
        }
        return result
    }

    private fun splitWordsIntoCinemaLines(
        words: JSONArray,
        offsetSec: Double,
        defaultSpeaker: Int?,
        out: MutableList<TimedLine>
    ) {
        val sb = StringBuilder()
        var lineStart = -1.0
        var lineEnd = -1.0
        var lineSpeaker: Int? = defaultSpeaker

        fun flush() {
            val text = sb.toString().trim()
            if (text.isNotEmpty() && lineStart >= 0.0) {
                val safeEnd = lineEnd.coerceIn(lineStart + 1.0, lineStart + 6.0)
                out.add(TimedLine(lineStart, safeEnd, text, lineSpeaker))
            }
            sb.setLength(0)
            lineStart = -1.0
            lineEnd = -1.0
        }

        for (i in 0 until words.length()) {
            val w = words.optJSONObject(i) ?: continue
            val token = w.optString("punctuated_word", "").ifBlank { w.optString("word", "") }.trim()
            if (token.isEmpty()) continue
            val wStart = w.optDouble("start", 0.0) + offsetSec
            val wEnd = w.optDouble("end", wStart + 0.3) + offsetSec
            val wSpeaker = if (w.has("speaker")) w.optInt("speaker") else defaultSpeaker

            val gap = if (lineEnd >= 0.0) wStart - lineEnd else 0.0
            val speakerChanged = lineSpeaker != null && wSpeaker != null && lineSpeaker != wSpeaker

            if (sb.isNotEmpty() && (gap >= 0.75 || speakerChanged || sb.length + token.length > 76 || (wEnd - lineStart) >= 5.4)) {
                flush()
            }

            if (lineStart < 0.0) {
                lineStart = wStart
                lineSpeaker = wSpeaker
            }
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(token)
            lineEnd = wEnd

            val endsSentence = token.endsWith(".") || token.endsWith("?") || token.endsWith("!")
            if (endsSentence && sb.length >= 24) {
                flush()
            }
        }
        flush()
    }

    // Translates in 45-line scene batches with speaker hints so Arabic pronouns/gender stay accurate
    private suspend fun translateTimedLines(
        lines: List<TimedLine>,
        translator: ArabicTranslator
    ): List<ExternalCue> {
        val output = mutableListOf<ExternalCue>()
        val chunks = lines.chunked(45)
        for (chunk in chunks) {
            coroutineContext.ensureActive()
            val textsForAi = chunk.map { line ->
                if (line.speaker != null) "[S${line.speaker + 1}] ${line.text}" else line.text
            }
            val translatedMap = translator.translateBatchForSubtitleFile(textsForAi)
            chunk.forEachIndexed { idx, line ->
                val rawAr = translatedMap[idx] ?: line.text
                val cleanAr = rawAr.replace(speakerPrefixRegex, "").trim()
                if (cleanAr.isNotEmpty()) {
                    output.add(
                        ExternalCue(
                            startSec = line.startSec,
                            endSec = line.endSec,
                            originalText = line.text,
                            arabicText = cleanAr
                        )
                    )
                }
            }
        }
        return output
    }

    private fun cuesToJson(cues: List<ExternalCue>): String {
        val arr = JSONArray()
        for (cue in cues) {
            arr.put(
                JSONObject().apply {
                    put("s", cue.startSec)
                    put("e", cue.endSec)
                    put("ar", cue.arabicText)
                    put("en", cue.originalText)
                }
            )
        }
        return arr.toString()
    }

    private fun pickBestSubPlaylistUrl(masterUrl: String, masterText: String): String? {
        val lines = masterText.lines().map { it.trim() }
        // 1. Check for dedicated AUDIO-only playlist first (fastest & smallest!)
        val audioUriRegex = Regex("""URI="([^"]+)"""")
        for (line in lines) {
            if (line.startsWith("#EXT-X-MEDIA:") && line.contains("TYPE=AUDIO")) {
                val m = audioUriRegex.find(line)
                if (m != null) {
                    return resolveUrl(masterUrl, m.groupValues[1])
                }
            }
        }
        // 2. Otherwise pick lowest-bandwidth video+audio variant
        var lowestBw = Long.MAX_VALUE
        var bestUrl: String? = null
        val bwRegex = Regex("""BANDWIDTH=(\d+)""")
        for (i in lines.indices) {
            val line = lines[i]
            if (line.startsWith("#EXT-X-STREAM-INF")) {
                val bw = bwRegex.find(line)?.groupValues?.get(1)?.toLongOrNull() ?: Long.MAX_VALUE
                val nextUri = lines.drop(i + 1).firstOrNull { it.isNotEmpty() && !it.startsWith("#") }
                if (nextUri != null && bw < lowestBw) {
                    lowestBw = bw
                    bestUrl = resolveUrl(masterUrl, nextUri)
                }
            }
        }
        return bestUrl
    }

    private fun extractInitMapUrl(baseUrl: String, playlistText: String): String? {
        val uriRegex = Regex("""URI="([^"]+)"""")
        for (raw in playlistText.lines()) {
            val line = raw.trim()
            if (line.startsWith("#EXT-X-MAP:")) {
                val m = uriRegex.find(line)
                if (m != null) return resolveUrl(baseUrl, m.groupValues[1])
            }
        }
        return null
    }

    private fun parseHlsSegments(baseUrl: String, playlistText: String): List<HlsSegment> {
        val list = mutableListOf<HlsSegment>()
        var pendingDuration: Double? = null
        var elapsed = 0.0
        for (raw in playlistText.lines()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTINF:")) {
                val durStr = line.removePrefix("#EXTINF:").substringBefore(',').trim()
                pendingDuration = durStr.toDoubleOrNull() ?: 4.0
            } else if (!line.startsWith("#") && pendingDuration != null) {
                val segUrl = resolveUrl(baseUrl, line)
                list.add(HlsSegment(segUrl, pendingDuration, elapsed))
                elapsed += pendingDuration
                pendingDuration = null
            }
        }
        return list
    }

    private fun resolveUrl(baseUrl: String, relative: String): String {
        if (relative.startsWith("http://") || relative.startsWith("https://")) return relative
        return runCatching { URI(baseUrl).resolve(relative).toString() }.getOrDefault(relative)
    }

    private fun fetchText(url: String, headers: Map<String, String>): String? = runCatching {
        val req = buildRequest(url, headers).get().build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return@runCatching null
            resp.body?.string()
        }
    }.getOrNull()

    private fun fetchBytes(url: String, headers: Map<String, String>): ByteArray? = runCatching {
        val req = buildRequest(url, headers).get().build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return@runCatching null
            resp.body?.bytes()
        }
    }.getOrNull()

    private fun fetchContentLength(url: String, headers: Map<String, String>): Long = runCatching {
        val req = buildRequest(url, headers).head().build()
        httpClient.newCall(req).execute().use { resp ->
            resp.header("Content-Length")?.toLongOrNull() ?: -1L
        }
    }.getOrDefault(-1L)

    private fun buildRequest(url: String, headers: Map<String, String>): Request.Builder {
        val b = Request.Builder().url(url)
        for ((k, v) in headers) {
            if (k.equals("Range", true) || k.equals("Host", true) || k.equals("Content-Length", true)) continue
            if (v.isNotBlank()) b.header(k, v)
        }
        return b
    }

    // Standard 7-byte ADTS header for raw AAC frames extracted by MediaExtractor
    private fun createAdtsHeader(frameLength: Int, sampleRate: Int, channels: Int): ByteArray {
        val packetLen = frameLength + 7
        val freqIdx = when (sampleRate) {
            96000 -> 0
            88200 -> 1
            64000 -> 2
            48000 -> 3
            44100 -> 4
            32000 -> 5
            24000 -> 6
            22050 -> 7
            16000 -> 8
            12000 -> 9
            11025 -> 10
            8000 -> 11
            else -> 4
        }
        val profile = 2 // AAC LC
        val chanCfg = channels.coerceIn(1, 7)
        val header = ByteArray(7)
        header[0] = 0xFF.toByte()
        header[1] = 0xF9.toByte()
        header[2] = (((profile - 1) shl 6) + (freqIdx shl 2) + (chanCfg shr 2)).toByte()
        header[3] = (((chanCfg and 3) shl 6) + (packetLen shr 11)).toByte()
        header[4] = ((packetLen and 0x7FF) shr 3).toByte()
        header[5] = (((packetLen and 7) shl 5) + 0x1F).toByte()
        header[6] = 0xFC.toByte()
        return header
    }

    private fun cacheFileFor(context: Context, mediaUrl: String): File {
        val dir = File(context.cacheDir, "proactive_subs").apply { mkdirs() }
        val cleanUrl = mediaUrl.substringBefore('?')
        val digest = MessageDigest.getInstance("SHA-256").digest(cleanUrl.toByteArray(Charsets.UTF_8))
        val hex = digest.joinToString("") { "%02x".format(it) }.take(24)
        return File(dir, "$hex.json")
    }
}
