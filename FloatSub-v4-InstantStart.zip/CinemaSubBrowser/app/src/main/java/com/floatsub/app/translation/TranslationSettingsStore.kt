package com.floatsub.app.translation

import android.content.Context
import com.floatsub.app.model.AiTranslationConfig
import com.floatsub.app.model.DeepgramLanguage
import com.floatsub.app.model.SubtitleBgOpacity
import com.floatsub.app.model.SubtitleFontSize
import com.floatsub.app.model.SubtitleStyleConfig
import com.floatsub.app.model.SubtitleTextColor
import com.floatsub.app.model.TranslationEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object TranslationSettingsStore {

    private const val PREFS_NAME = "floatsub_prefs"
    private const val KEY_ENGINE = "translation_engine"
    private const val KEY_GEMINI = "gemini_api_key"
    private const val KEY_GROQ = "groq_api_key"
    private const val KEY_SAMBANOVA = "sambanova_api_key"
    private const val KEY_DEEPGRAM = "deepgram_api_key"
    private const val KEY_DEEPGRAM_LANG = "deepgram_language"
    private const val KEY_OPUS_COMPRESSION = "opus_compression_enabled"
    private const val KEY_FONT_SIZE = "font_size"
    private const val KEY_TEXT_COLOR = "text_color"
    private const val KEY_BG_OPACITY = "bg_opacity"
    private const val KEY_OVERLAY_Y = "overlay_y_offset"

    @Volatile
    var currentConfig: AiTranslationConfig = AiTranslationConfig()
        private set

    private val _styleConfig = MutableStateFlow(SubtitleStyleConfig())
    val styleConfig: StateFlow<SubtitleStyleConfig> = _styleConfig.asStateFlow()

    @Volatile
    var currentPageTitle: String = ""

    fun init(context: Context) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val engine = runCatching {
            TranslationEngine.valueOf(prefs.getString(KEY_ENGINE, TranslationEngine.AUTO_HYBRID.name) ?: "")
        }.getOrDefault(TranslationEngine.AUTO_HYBRID)

        val dgLang = runCatching {
            DeepgramLanguage.valueOf(prefs.getString(KEY_DEEPGRAM_LANG, DeepgramLanguage.ENGLISH.name) ?: "")
        }.getOrDefault(DeepgramLanguage.ENGLISH)

        currentConfig = AiTranslationConfig(
            engine = engine,
            geminiApiKey = prefs.getString(KEY_GEMINI, "") ?: "",
            groqApiKey = prefs.getString(KEY_GROQ, "") ?: "",
            sambaNovaApiKey = prefs.getString(KEY_SAMBANOVA, "") ?: "",
            deepgramApiKey = prefs.getString(KEY_DEEPGRAM, "") ?: "",
            deepgramLanguage = dgLang,
            opusCompressionEnabled = prefs.getBoolean(KEY_OPUS_COMPRESSION, true)
        )

        val fontSize = runCatching {
            SubtitleFontSize.valueOf(prefs.getString(KEY_FONT_SIZE, SubtitleFontSize.MEDIUM.name) ?: "")
        }.getOrDefault(SubtitleFontSize.MEDIUM)
        val textColor = runCatching {
            SubtitleTextColor.valueOf(prefs.getString(KEY_TEXT_COLOR, SubtitleTextColor.WHITE.name) ?: "")
        }.getOrDefault(SubtitleTextColor.WHITE)
        val bgOpacity = runCatching {
            SubtitleBgOpacity.valueOf(prefs.getString(KEY_BG_OPACITY, SubtitleBgOpacity.SEMI_TRANSPARENT.name) ?: "")
        }.getOrDefault(SubtitleBgOpacity.SEMI_TRANSPARENT)
        val overlayY = prefs.getInt(KEY_OVERLAY_Y, 180)

        _styleConfig.value = SubtitleStyleConfig(
            fontSize = fontSize,
            textColor = textColor,
            bgOpacity = bgOpacity,
            overlayYOffsetPx = overlayY
        )
    }

    fun update(context: Context, config: AiTranslationConfig) {
        currentConfig = config
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_ENGINE, config.engine.name)
            .putString(KEY_GEMINI, config.geminiApiKey.trim())
            .putString(KEY_GROQ, config.groqApiKey.trim())
            .putString(KEY_SAMBANOVA, config.sambaNovaApiKey.trim())
            .putString(KEY_DEEPGRAM, config.deepgramApiKey.trim())
            .putString(KEY_DEEPGRAM_LANG, config.deepgramLanguage.name)
            .putBoolean(KEY_OPUS_COMPRESSION, config.opusCompressionEnabled)
            .apply()
    }

    fun updateStyle(context: Context, style: SubtitleStyleConfig) {
        _styleConfig.value = style
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_FONT_SIZE, style.fontSize.name)
            .putString(KEY_TEXT_COLOR, style.textColor.name)
            .putString(KEY_BG_OPACITY, style.bgOpacity.name)
            .putInt(KEY_OVERLAY_Y, style.overlayYOffsetPx)
            .apply()
    }
}
