package com.floatsub.app.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.floatsub.app.audio.AudioCaptureService
import com.floatsub.app.audio.DeepgramStreamingClient
import com.floatsub.app.model.AiTranslationConfig
import com.floatsub.app.model.DeepgramLanguage
import com.floatsub.app.model.SubtitleBgOpacity
import com.floatsub.app.model.SubtitleFontSize
import com.floatsub.app.model.SubtitleState
import com.floatsub.app.model.SubtitleStyleConfig
import com.floatsub.app.model.SubtitleTextColor
import com.floatsub.app.model.TranslationEngine
import com.floatsub.app.translation.ArabicTranslator
import com.floatsub.app.translation.TranslationSettingsStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FloatSubUiState(
    val aiConfig: AiTranslationConfig = TranslationSettingsStore.currentConfig,
    val styleConfig: SubtitleStyleConfig = TranslationSettingsStore.styleConfig.value,
    val isTestingApiKey: Boolean = false,
    val apiKeyTestResult: Pair<Boolean, String>? = null,
    val isTestingDeepgramKey: Boolean = false,
    val deepgramTestResult: Pair<Boolean, String>? = null
)

class FloatSubViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(FloatSubUiState())
    val uiState: StateFlow<FloatSubUiState> = _uiState.asStateFlow()

    val subtitleState: StateFlow<SubtitleState> = AudioCaptureService.subtitleState
    private val testerTranslator = ArabicTranslator()

    fun loadSavedSettings(context: Context) {
        TranslationSettingsStore.init(context)
        _uiState.update {
            it.copy(
                aiConfig = TranslationSettingsStore.currentConfig,
                styleConfig = TranslationSettingsStore.styleConfig.value
            )
        }
    }

    fun updateEngine(context: Context, engine: TranslationEngine) {
        val updated = _uiState.value.aiConfig.copy(engine = engine)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated, apiKeyTestResult = null) }
    }

    fun updateGeminiKey(context: Context, key: String) {
        val updated = _uiState.value.aiConfig.copy(geminiApiKey = key)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated, apiKeyTestResult = null) }
    }

    fun updateGroqKey(context: Context, key: String) {
        val updated = _uiState.value.aiConfig.copy(groqApiKey = key)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated, apiKeyTestResult = null) }
    }

    fun updateSambaNovaKey(context: Context, key: String) {
        val updated = _uiState.value.aiConfig.copy(sambaNovaApiKey = key)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated, apiKeyTestResult = null) }
    }

    fun updateDeepgramKey(context: Context, key: String) {
        val updated = _uiState.value.aiConfig.copy(deepgramApiKey = key)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated, deepgramTestResult = null) }
    }

    fun updateDeepgramLanguage(context: Context, lang: DeepgramLanguage) {
        val updated = _uiState.value.aiConfig.copy(deepgramLanguage = lang)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated) }
    }

    fun updateOpusCompression(context: Context, enabled: Boolean) {
        val updated = _uiState.value.aiConfig.copy(opusCompressionEnabled = enabled)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated) }
    }

    fun testAiKeys() {
        val cfg = _uiState.value.aiConfig
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingApiKey = true, apiKeyTestResult = null) }
            val result = testerTranslator.testAllConfiguredKeys(cfg)
            _uiState.update { it.copy(isTestingApiKey = false, apiKeyTestResult = result) }
        }
    }

    fun testDeepgramKey() {
        val key = _uiState.value.aiConfig.deepgramApiKey
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingDeepgramKey = true, deepgramTestResult = null) }
            val result = DeepgramStreamingClient.verifyApiKey(key)
            _uiState.update { it.copy(isTestingDeepgramKey = false, deepgramTestResult = result) }
        }
    }

    fun updateFontSize(context: Context, size: SubtitleFontSize) {
        val updated = _uiState.value.styleConfig.copy(fontSize = size)
        TranslationSettingsStore.updateStyle(context, updated)
        _uiState.update { it.copy(styleConfig = updated) }
    }

    fun updateTextColor(context: Context, color: SubtitleTextColor) {
        val updated = _uiState.value.styleConfig.copy(textColor = color)
        TranslationSettingsStore.updateStyle(context, updated)
        _uiState.update { it.copy(styleConfig = updated) }
    }

    fun updateBgOpacity(context: Context, opacity: SubtitleBgOpacity) {
        val updated = _uiState.value.styleConfig.copy(bgOpacity = opacity)
        TranslationSettingsStore.updateStyle(context, updated)
        _uiState.update { it.copy(styleConfig = updated) }
    }

    fun resetOverlayPosition(context: Context) {
        val updated = _uiState.value.styleConfig.copy(overlayYOffsetPx = 180)
        TranslationSettingsStore.updateStyle(context, updated)
        _uiState.update { it.copy(styleConfig = updated) }
    }

    override fun onCleared() {
        testerTranslator.close()
        super.onCleared()
    }
}
