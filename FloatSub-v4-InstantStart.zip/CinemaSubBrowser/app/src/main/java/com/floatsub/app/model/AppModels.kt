package com.floatsub.app.model

import androidx.compose.ui.graphics.Color

enum class SubtitleFontSize(val labelAr: String, val sp: Float) {
    SMALL("صغير", 16f),
    MEDIUM("متوسط", 20f),
    LARGE("كبير", 24f),
    EXTRA_LARGE("كبير جداً", 30f)
}

enum class SubtitleTextColor(val labelAr: String, val color: Color, val argb: Int) {
    WHITE("أبيض ناصع", Color(0xFFFFFFFF), 0xFFFFFFFF.toInt()),
    NETFLIX_YELLOW("أصفر سينمائي", Color(0xFFF5C518), 0xFFF5C518.toInt())
}

enum class SubtitleBgOpacity(val labelAr: String, val color: Color, val argb: Int) {
    NONE("بدون خلفية", Color.Transparent, 0x00000000),
    SEMI_TRANSPARENT("شبه شفاف", Color(0xAA000000), 0xAA000000.toInt()),
    SOLID("داكن بالكامل", Color(0xE6000000), 0xE6000000.toInt())
}

enum class DeepgramLanguage(val labelAr: String, val code: String) {
    ENGLISH("إنجليزي (أسرع وأدق)", "en"),
    AUTO_MULTI("تلقائي (كل اللغات)", "multi")
}

enum class TranslationEngine(val labelAr: String) {
    AUTO_HYBRID("الكل معاً (ذكي)"),
    GEMINI_AI("Gemini AI"),
    GROQ_AI("Groq AI"),
    SAMBANOVA_AI("SambaNova (سريع ومجاني)"),
    GOOGLE_FREE("جوجل (مجاني)")
}

enum class SubtitleSourceMode {
    NONE,
    LIVE_AUDIO
}

data class SubtitleStyleConfig(
    val fontSize: SubtitleFontSize = SubtitleFontSize.MEDIUM,
    val textColor: SubtitleTextColor = SubtitleTextColor.WHITE,
    val bgOpacity: SubtitleBgOpacity = SubtitleBgOpacity.SEMI_TRANSPARENT,
    val overlayYOffsetPx: Int = 180
)

data class AiTranslationConfig(
    val engine: TranslationEngine = TranslationEngine.AUTO_HYBRID,
    val geminiApiKey: String = "",
    val groqApiKey: String = "",
    val sambaNovaApiKey: String = "",
    val deepgramApiKey: String = "",
    val deepgramLanguage: DeepgramLanguage = DeepgramLanguage.ENGLISH,
    val opusCompressionEnabled: Boolean = true
)

sealed interface PipelineStatus {
    data object Idle : PipelineStatus
    data class DownloadingModels(val messageAr: String, val progress: Int? = null) : PipelineStatus
    data object Listening : PipelineStatus
    data class Error(val messageAr: String) : PipelineStatus
}

data class SubtitleState(
    val isLiveEnabled: Boolean = false,
    val isPaused: Boolean = false,
    val sourceMode: SubtitleSourceMode = SubtitleSourceMode.NONE,
    val arabicText: String = "",
    val originalEnglishText: String = "",
    val status: PipelineStatus = PipelineStatus.Idle
)
