package com.cinemasub.browser.translation

import android.content.Context
import com.cinemasub.browser.model.AiTranslationConfig
import com.cinemasub.browser.model.TranslationEngine

object TranslationSettingsStore {

    private const val PREFS_NAME = "cinemasub_ai_prefs"
    private const val KEY_ENGINE = "translation_engine"
    private const val KEY_GEMINI = "gemini_api_key"
    private const val KEY_GROQ = "groq_api_key"
    private const val KEY_ADBLOCK = "adblock_enabled"

    @Volatile
    var currentConfig: AiTranslationConfig = AiTranslationConfig()
        private set

    @Volatile
    var isAdBlockerEnabled: Boolean = true
        private set

    fun init(context: Context) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val engineName = prefs.getString(KEY_ENGINE, TranslationEngine.GOOGLE_FREE.name)
        val engine = runCatching { TranslationEngine.valueOf(engineName ?: "") }
            .getOrDefault(TranslationEngine.GOOGLE_FREE)
        val geminiKey = prefs.getString(KEY_GEMINI, "") ?: ""
        val groqKey = prefs.getString(KEY_GROQ, "") ?: ""
        isAdBlockerEnabled = prefs.getBoolean(KEY_ADBLOCK, true)
        currentConfig = AiTranslationConfig(
            engine = engine,
            geminiApiKey = geminiKey,
            groqApiKey = groqKey
        )
    }

    fun update(context: Context, config: AiTranslationConfig) {
        currentConfig = config
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_ENGINE, config.engine.name)
            .putString(KEY_GEMINI, config.geminiApiKey.trim())
            .putString(KEY_GROQ, config.groqApiKey.trim())
            .apply()
    }

    fun setAdBlockerEnabled(context: Context, enabled: Boolean) {
        isAdBlockerEnabled = enabled
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_ADBLOCK, enabled).apply()
    }
}
