package com.cinemasub.browser.ui.components

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.cinemasub.browser.browser.ExternalCue
import com.cinemasub.browser.model.PipelineStatus
import com.cinemasub.browser.model.SubtitleSourceMode
import com.cinemasub.browser.model.SubtitleState
import com.cinemasub.browser.model.SubtitleStyleConfig
import kotlinx.coroutines.delay
import okhttp3.OkHttpClient
import org.json.JSONArray
import java.util.concurrent.TimeUnit

@OptIn(UnstableApi::class)
@Composable
fun CinemaPlayerOverlay(
    mediaUrl: String,
    headers: Map<String, String>,
    externalSubtitlesJson: String?,
    styleConfig: SubtitleStyleConfig,
    playbackSpeed: Float,
    isGeneratingProactive: Boolean,
    proactiveProgressPercent: Int,
    onStartProactiveSubtitles: () -> Unit,
    onNudgeSyncOffset: (Float) -> Unit,
    onResetSyncOffset: () -> Unit,
    onVerticalBiasChanged: (Float) -> Unit,
    onOpenSettings: () -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current

    BackHandler(enabled = true) {
        onClose()
    }

    val parsedCues = remember(externalSubtitlesJson) {
        parseCuesJson(externalSubtitlesJson)
    }

    var playerError by remember { mutableStateOf<String?>(null) }
    var currentSubtitleState by remember {
        mutableStateOf(
            SubtitleState(
                isLiveEnabled = true,
                sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                status = PipelineStatus.Listening
            )
        )
    }

    val exoPlayer = remember(mediaUrl) {
        val okClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()

        val cleanHeaders = buildMap {
            for ((k, v) in headers) {
                if (k.equals("Range", true) || k.equals("Host", true) || k.equals("Content-Length", true)) {
                    continue
                }
                if (v.isNotBlank()) put(k, v)
            }
        }

        val dataSourceFactory = OkHttpDataSource.Factory(okClient)
            .setDefaultRequestProperties(cleanHeaders)

        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)

        ExoPlayer.Builder(context)
            .setMediaSourceFactory(mediaSourceFactory)
            .build()
            .apply {
                val isHls = mediaUrl.lowercase().substringBefore('?').endsWith(".m3u8")
                val itemBuilder = MediaItem.Builder().setUri(mediaUrl)
                if (isHls) {
                    itemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
                }
                setMediaItem(itemBuilder.build())
                setPlaybackSpeed(playbackSpeed)
                addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        playerError = "تعذر تشغيل البث مباشرة (${error.errorCodeName}) — جرّب سيرفر آخر أو المتصفح."
                    }
                })
                prepare()
                playWhenReady = true
            }
    }

    LaunchedEffect(playbackSpeed) {
        exoPlayer.setPlaybackSpeed(playbackSpeed)
    }

    DisposableEffect(exoPlayer) {
        onDispose {
            exoPlayer.release()
        }
    }

    // 60ms high-precision subtitle sync loop bound directly to ExoPlayer.currentPosition
    LaunchedEffect(exoPlayer, parsedCues, styleConfig.syncOffsetSec) {
        var lastKey = ""
        while (true) {
            if (parsedCues.isNotEmpty()) {
                val tSec = (exoPlayer.currentPosition / 1000.0) - styleConfig.syncOffsetSec.toDouble()
                val matched = findCueAtTime(parsedCues, tSec)
                val key = if (matched != null) "${matched.startSec}|${matched.arabicText}" else ""
                if (key != lastKey) {
                    lastKey = key
                    currentSubtitleState = SubtitleState(
                        isLiveEnabled = true,
                        sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                        status = PipelineStatus.Listening,
                        arabicText = matched?.arabicText.orEmpty(),
                        originalEnglishText = matched?.originalText.orEmpty()
                    )
                }
            } else if (lastKey.isNotEmpty()) {
                lastKey = ""
                currentSubtitleState = SubtitleState(
                    isLiveEnabled = true,
                    sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                    status = PipelineStatus.Listening,
                    arabicText = "",
                    originalEnglishText = ""
                )
            }
            delay(60L)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    player = exoPlayer
                    useController = true
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                }
            },
            update = { view ->
                if (view.player !== exoPlayer) {
                    view.player = exoPlayer
                }
            }
        )

        // 100% Synced Netflix-style Subtitle Overlay
        NetflixSubtitleOverlay(
            subtitleState = currentSubtitleState,
            styleConfig = styleConfig,
            onVerticalBiasChanged = onVerticalBiasChanged,
            modifier = Modifier.fillMaxSize()
        )

        // Error banner if stream rejects direct playback
        playerError?.let { msg ->
            Surface(
                color = Color(0xDD991B1B),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
            ) {
                Text(
                    text = msg,
                    color = Color.White,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }

        // Top Bar: Close + Proactive Subtitle Trigger + Settings
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .size(38.dp)
                    .background(Color(0x99000000), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "إغلاق المشغّل",
                    tint = Color.White
                )
            }

            // Center: Proactive Generate / Status Pill
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = when {
                    parsedCues.isNotEmpty() && !isGeneratingProactive -> Color(0xBB166534)
                    isGeneratingProactive -> Color(0xCC1E3A8A)
                    else -> Color(0xDDE50914)
                },
                modifier = Modifier.clickable(enabled = !isGeneratingProactive) {
                    onStartProactiveSubtitles()
                }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (isGeneratingProactive) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            strokeWidth = 2.dp,
                            color = Color.White
                        )
                        Text(
                            text = "جاري الترجمة ($proactiveProgressPercent%)...",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else if (parsedCues.isNotEmpty()) {
                        Icon(
                            imageVector = Icons.Default.Subtitles,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "ترجمة 100% (${parsedCues.size} جملة)",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Subtitles,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "توليد ترجمة 100%",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .size(38.dp)
                    .background(Color(0x99000000), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "إعدادات الترجمة",
                    tint = Color.White
                )
            }
        }

        // Compact floating Sync & Position pill bar (top-end below settings)
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 60.dp, end = 12.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                PlayerMiniChip("-0.2") { onNudgeSyncOffset(-0.2f) }
                PlayerMiniChip("+0.2") { onNudgeSyncOffset(0.2f) }
                PlayerMiniChip("▲") { onVerticalBiasChanged(styleConfig.verticalBias - 0.04f) }
                PlayerMiniChip("▼") { onVerticalBiasChanged(styleConfig.verticalBias + 0.04f) }
            }
            if (kotlin.math.abs(styleConfig.syncOffsetSec) >= 0.05f) {
                val sign = if (styleConfig.syncOffsetSec > 0) "+" else ""
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xCC000000),
                    modifier = Modifier.clickable { onResetSyncOffset() }
                ) {
                    Text(
                        text = "${sign}${String.format("%.1f", styleConfig.syncOffsetSec)}s ↺",
                        color = Color(0xFFF5C518),
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayerMiniChip(label: String, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xAA18181B),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
        )
    }
}

private fun parseCuesJson(json: String?): List<ExternalCue> {
    if (json.isNullOrBlank()) return emptyList()
    return runCatching {
        val arr = JSONArray(json)
        val list = ArrayList<ExternalCue>(arr.length())
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val s = obj.optDouble("s", -1.0)
            val e = obj.optDouble("e", -1.0)
            val ar = obj.optString("ar", "")
            val en = obj.optString("en", "")
            if (s >= 0.0 && e > s && ar.isNotBlank()) {
                list.add(ExternalCue(s, e, en, ar))
            }
        }
        list.sortBy { it.startSec }
        list
    }.getOrDefault(emptyList())
}

private fun findCueAtTime(cues: List<ExternalCue>, tSec: Double): ExternalCue? {
    var lo = 0
    var hi = cues.size - 1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        val c = cues[mid]
        when {
            tSec < c.startSec -> hi = mid - 1
            tSec > c.endSec -> lo = mid + 1
            else -> return c
        }
    }
    return null
}
