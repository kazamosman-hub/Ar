package com.cinemasub.browser.ui

import android.content.Context
import android.net.Uri
import com.cinemasub.browser.browser.ExternalSubtitleParser
import com.cinemasub.browser.browser.ProactiveMediaSubtitleEngine
import android.util.Patterns
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cinemasub.browser.audio.AudioCaptureService
import com.cinemasub.browser.audio.DeepgramStreamingClient
import com.cinemasub.browser.model.AiTranslationConfig
import com.cinemasub.browser.model.Bookmark
import com.cinemasub.browser.model.DeepgramLanguage
import com.cinemasub.browser.model.PipelineStatus
import com.cinemasub.browser.model.QuickLink
import com.cinemasub.browser.model.SubtitleBgOpacity
import com.cinemasub.browser.model.SubtitleDialect
import com.cinemasub.browser.model.SubtitleFontSize
import com.cinemasub.browser.model.SubtitleSourceMode
import com.cinemasub.browser.model.SubtitleState
import com.cinemasub.browser.model.SubtitleStyleConfig
import com.cinemasub.browser.model.SubtitleTextColor
import com.cinemasub.browser.model.TranslationEngine
import com.cinemasub.browser.translation.ArabicTranslator
import com.cinemasub.browser.translation.TranslationSettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.launch
import java.net.URLEncoder

data class BrowserUiState(
    val currentUrl: String = "",
    val addressBarText: String = "",
    val isHomeVisible: Boolean = true,
    val isLoading: Boolean = false,
    val loadingProgress: Int = 0,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val adBlockerEnabled: Boolean = TranslationSettingsStore.isAdBlockerEnabled,
    val forceDarkMode: Boolean = TranslationSettingsStore.forceDarkMode,
    val playbackSpeed: Float = 1.0f,
    val externalSubtitlesJson: String? = null,
    val externalSubtitleFileName: String? = null,
    val isLoadingExternalSubtitle: Boolean = false,
    val detectedVideoUrl: String? = null,
    val detectedPlayerUrl: String? = null,
    val isCinemaPlayerOpen: Boolean = false,
    val isGeneratingProactive: Boolean = false,
    val proactiveProgressPercent: Int = 0,
    val proactiveStatusMessage: String? = null,
    val blockedAdsCount: Int = 0,
    val isFullscreenVideo: Boolean = false,
    val showFullscreenPrompt: Boolean = false,
    val webCaptionEnabled: Boolean = false,
    val hasReceivedWebCaption: Boolean = false,
    val isTestingApiKey: Boolean = false,
    val apiKeyTestResult: Pair<Boolean, String>? = null,
    val isTestingDeepgramKey: Boolean = false,
    val deepgramTestResult: Pair<Boolean, String>? = null,
    val subtitleStyle: SubtitleStyleConfig = SubtitleStyleConfig(),
    val aiConfig: AiTranslationConfig = TranslationSettingsStore.currentConfig,
    val bookmarks: List<Bookmark> = listOf(
        Bookmark("YouTube", "https://m.youtube.com"),
        Bookmark("Vimeo", "https://vimeo.com"),
        Bookmark("TED Talks", "https://www.ted.com/talks")
    )
)

class BrowserViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(BrowserUiState())
    val uiState: StateFlow<BrowserUiState> = _uiState.asStateFlow()

    val webCaptionTranslator = ArabicTranslator()
    private var detectedVideoHeaders: Map<String, String> = emptyMap()
    private var proactiveJob: Job? = null
    private val _webSubtitleState = MutableStateFlow(SubtitleState())

    private val incomingWebCues = MutableSharedFlow<String>(
        replay = 0,
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    private val preloadBatches = MutableSharedFlow<List<String>>(
        replay = 0,
        extraBufferCapacity = 4,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    private val preloadSemaphore = Semaphore(2)
    private val recentEnglishCues = ArrayDeque<String>()

    val subtitleState: StateFlow<SubtitleState> = combine(
        _webSubtitleState,
        AudioCaptureService.subtitleState
    ) { webState, audioState ->
        when {
            audioState.isLiveEnabled -> audioState
            webState.isLiveEnabled -> webState
            else -> SubtitleState()
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SubtitleState()
    )

    val quickLinks = listOf(
        QuickLink("YouTube", "https://m.youtube.com", Color(0xFFE50914)),
        QuickLink("Vimeo", "https://vimeo.com", Color(0xFF1AB7EA)),
        QuickLink("Dailymotion", "https://www.dailymotion.com", Color(0xFF0066DC)),
        QuickLink("Google", "https://www.google.com", Color(0xFF34A853))
    )

    init {
        viewModelScope.launch(Dispatchers.IO) {
            webCaptionTranslator.ensureModelDownloaded()
        }

        viewModelScope.launch(Dispatchers.IO) {
            preloadBatches.collect { batch ->
                if (_uiState.value.webCaptionEnabled && batch.isNotEmpty()) {
                    val snapshotContext = synchronized(recentEnglishCues) { recentEnglishCues.toList() }
                    launch(Dispatchers.IO) {
                        preloadSemaphore.withPermit {
                            webCaptionTranslator.preloadBatchToCache(batch, snapshotContext)
                        }
                    }
                }
            }
        }

        viewModelScope.launch(Dispatchers.IO) {
            incomingWebCues.collectLatest { rawCue ->
                if (!_uiState.value.webCaptionEnabled) return@collectLatest

                if (rawCue.isBlank()) {
                    _webSubtitleState.update {
                        it.copy(arabicText = "", originalEnglishText = "")
                    }
                    return@collectLatest
                }

                _uiState.update { it.copy(hasReceivedWebCaption = true) }
                val prev = synchronized(recentEnglishCues) {
                    val last = recentEnglishCues.lastOrNull().orEmpty()
                    if (last != rawCue) {
                        recentEnglishCues.addLast(rawCue)
                        if (recentEnglishCues.size > 4) recentEnglishCues.removeFirst()
                    }
                    last
                }
                val arabic = webCaptionTranslator.translateToArabic(rawCue, prev)
                val offsetMs = (_uiState.value.subtitleStyle.syncOffsetSec * 1000f).toLong()
                if (offsetMs > 0L) delay(offsetMs)
                if (arabic.isNotBlank() && _uiState.value.webCaptionEnabled) {
                    _webSubtitleState.update {
                        it.copy(
                            isLiveEnabled = true,
                            sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                            originalEnglishText = rawCue,
                            arabicText = arabic,
                            status = PipelineStatus.Listening
                        )
                    }
                }
            }
        }
    }

    fun loadSavedSettings(context: Context) {
        TranslationSettingsStore.init(context)
        _uiState.update {
            it.copy(
                aiConfig = TranslationSettingsStore.currentConfig,
                adBlockerEnabled = TranslationSettingsStore.isAdBlockerEnabled,
                forceDarkMode = TranslationSettingsStore.forceDarkMode,
                subtitleStyle = it.subtitleStyle.copy(
                    syncOffsetSec = TranslationSettingsStore.syncOffsetSec,
                    dualSubtitlesEnabled = TranslationSettingsStore.dualSubtitlesEnabled
                )
            )
        }
    }

    fun updateTranslationEngine(context: Context, engine: TranslationEngine) {
        val updated = _uiState.value.aiConfig.copy(engine = engine)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated, apiKeyTestResult = null) }
    }

    fun updateSubtitleDialect(context: Context, dialect: SubtitleDialect) {
        val updated = _uiState.value.aiConfig.copy(dialect = dialect)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated) }
    }

    fun nudgeSyncOffset(context: Context, deltaSec: Float) {
        updateSyncOffsetSec(context, _uiState.value.subtitleStyle.syncOffsetSec + deltaSec)
    }

    fun setDualSubtitlesEnabled(context: Context, enabled: Boolean) {
        TranslationSettingsStore.setDualSubtitlesEnabled(context, enabled)
        _uiState.update {
            it.copy(subtitleStyle = it.subtitleStyle.copy(dualSubtitlesEnabled = enabled))
        }
    }

    fun setForceDarkMode(context: Context, enabled: Boolean) {
        TranslationSettingsStore.setForceDarkMode(context, enabled)
        _uiState.update { it.copy(forceDarkMode = enabled) }
    }

    fun setPlaybackSpeed(speed: Float) {
        _uiState.update { it.copy(playbackSpeed = speed) }
    }

    fun updateGeminiApiKey(context: Context, key: String) {
        val updated = _uiState.value.aiConfig.copy(geminiApiKey = key)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated, apiKeyTestResult = null) }
    }

    fun updateGroqApiKey(context: Context, key: String) {
        val updated = _uiState.value.aiConfig.copy(groqApiKey = key)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated, apiKeyTestResult = null) }
    }

    fun updateOpenRouterApiKey(context: Context, key: String) {
        val updated = _uiState.value.aiConfig.copy(openRouterApiKey = key)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated, apiKeyTestResult = null) }
    }

    fun updateDeepgramApiKey(context: Context, key: String) {
        val updated = _uiState.value.aiConfig.copy(deepgramApiKey = key)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated, deepgramTestResult = null) }
    }

    fun updateDeepgramLanguage(context: Context, lang: DeepgramLanguage) {
        val updated = _uiState.value.aiConfig.copy(deepgramLanguage = lang)
        TranslationSettingsStore.update(context, updated)
        _uiState.update { it.copy(aiConfig = updated) }
    }

    fun testDeepgramApiKey() {
        val key = _uiState.value.aiConfig.deepgramApiKey
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingDeepgramKey = true, deepgramTestResult = null) }
            val result = DeepgramStreamingClient.verifyApiKey(key)
            _uiState.update { it.copy(isTestingDeepgramKey = false, deepgramTestResult = result) }
        }
    }

    fun updateSyncOffsetSec(context: Context, offsetSec: Float) {
        val clamped = (Math.round(offsetSec * 5f) / 5f).coerceIn(-3f, 3f)
        TranslationSettingsStore.setSyncOffsetSec(context, clamped)
        _uiState.update {
            it.copy(subtitleStyle = it.subtitleStyle.copy(syncOffsetSec = clamped))
        }
    }

    fun testCurrentApiKey() {
        val config = _uiState.value.aiConfig
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingApiKey = true, apiKeyTestResult = null) }
            val result = webCaptionTranslator.testAllConfiguredKeys(config)
            _uiState.update { it.copy(isTestingApiKey = false, apiKeyTestResult = result) }
        }
    }

    fun toggleAdBlocker(context: Context) {
        val next = !_uiState.value.adBlockerEnabled
        TranslationSettingsStore.setAdBlockerEnabled(context, next)
        _uiState.update { it.copy(adBlockerEnabled = next) }
    }

    fun setAdBlockerEnabled(context: Context, enabled: Boolean) {
        TranslationSettingsStore.setAdBlockerEnabled(context, enabled)
        _uiState.update { it.copy(adBlockerEnabled = enabled) }
    }

    fun loadExternalSubtitleFile(context: Context, uri: Uri) {
        viewModelScope.launch {
            val fileName = ExternalSubtitleParser.resolveDisplayName(context, uri)
            _uiState.update {
                it.copy(
                    isLoadingExternalSubtitle = true,
                    webCaptionEnabled = true,
                    hasReceivedWebCaption = true
                )
            }
            _webSubtitleState.value = SubtitleState(
                isLiveEnabled = true,
                sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                status = PipelineStatus.DownloadingModels("جاري تجهيز وترجمة ملف $fileName...")
            )
            val result = ExternalSubtitleParser.loadAndPrepareJson(context, uri, webCaptionTranslator)
            if (result != null) {
                val (json, count) = result
                _uiState.update {
                    it.copy(
                        isLoadingExternalSubtitle = false,
                        externalSubtitlesJson = json,
                        externalSubtitleFileName = "$fileName ($count جملة)"
                    )
                }
                _webSubtitleState.value = SubtitleState(
                    isLiveEnabled = true,
                    sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                    status = PipelineStatus.Listening
                )
            } else {
                _uiState.update { it.copy(isLoadingExternalSubtitle = false) }
                _webSubtitleState.value = SubtitleState(
                    isLiveEnabled = true,
                    sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                    status = PipelineStatus.Error("تعذر قراءة ملف الترجمة، تأكد أنه بصيغة .srt أو .vtt")
                )
            }
        }
    }

    fun onDetectedVideoStream(url: String, headers: Map<String, String>) {
        val current = _uiState.value.detectedVideoUrl
        // Prefer .m3u8 master playlist over single .mp4 or keep newest stream
        if (current != null && current.lowercase().contains(".m3u8") && !url.lowercase().contains(".m3u8")) {
            return
        }
        detectedVideoHeaders = headers
        val referer = headers.entries.firstOrNull { it.key.equals("Referer", ignoreCase = true) }?.value?.trim()
        val pageHost = runCatching { android.net.Uri.parse(_uiState.value.currentUrl).host }.getOrNull()
        val refHost = runCatching { android.net.Uri.parse(referer).host }.getOrNull()
        val iframePlayerUrl = if (
            !referer.isNullOrBlank() &&
            (referer.startsWith("http://") || referer.startsWith("https://")) &&
            !refHost.isNullOrBlank() &&
            !refHost.equals(pageHost, ignoreCase = true)
        ) {
            referer
        } else {
            _uiState.value.detectedPlayerUrl
        }
        _uiState.update { it.copy(detectedVideoUrl = url, detectedPlayerUrl = iframePlayerUrl) }
    }

    fun startProactiveSubtitleGeneration(context: Context) {
        val mediaUrl = _uiState.value.detectedVideoUrl ?: return
        val config = _uiState.value.aiConfig
        proactiveJob?.cancel()
        proactiveJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isGeneratingProactive = true,
                    proactiveProgressPercent = 2,
                    proactiveStatusMessage = "جاري تجهيز الترجمة الاستباقية بتوقيت 100%...",
                    webCaptionEnabled = true,
                    hasReceivedWebCaption = true
                )
            }
            _webSubtitleState.value = SubtitleState(
                isLiveEnabled = true,
                sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                status = PipelineStatus.DownloadingModels("جاري تجهيز أول دقيقتين بتوقيت 100%...")
            )
            try {
                val res = ProactiveMediaSubtitleEngine.generateProgressively(
                    context = context,
                    mediaUrl = mediaUrl,
                    headers = detectedVideoHeaders,
                    deepgramApiKey = config.deepgramApiKey,
                    languageCode = config.deepgramLanguage.code,
                    translator = webCaptionTranslator,
                    onProgress = { json, count, pct, msg ->
                        _uiState.update { st ->
                            st.copy(
                                proactiveProgressPercent = pct,
                                proactiveStatusMessage = msg,
                                externalSubtitlesJson = json ?: st.externalSubtitlesJson,
                                externalSubtitleFileName = if (count > 0) "ترجمة استباقية ($count جملة)" else st.externalSubtitleFileName
                            )
                        }
                        if (json != null && count > 0) {
                            _webSubtitleState.value = SubtitleState(
                                isLiveEnabled = true,
                                sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                                status = PipelineStatus.Listening
                            )
                        }
                    }
                )
                if (res != null) {
                    val (json, count) = res
                    _uiState.update {
                        it.copy(
                            isGeneratingProactive = false,
                            proactiveProgressPercent = 100,
                            proactiveStatusMessage = "اكتملت الترجمة الاستباقية ($count جملة) بتوقيت 100% ✅",
                            externalSubtitlesJson = json,
                            externalSubtitleFileName = "ترجمة استباقية ($count جملة)"
                        )
                    }
                    _webSubtitleState.value = SubtitleState(
                        isLiveEnabled = true,
                        sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                        status = PipelineStatus.Listening
                    )
                } else {
                    _uiState.update {
                        it.copy(
                            isGeneratingProactive = false,
                            proactiveStatusMessage = "تعذر استخراج كلام من هذا الفيديو — استخدم وضع الصوت المباشر."
                        )
                    }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                _uiState.update {
                    it.copy(
                        isGeneratingProactive = false,
                        proactiveStatusMessage = "تم إيقاف الترجمة الاستباقية."
                    )
                }
            } catch (e: Exception) {
                val errMsg = e.localizedMessage ?: "تعذر معالجة هذا الفيديو (قد يكون محمياً بـ DRM)."
                _uiState.update {
                    it.copy(
                        isGeneratingProactive = false,
                        proactiveStatusMessage = errMsg
                    )
                }
                _webSubtitleState.value = SubtitleState(
                    isLiveEnabled = true,
                    sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                    status = PipelineStatus.Error(errMsg)
                )
            }
        }
    }

    fun getDetectedVideoHeaders(): Map<String, String> = detectedVideoHeaders

    fun openCinemaPlayer() {
        if (_uiState.value.detectedVideoUrl != null) {
            _uiState.update { it.copy(isCinemaPlayerOpen = true) }
        }
    }

    fun closeCinemaPlayer() {
        _uiState.update { it.copy(isCinemaPlayerOpen = false) }
    }

    fun cancelProactiveSubtitleGeneration() {
        proactiveJob?.cancel()
        proactiveJob = null
        _uiState.update { it.copy(isGeneratingProactive = false) }
    }

    fun clearExternalSubtitle() {
        _uiState.update {
            it.copy(
                externalSubtitlesJson = null,
                externalSubtitleFileName = null,
                isLoadingExternalSubtitle = false
            )
        }
        _webSubtitleState.update { it.copy(arabicText = "", originalEnglishText = "") }
    }

    fun onExternalSubtitleCueReceived(arabic: String, english: String) {
        if (_uiState.value.externalSubtitlesJson.isNullOrBlank()) return
        _webSubtitleState.value = SubtitleState(
            isLiveEnabled = true,
            sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
            originalEnglishText = english,
            arabicText = arabic,
            status = PipelineStatus.Listening
        )
    }

    fun onWebCaptionReceived(rawCue: String) {
        if (!_uiState.value.webCaptionEnabled) return
        if (!_uiState.value.externalSubtitlesJson.isNullOrBlank()) return
        incomingWebCues.tryEmit(rawCue)
    }

    fun onPreloadBatchReceived(batch: List<String>) {
        if (!_uiState.value.webCaptionEnabled) return
        preloadBatches.tryEmit(batch)
    }

    fun setWebCaptionEnabled(enabled: Boolean) {
        _uiState.update {
            it.copy(
                webCaptionEnabled = enabled,
                hasReceivedWebCaption = if (enabled) false else it.hasReceivedWebCaption
            )
        }
        if (enabled) {
            _webSubtitleState.update {
                SubtitleState(
                    isLiveEnabled = true,
                    sourceMode = SubtitleSourceMode.WEB_CAPTIONS,
                    arabicText = "",
                    status = PipelineStatus.Listening
                )
            }
        } else {
            _webSubtitleState.update { SubtitleState() }
        }
    }

    fun resolveInputToUrl(rawInput: String): String {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return "https://www.google.com"
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            return trimmed
        }
        val looksLikeDomain = !trimmed.contains(" ") &&
            trimmed.contains(".") &&
            Patterns.WEB_URL.matcher("https://$trimmed").matches()

        return if (looksLikeDomain) {
            "https://$trimmed"
        } else {
            val encoded = URLEncoder.encode(trimmed, "UTF-8")
            "https://www.google.com/search?q=$encoded"
        }
    }

    fun onAddressBarChanged(text: String) {
        _uiState.update { it.copy(addressBarText = text) }
    }

    fun onNavigateTo(url: String) {
        _uiState.update {
            it.copy(
                currentUrl = url,
                addressBarText = url,
                isHomeVisible = false,
                blockedAdsCount = 0,
                hasReceivedWebCaption = false
            )
        }
    }

    fun goHome() {
        _uiState.update {
            it.copy(isHomeVisible = true, addressBarText = "")
        }
    }

    fun onPageStarted(url: String) {
        detectedVideoHeaders = emptyMap()
        _uiState.update {
            it.copy(
                detectedVideoUrl = null,
                detectedPlayerUrl = null,
                currentUrl = url,
                addressBarText = url,
                isLoading = true,
                hasReceivedWebCaption = false
            )
        }
    }

    fun onPageFinished(url: String, canGoBack: Boolean, canGoForward: Boolean) {
        _uiState.update {
            it.copy(
                currentUrl = url,
                addressBarText = url,
                isLoading = false,
                canGoBack = canGoBack,
                canGoForward = canGoForward
            )
        }
    }

    fun onProgressChanged(progress: Int) {
        _uiState.update { it.copy(loadingProgress = progress, isLoading = progress < 100) }
    }

    fun incrementBlockedAds() {
        _uiState.update { it.copy(blockedAdsCount = it.blockedAdsCount + 1) }
    }

    fun onFullscreenChanged(isFullscreen: Boolean) {
        _uiState.update { state ->
            val shouldPrompt = isFullscreen && !subtitleState.value.isLiveEnabled
            state.copy(
                isFullscreenVideo = isFullscreen,
                showFullscreenPrompt = shouldPrompt
            )
        }
    }

    fun dismissFullscreenPrompt() {
        _uiState.update { it.copy(showFullscreenPrompt = false) }
    }

    fun addBookmark(title: String, url: String) {
        if (url.isBlank()) return
        _uiState.update { state ->
            if (state.bookmarks.any { it.url == url }) state
            else state.copy(bookmarks = state.bookmarks + Bookmark(title.ifBlank { url }, url))
        }
    }

    fun removeBookmark(url: String) {
        _uiState.update { state ->
            state.copy(bookmarks = state.bookmarks.filterNot { it.url == url })
        }
    }

    fun updateFontSize(size: SubtitleFontSize) {
        _uiState.update { it.copy(subtitleStyle = it.subtitleStyle.copy(fontSize = size)) }
    }

    fun updateTextColor(color: SubtitleTextColor) {
        _uiState.update { it.copy(subtitleStyle = it.subtitleStyle.copy(textColor = color)) }
    }

    fun updateBgOpacity(bg: SubtitleBgOpacity) {
        _uiState.update { it.copy(subtitleStyle = it.subtitleStyle.copy(bgOpacity = bg)) }
    }

    fun updateVerticalBias(bias: Float) {
        _uiState.update {
            it.copy(subtitleStyle = it.subtitleStyle.copy(verticalBias = bias.coerceIn(0.08f, 0.92f)))
        }
    }

    override fun onCleared() {
        webCaptionTranslator.close()
        super.onCleared()
    }
}
